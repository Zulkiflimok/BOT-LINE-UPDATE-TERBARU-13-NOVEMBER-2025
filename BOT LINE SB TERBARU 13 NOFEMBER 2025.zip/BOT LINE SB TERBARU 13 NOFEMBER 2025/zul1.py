from linepy import *
from akad.ttypes import Message
from liff.ttypes import LiffChatContext, LiffContext, LiffNoneContext, LiffViewRequest
from justgood import imjustgood
from datetime import datetime
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, multiprocessing, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib, urllib3, urllib.parse, html5lib, wikipedia, atexit, timeit, pafy, youtube_dl, traceback, livejson
from threading import Thread,Event
from subprocess import check_output
from Naked.toolshed.shell import execute_js
import sys,traceback
_session = requests.session()
botStart = time.time()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2 
#=========================================================
cl = LINE("zulmoko80@gmail.com","Zul1997@",appName ="DESKTOPWIN\t9.2.0\tWindows\t10.0")
#cl.log("Auth Token : " + str(cl.authToken))
#print ("TEAM TERMUX")
#=========================================================
oepoll = OEPoll(cl)
#=========================================================
clProfile = cl.getProfile()
clSettings = cl.getSettings()
#=========================================================
clMID = cl.profile.mid
mid = cl.getProfile().mid
creator = ["ua6105e31b80ad992f5dcc02003a9ecd6"]
owner = ["ua6105e31b80ad992f5dcc02003a9ecd6"]
admin = ["ua6105e31b80ad992f5dcc02003a9ecd6"]
staff = ["ua6105e31b80ad992f5dcc02003a9ecd6"]
Bots = [mid]
SoakBots = creator + owner+ admin + staff
#=========================================================
protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
welcome = []
leave = []
msg_dict = {}
msg_dict1 = {}
temp_flood = {}
try:
    with open("quisdata.json", "r", encoding="utf_8_sig") as fp:
        quisdata = json.loads(fp.read())
except:
    print ("data file not found, data dict default will used")
    quisdata = {}

with open("quest.txt", "r") as file:
     blist = file.readlines()
     quest = [x.strip() for x in blist]
file.close()
group = cl.getAllChatIds()

for g in group:
  quisdata[g]={'point':{}}
  quisdata[g]['saklar']=False
  quisdata[g]['quest']=''
  quisdata[g]['asw']=[]
  quisdata[g]['tmp']=[]
#=========================================================
settings = {
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "changevp": False,
    "changeCover":{},
    "autoJoinTicket":False,
    "readerPesan": "Gw @!, Kang Sider",
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

read = { 
    "readMember": {},
    "readPoint": {}
}

tes = {
    "Message": {},
    "msg": {},
}

tes2 = {
    "Message2": {},
    "msg2": {},
}
wait = {
    "Limit": 3,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "quis": False,
    "autoJoinquis": False,
    #"Joinjs": False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":False,
    "contact":False,
    'autoBlock':False,
    "respontag":False,
    'autoJoin':True,
    'autoCancel':{"on":True,"members":5},
    'autoAdd':False,
    'autotext':False,
    'autoLeave':False,
    'Timeline':False,
    "detectMention":False,
    "detectMention1":True,
    "detectMention2":False,
    "Mentionkick":False,
    "welcomeOn":True,
    "stickerOn":False,
    "sticker":False,
    "rsmule": True,
    "tiktok": True,
    "ytube": True,
    "changevp": False,
    "changeFoto": {},
    "likeOn": True,
    "stickers": {},
    "apikey" : "amdbots",
    "dark" : True,
    "nganu" : False,
    "apkTikel": False,
    "AddstickerSider": {
        "sid": "",
        "spkg": "",
        "status": False
    },
    "AddstickerTag": {
        "sid": "",
        "spkg": "",
        "status":False
    },
    "AddstickerPesan": {
        "sid": "",
        "spkg": "",
        "status":False
    },
    "AddstickerWelcome": {
        "sid": "",
        "spkg": "",
        "status":False
    },
    "AddstickerLeave": {
        "sid": "",
        "spkg": "",
        "status":False
    },
    "stk":{},
    "selfbot":True,
    "token":True,
    "responGc":True,
    "respontag":False,
    "Images":{},
    "Img":{},
    "Addimage":{},
    "Videos":{},
    "Video":{},
    "Addvideo":{},
    #"laranganOn":True,
    "responsalam":True,
    #"liff":"1655623470-81eDd9kM",
    "liff": "1655425084-3OQ8Mn9J",
    "liff1": "1655063343-oxyzbOrK",
    "liff2": "2000602728-ZB8DrLMB",
    "liff3": "1655623470-81eDd9kM",
    "anu": "2000602682",
    "anu1": "2000602682",
    "anu2": "2000602728",
    "anu3": "2000602744",
    "saat": "Data Liff Kamu Saat Ini [ 1 ]\n━━━━━━━━━━━━━━━━━━━\n",
    "saat1": "Data Liff Kamu Saat Ini [ 1 ]\n━━━━━━━━━━━━━━━━━━━\n",
    "saat2": "Data Liff Kamu Saat Ini [ 2 ]\n━━━━━━━━━━━━━━━━━━━\n",
    "saat3": "Data Liff Kamu Saat Ini [ 3 ]\n━━━━━━━━━━━━━━━━━━━\n",
    "link":"https://i.gifer.com/7CJk.gif",
    "link":"https://www.smule.com",
    "amdb":"#bypass",
    "amda":"nukeall",
    "balasan": " Ada sayang ada...kangen ya\n😘😘😘😘😘😘😘😘😘😘😘",
    "siderMsg": "suka ngintip sini msk 𝚔𝚔..",
    "mention1":"hai kk",
    "mention":"𝚃𝚎𝚛𝚌𝚒𝚍𝚞𝚔 𝚝𝚞𝚔𝚊𝚗𝚐 𝚗𝚐𝚒𝚗𝚝𝚒𝚙..😎 ",
    "Tag":"Ada apa kak tag teg tog teros typok purun.....",
    "leave":"Selamat Tinggal Kak ",
    "welcome":"sᴇᴍᴏɢᴀ ʙᴇᴛᴀʜ ɢᴀᴇᴢ\nᴊᴀɴɢᴀɴ ɴᴀᴋᴀʟ ʏᴀ ᴅɪ ᴍᴀʀɪ",
    "leavemsg":"sᴇʟᴀᴍᴀᴛ ᴊᴀʟᴀɴ ᴛᴇᴍᴀɴ\nsᴇᴍᴏɢᴀ ᴛᴇɴᴀɴɢ ᴅɪsᴀɴᴀ ",
    "order":"╭──────────────────╮\n├🔹ɴᴜᴍᴘᴀɴɢ ᴘʀᴏᴍᴏ ʏᴀ ᴋᴀᴋᴀᴋ    │\n╰──────────────────╯\n╭──────────────────\n├🔹ʀᴇᴀᴅʏ ʙᴏᴛ ᴘʀᴏᴛᴇᴄᴛ\n├🔹ʀᴏᴏᴍ sᴍᴜʟᴇ / ᴇᴠᴇɴᴛ \n├🔹ʀᴇᴀᴅʏ sʙ ᴏɴʟʏ \n├🔹sʙ ᴏɴʟʏ + ᴀᴊs \n├🔹sʙ + ᴀssɪsᴛ + ᴀᴊs \n├🔹ʟᴏɢɪɴ ᴊs / ʙʏᴘᴀs\n├🔹ɴᴇᴡ ᴘᴇᴍʙᴜᴀᴛᴀɴ sᴄ ʙᴏᴛ \n├🔹ɴᴇᴡ ʙᴇʟᴀᴊᴀʀ ʙᴏᴛ \n├🔹ᴘᴇᴍᴀsᴀɴɢ sʙ ᴋᴇ ᴛᴇᴍᴘʟᴀᴛᴇ\n├🔹ʀᴇᴀᴅʏ ᴀᴋᴜɴ ᴄᴏɪɴ\n├🔹ʀᴇᴀᴅʏ ᴄᴏɪɴ ɢɪғᴛ \n╰────────────────── \n╭─────────────────\n├ line.me/ti/p/~zul.1.02\n╰─────────────────",
    "unsend":False,
    }

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

comd = {
    "help": "help",
    "help1": "help1",
    "speed": "speed",
    "kick": "kick",
    "tagall": "tagall",
    "cban": "cban",
    "sider2On": "sider2 on",
    "sider2Off": "sider2 off",
    "sider1On": "sider1 on",
    "sider1Off": "sider1 off",
    "siderOn": "sider on",
    "siderOff": "sider off",
    "bye": "bye",
    "unsend": "unsend"
}

cctv = {
    "cyduk":{},
    "cyduk1":{},    
    "cyduk2":{},    
    "point":{},
    "point1":{},    
    "point2":{},    
    "sidermem":{}, 
    "sidermem1":{}, 
    "sidermem2":{}
}

temptag = {
    "stealtag":False
}

with open('creator.json', 'r') as fp:
    creator = json.load(fp)
with open('owner.json', 'r') as fp:
    owner = json.load(fp)
with open('sticker.json', 'r') as fp:
    stickers = json.load(fp)
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

stickersOpen = codecs.open("sticker.json","r","utf-8")
stickers = json.load(stickersOpen)
mulai = time.time()

def load_thedata():
    try:
        with open("thedata.json", "r") as file:
            thedata = json.load(file)
    except FileNotFoundError:
        thedata = {}
    return thedata

def save_thedata():
    global thedata
    backjson1 = json.dumps(thedata, indent=2)
    a = open("thedata.json", "w").write(backjson1)
    return a

thedata = load_thedata()
if "history_upname" not in thedata:
    thedata["history_upname"] = {}
    thedata["user_gid"] = {}
    thedata["useract"] = {}

cl.tmp_getname = {}
cl.tmp_getgcname = {}
cl.flush_tmp_at = 0

def flush_tmp():
    if time.time() < cl.flush_tmp_at:return
    cl.tmp_getname = {}
    cl.tmp_getgcname = {}
    cl.flush_tmp_at = time.time() + 3600

def getname(sender):
    if sender not in cl.tmp_getgcname:
        nama = cl.getContact(sender).displayName
        cl.tmp_getname[sender] = nama
    else:
        nama = cl.tmp_getname[sender]
    if sender not in thedata["history_upname"]:
        thedata["history_upname"][sender] = [nama]
    return nama

def getgcname(to, user=None):
    if user != None and user.startswith("u"):
        try:thedata["user_gid"][user]
        except:thedata["user_gid"][user] = []
        if to not in thedata["user_gid"][user]:
            thedata["user_gid"][user].append(to)
    if to not in cl.tmp_getgcname:
        nama = cl.getChats([to]).chats[0].chatName
        cl.tmp_getname[to] = nama
    else:
        nama = cl.tmp_getname[to]

    return nama
def getUserActivity(user, to_biasa=""):
    jam = pytz.timezone("Asia/Jakarta")
    jamSek = datetime.now(tz=jam)
    jamm = datetime.strftime(jamSek, "%d-%m-%Y")
    jam_time = datetime.strftime(jamSek, "%H:%M")
    msgs = " 𝙉𝙊𝙏𝙞𝙁 𝘿𝙀𝙇𝙀𝙏𝙀 𝘼𝘾𝘾𝙊𝙐𝙉𝙏"
    msgs += f"\n• {jamm} {jam_time}"
    resId = False
    try:
        cl.getContact(user)
        resId = True
    except:
        resId = False
    try:
        if user not in thedata["history_upname"]:
            thedata["history_upname"][user] = [getname(user)]
        indexName = len(thedata["history_upname"][user])
        msgs += f"\n• Display Name: {thedata['history_upname'][user][0]}\n"
        if indexName > 1:
            msgs += "• Previous:\n"
            for no, logName in enumerate(thedata["history_upname"][user][1:indexName], 1):
                msgs += f"{no}. {logName}\n"
    except:
        pass
    if user in thedata["useract"]:
        if thedata["useract"][user]["type"] is not None and thedata["useract"][user]["data"] != {}:
            actType = thedata["useract"][user]["type"]
            actData = thedata["useract"][user]["data"]
            times = humanize.naturaltime(datetime.fromtimestamp(actData["time"]/1000))
            type_mapping = {
                "add": "Add Contact",
                "announce": "Announce",
                "message": "Send Message",
                "read": "Read Message",
                "unsend": "Unsend Message",
                "reaction": "Reaction Message",
                "join": "Join Group",
                "leave": "Leave Group",
                "invite": "Invite User",
                "kick": "Kick User",
                "cancel": "Cancel User",
                "album": "Album Group",
                "call invitation": "Call Invitation",
                "call group": "Call Group",
                "update group": "Update Group",
                "update profile": "Update Profile"
            }
            if actType in type_mapping:
                msgs += "\n𝙉𝙤𝙩𝙞𝙛 𝗔𝗰𝘁𝗶𝘃𝗶𝘁𝙖𝙨\n"
                msgs += f"• Type: {type_mapping[actType]}\n"
                msgs += f"• Time: {times}\n"
                msgs += f"• Group: {actData.get('group', 'N/A')}\n"
                msgs += f"• Detail: {actData.get('msg', 'N/A')}\n"
                if actType == "invite" and len(actData["invited"]) != 0:
                    msgs += f"• Invited: {len(actData['invited'])}\n"
                    try:contacts = [c.displayName for c in cl.getContacts(actData["invited"])]
                    except:contacts = []
                    for no, i in enumerate(contacts, 1):
                        msgs += f"{no}. {i}\n"
                elif actType in ["kick", "cancel"]:
                    msgs += f"• {actType.capitalize()}: {cl.getContact(actData.get('kicked' if actType == 'kick' else 'canceled')).displayName}\n"

    if to_biasa != "":
        return cl.sendMessage(to_biasa, msgs)
    for to in thedata["user_gid"][user]:
        try:cl.sendMessage(to, msgs)
        except:pass
        time.sleep(0.1)

def notifiedUpdateProfile(op): 
    user = op.param1
    option = op.param2
    data = op.param3
    users = getname(user) # cl.getContact(user).displayName
    if user not in thedata["useract"]: thedata["useract"][user] = {"type": None, "data": {}}
    thedata["useract"][user]["type"] = "update profile"
    if option == "2":
        datas = json.loads(data)
        thedata["useract"][user]["data"] = {"msg": f"{users} update display name '{datas['OLD_DISPLAY_NAME']}' to '{datas['DISPLAY_NAME']}'.", "time": op.createdTime}
    elif option == "8": thedata["useract"][user]["data"] = {"msg": f"{users} update profile picture.", "time": op.createdTime}
    elif option == "16": thedata["useract"][user]["data"] = {"msg": f"{users} update profile status.", "time": op.createdTime}

def notifiedAddContact(op):
    user = op.param1
    if user not in thedata["useract"]: thedata["useract"][user] = {"type": None, "data": {}}
    thedata["useract"][user]["type"] = "add"
    thedata["useract"][user]["data"] = {"time": op.createdTime}

def receivedMessage(op):
    msg = op.message
    text = msg.text
    msg_id = msg.id
    receiver = msg.to
    sender = msg._from
    if msg.toType in [0, 1, 2]:
        to = sender if (msg.toType == 0 and sender != cl.profile.mid) else receiver
    if msg.contentType in [0, 1, 2, 3, 7, 13, 14, 15, 16, 18, 19, 22] and msg.toType == 2:
        if sender != cl.profile.mid: 
            users = getname(sender) # cl.getContact(sender).displayName
            user_activity = thedata["useract"].setdefault(sender, {"type": None, "data": {}})
            group_name = getgcname(to, sender)
            content_map = {
                0: {"type": "message", "data": {"text": text, "group": group_name, "time": msg.createdTime}},
                1: {"type": "message", "data": {"text": f"{users} sent a photo.", "group": group_name, "time": msg.createdTime}},
                2: {"type": "message", "data": {"text": f"{users} sent a video.", "group": group_name, "time": msg.createdTime}},
                3: {"type": "message", "data": {"text": f"{users} sent a voice message.", "group": group_name, "time": msg.createdTime}},
                7: {"type": "message", "data": {"text": f"{users} sent a sticker.", "group": group_name, "time": msg.createdTime}},
                13: {"type": "message", "data": {"text": f"{users} sent a contact.", "group": group_name, "time": msg.createdTime}},
                14: {"type": "message", "data": {"text": f"{users} sent a file.", "group": group_name, "time": msg.createdTime}},
                15: {"type": "message", "data": {"text": f"{users} sent a location.", "group": group_name, "time": msg.createdTime}}
            }
            if msg.contentType in content_map:
                thedata["useract"][sender].update(content_map[msg.contentType])
            if msg.contentType == 16:
                service_type = msg.contentMetadata.get("serviceType")
                post_url = msg.contentMetadata.get("postEndUrl", "")
                if service_type == "MH" and "userMid=" in post_url:
                    postid = post_url.split("userMid=")[1].split("&postId=")
                    post_creator = cl.getContact(postid[0]).displayName
                    user_activity["data"] = {"text": f"{users} shared {post_creator}'s post.", "group": group_name, "time": msg.createdTime}
                elif service_type == "GB" and "homeId=" in post_url:
                    postid = post_url.split("homeId=")[1].split("&postId=")
                    post_creator = getgcname(postid[0], sender)
                    user_activity["data"] = {"text": f"{users} shared {post_creator}'s post.", "group": group_name, "time": msg.createdTime}
                elif msg.contentMetadata.get("locKey") == "BA":
                    user_activity["type"] = "album"
                    user_activity["data"] = {"group": group_name, "msg": f"{users} created album {msg.contentMetadata.get('albumName')}.", "time": msg.createdTime}
                elif msg.contentMetadata.get("locKey") == "BT":
                    user_activity["type"] = "album"
                    user_activity["data"] = {"group": group_name, "msg": f"{users} added photo to album {msg.contentMetadata.get('albumName')}.", "time": msg.createdTime}

            elif msg.contentType == 18:
                loc_key = msg.contentMetadata.get("LOC_KEY")
                if loc_key == "BB":
                    splArg = msg.contentMetadata.get("LOC_ARGS", "").split("\x1e")
                    user_activity["type"] = "album"
                    user_activity["data"] = {"group": group_name, "msg": f"{users} changed album name {splArg[0]} to {splArg[1]}.", "time": msg.createdTime}
                elif loc_key == "BD":
                    user_activity["type"] = "album"
                    user_activity["data"] = {"group": group_name, "msg": f"{users} deleted album {msg.contentMetadata.get('LOC_ARGS')}.", "time": msg.createdTime}
                elif loc_key == "BO":
                    user_activity["type"] = "album"
                    user_activity["data"] = {"group": group_name, "msg": f"{users} deleted photo from album {msg.contentMetadata.get('LOC_ARGS')}.", "time": msg.createdTime}
                elif loc_key == "C_SN":
                    user_activity["type"] = "update group"
                    user_activity["data"] = {"group": group_name, "msg": f"{users} allowed joining via link or QR code.", "time": msg.createdTime}
                elif loc_key == "C_SP":
                    user_activity["type"] = "update group"
                    user_activity["data"] = {"group": group_name, "msg": f"{users} disabled joining via link or QR code.", "time": msg.createdTime}
                elif loc_key == "C_PN":
                    splArg = msg.contentMetadata.get("LOC_ARGS", "").split("\x1e")
                    user_activity["type"] = "update group"
                    user_activity["data"] = {"group": group_name, "msg": f"{users} changed group's name to {splArg[1]}.", "time": msg.createdTime}
                elif loc_key == "C_PI":
                    user_activity["type"] = "update group"
                    user_activity["data"] = {"group": group_name, "msg": f"{users} changed group's profile picture.", "time": msg.createdTime}

            elif msg.contentType == 19:
                thedata["useract"][sender]["type"] = "message"
                thedata["useract"][sender]["data"] = {"text": f"{users} shared music.", "group": getgcname(to, sender), "time": msg.createdTime}
            elif msg.contentType == 22:
                thedata["useract"][sender]["type"] = "message"
                thedata["useract"][sender]["data"] = {"text": msg.contentMetadata["ALT_TEXT"], "group": getgcname(to, sender), "time": msg.createdTime}

def notifiedReceiveAnnouncement(op):
    group = op.param1
    if group.startswith("c"):
        announcements = cl.getChatRoomAnnouncements(group)
        if not announcements:
            return
        first_announcement = announcements[0]
        creator_mid = first_announcement.creatorMid
        if creator_mid not in thedata["useract"]:
            thedata["useract"][creator_mid] = {"type": None, "data": {}}
        thedata["useract"][creator_mid]["type"] = "announce"
        thedata["useract"][creator_mid]["data"] = {
            "text": first_announcement.contents.text,
            "group": getgcname(group, creator_mid),
            "time": op.createdTime
        }

def notifiedReadMessage(op):
    group = op.param1
    reader = op.param2
    if reader not in thedata["useract"]: thedata["useract"][reader] = {"type": None, "data": {}}
    thedata["useract"][reader]["type"] = "read"
    if group.startswith("c"): thedata["useract"][reader]["data"] = {"group": getgcname(group, reader), "time": op.createdTime}

def notifiedDestroyMessage(op):
    group = op.param1
    user = op.param2
    if user not in thedata["useract"]:
        thedata["useract"][user] = {"type": None, "data": {}}
    thedata["useract"][user]["type"] = "unsend"
    if group.startswith("c"):
        thedata["useract"][user]["data"] = {
            "group": getgcname(group, user),
            "time": op.createdTime
        }

def notifiedInviteIntoChat(op):
    group = op.param1
    inviter = op.param2
    invited = op.param3.split("\x1e")
    if inviter not in thedata["useract"]:
        thedata["useract"][inviter] = {"type": None, "data": {}}
    thedata["useract"][inviter].update({
        "type": "invite",
        "data": {
            "group": getgcname(group, inviter),
            "time": op.createdTime,
            "invited": invited
        }
    })

def notifiedCancelChatInvitation(op):
    group = op.param1
    canceler = op.param2
    canceled = op.param3
    if canceler not in thedata["useract"]:
        thedata["useract"][canceler] = {"type": None, "data": {}}
    thedata["useract"][canceler].update({
        "type": "cancel",
        "data": {
            "group": getgcname(group, canceler),
            "time": op.createdTime,
            "canceled": canceled
        }
    })

def notifiedDeleteSelfFromChat(op):
    group = op.param1
    leaved = op.param2
    if leaved not in thedata["useract"]:
        thedata["useract"][leaved] = {"type": None, "data": {}}
    thedata["useract"][leaved].update({
        "type": "leave",
        "data": {
            "group": getgcname(group, leaved),
            "time": op.createdTime
        }
    })

def notifiedAcceptChatInvitation(op):
    group = op.param1
    joined = op.param2
    getname(joined)
    if joined not in thedata["useract"]:
        thedata["useract"][joined] = {"type": None, "data": {}}
    thedata["useract"][joined].update({
        "type": "join",
        "data": {
            "group": getgcname(group, joined),
            "time": op.createdTime
        }
    })

def notifiedDeleteOtherFromChat(op):
    group = op.param1
    kicker = op.param2
    kicked = op.param3
    if kicker not in thedata["useract"]:
        thedata["useract"][kicker] = {"type": None, "data": {}}
    thedata["useract"][kicker].update({
        "type": "kick",
        "data": {
            "group": getgcname(group, kicker),
            "time": op.createdTime,
            "kicked": kicked
        }
    })

def getMessageMid(to, id):
    messages = cl.getRecentMessagesV2(to, 100)
    mids = next((msg._from for msg in messages if msg.id == id), None)
    return mids
def notifiedSendReaction(op):
    group = op.param1
    data = op.param2
    sender = op.param3
    datas = json.loads(data)
    if not datas["chatMid"].startswith("c"):
        return
    users = getname(sender) # cl.getContact(sender).displayName
    user_activity = thedata["useract"].setdefault(sender, {"type": None, "data": {}})
    user_activity["type"] = "reaction"
    if datas["curr"] is None:
        user_activity["data"] = {
            "group": getgcname(datas["chatMid"], sender),
            "msg": f"{users} unreaction message.",
            "time": op.createdTime
        }
        return
    itsMids = getMessageMid(datas["chatMid"], group)
    if itsMids is None or itsMids == cl.profile.mid:
        user_activity["data"] = {
            "group": getgcname(datas["chatMid"], sender),
            "msg": f"{users} gave reaction on my message.",
            "time": op.createdTime
        }
        return
    reaction_map = {
        2: "\U00100103\U001001df\U0010ffff",
        3: "\U00100103\U001001e1\U0010ffff",
        4: "\U00100079",
        5: "\U0010007a",
        6: "\U0010007c",
        7: "\U00100091"
    }
    rtype = datas["curr"].get("predefinedReactionType")
    rmsg = reaction_map.get(rtype, "unknown reaction")
    if itsMids != sender:
        fmsg = cl.getContact(itsMids).displayName
        user_activity["data"] = {
            "group": getgcname(datas["chatMid"], sender),
            "msg": f"{users} gave reaction {rmsg} on {fmsg}'s message.",
            "time": op.createdTime
        }
    else:
        user_activity["data"] = {
            "group": getgcname(datas["chatMid"], sender),
            "msg": f"{users} gave reaction {rmsg} on his message.",
            "time": op.createdTime
        }

def recordOp(op):
    try:
        flush_tmp()
        
        if op.type == 33:
            getUserActivity(op.param1)
        if op.type == 2:
            notifiedUpdateProfile(op)
            user_mid = op.param1
            try:v = thedata["history_upname"][user_mid]
            except:thedata["history_upname"][user_mid] = []
            data = json.loads(op.param3)
            try:thedata["history_upname"][user_mid].insert(0, data["DISPLAY_NAME"])
            except:pass
            save_thedata()
        elif op.type == 5:
            notifiedAddContact(op)
            save_thedata()
        elif op.type == 26:
            receivedMessage(op)
            save_thedata()
        elif op.type == 30:
            notifiedReceiveAnnouncement(op)
            save_thedata()
        elif op.type == 55:
            notifiedReadMessage(op)
            save_thedata()
        elif op.type == 65:
            notifiedDestroyMessage(op)
            save_thedata()
        elif op.type == 124:
            notifiedInviteIntoChat(op)
            save_thedata()
        elif op.type == 126:
            notifiedCancelChatInvitation(op)
            save_thedata()
        elif op.type == 128:
            notifiedDeleteSelfFromChat(op)
            save_thedata()
        elif op.type == 130:
            notifiedAcceptChatInvitation(op)
            save_thedata()
        elif op.type == 133:
            notifiedDeleteOtherFromChat(op)
            save_thedata()
        elif op.type == 140:
            notifiedSendReaction(op)
            save_thedata()

    except Exception as e:
        traceback.print_tb(e.__traceback__)
        print("# ================= TRACKER RECORD ERROR ================ #")
        logError(e)

# -------------------------------------------------------------- 

def bypassJS(aping):
    ktl = cl.getChats([aping]).chats[0]
    if ktl.extra.groupExtra.inviteeMids == None:pends = []
    else:pends = ktl.extra.groupExtra.inviteeMids
    pending = []
    for x in pends:
        if x not in Bots and x not in admin and x not in clMID:pending.append(x)
    member = []
    for x in ktl.extra.groupExtra.memberMids:
        if x not in admin and x not in Bots and x not in clMID:member.append(x)
    cm = 'kickall.js gid={} type=dual token={} {}'.format(aping, cl.authToken, "app=desktopwin")
    for x in pending:
        cm += ' uik={}'.format(x)
    for x in member:
        cm += ' uid={}'.format(x)
    success = execute_js(cm)
    return success    
    
def cekpending(aww):
    bajingan = [];koe = cl.getChats([aww]).chats[0]    
    if koe.extra.groupExtra.inviteeMids != {}:
       for mmk in koe.extra.groupExtra.inviteeMids:bajingan.append(mmk)
    return bajingan        
def pendingGroup(to, mids=[]):
    parsed_len = len(mids)//20+1;result = '「 • PendingList • 」\n';mention = '@arfrhmn_ir\n';no = 0            
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1;result += '    • %i. %s' % (no, mention);slen = len(result) - 12;elen = len(result) + 3;mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})                                                
            if mid == mids[-1]:result += '\n'                
        if result:
            if result.endswith('\n'): result = result[:-1]
            cl.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''
def cekmember(aww):
    bajingan = [];koe = cl.getChats([aww], True , False).chats[0]    
    if koe.extra.groupExtra.memberMids != {}:
       for mmk in koe.extra.groupExtra.memberMids:bajingan.append(mmk)
    return bajingan     
def memberGroup(to, mids=[]):
    parsed_len = len(mids)//20+1;result = '「 Type: Mentionlist♪\n';mention = '@arfrhmn_ir\n';no = 0            
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1;result += '    • %i. %s' % (no, mention);slen = len(result) - 12;elen = len(result) + 3;mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})                                                
            if mid == mids[-1]:result += '\n'                
        if result:
            if result.endswith('\n'): result = result[:-1]
            cl.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''
    
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)
def backupquisData():
    with open("quisdata.json", "w", encoding="utf8") as f:
        json.dump(quisdata, f, ensure_ascii=False, indent=4, separators=(',', ': '))
def delExpire():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                if time.time() - temp_flood[tmp]["time"] >= 3*10:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        veza = "BOT ACTIVE AGAIN"
                        cl.sendMessage(tmp, veza, {'AGENT_LINK': "https://line.me/ti/p/~zul.1.02", 'AGENT_ICON': "http://klikuntung.com/images/messengers/line-logo.png", 'AGENT_NAME': "Detect Spam "})        
                    except Exception as error:
                        logError(error)

def delExpirev2():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        veza = "BOT ACTIVE AGAIN"
                        cl.sendMessage(tmp, veza, {'AGENT_LINK': "https://line.me/ti/p/~zul.1.02", 'AGENT_ICON': "http://klikuntung.com/images/messengers/line-logo.png", 'AGENT_NAME': "Detect Spam "})        
                    except Exception as error:
                        logError(error)
def helpquis():
    helpMessagequis = "[ Daftar Perintah ]" + "\n" + \
                  " /mulai" + "\n" + \
                  " /reset" + "\n" + \
                  " /next" + "\n" + \
                  " /nyerah" + "\n" + \
                  " /keluar" + "\n" + \
                  " /laporkan" + "\n" + \
                  "[ BOT GAME ]"
    return helpMessagequis
def getQuest(to):
	try:
			quisdata[to]['quest'] = ''
			quisdata[to]['asw'] = []
			quisdata[to]['tmp'] = []
			a = random.choice(quest)
			a = a.split('*')
			quisdata[to]['quest'] = a[0]
			for i in range(len(a)):
				quisdata[to]['asw'] += [a[i]]
			quisdata[to]['asw'].remove(a[0])
			for j in range(len(quisdata[to]['asw'])):
				quisdata[to]['tmp'] += [str(j+1)+'. _________']
	except Exception as e:
		print(e)
def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)
def allowLiff():
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': cl.authToken,
        'X-Line-Application': cl.server.APP_NAME,
        'X-Line-ChannelId': wait["anu"],
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)
        
def sendFlexAudio(to, link):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1655063343-oxyzbOrK', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {'Content-Type': 'application/json','Authorization': 'Bearer %s' % token.accessToken}
    data = {'messages': [{'type': 'audio','originalContentUrl': link,'duration': 250000}]}
    requests.post(url, headers=headers, data=json.dumps(data))

#==========[Template sider Zul]=======================================================================#

def sendSiderZul0(to, text):
    data = {
        "type": "text",
        "text": text,
        "sentBy": {
            "label": "TEAM TERMUX",
            "iconUrl": "https://3.bp.blogspot.com/-eg6KT8X_o-c/UkelFbx4igI/AAAAAAAAmiI/3Rq5Vs0NmX0/s1600/COUNTDOWN+RADAR.gif",            
            "linkUrl": "http://line.me/ti/p/~zul.1.02"
        }
    }
    sendTemplate(to, data)    


def sendSiderZul2(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/2yptfqj/ezgif-com-gif-to-apng.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "6:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/DYT9yGS/ezgif-com-gif-to-apng-3.png",
                "size": "15px",
                "aspectRatio": "6:2",
                "aspectMode": "cover",
                "animated": True,
              }
            ],
            "position": "absolute",
            "width": "80px",
            "height": "15px",
            "offsetTop": "12px",
            "offsetStart": "60px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "6px",
                "color": "#ff00ff",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "10px",
            "offsetTop": "1px",
            "offsetStart": "4px"
          }
        ],
        "paddingAll": "0px",
        "height": "20px",
        "cornerRadius": "15px",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02",
        }
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)

#==========[Template Zul]=======================================================================#

def sendZulBots5(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/2yptfqj/ezgif-com-gif-to-apng.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "6:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/DYT9yGS/ezgif-com-gif-to-apng-3.png",
                "size": "15px",
                "aspectRatio": "6:2",
                "aspectMode": "cover",
                "animated": True,
              }
            ],
            "position": "absolute",
            "width": "80px",
            "height": "15px",
            "offsetTop": "12px",
            "offsetStart": "60px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "6px",
                "color": "#ff00ff",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "10px",
            "offsetTop": "1px",
            "offsetStart": "4px"
          }
        ],
        "paddingAll": "0px",
        "height": "20px",
        "cornerRadius": "15px",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02",
        }
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)

def sendZulBots4(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "bubble",
  "size": "micro",
  "hero": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "animated": True,
        "url": "https://i.ibb.co.com/PC0GrXZ/ezgif-com-gif-maker-1.png",
        "size": "full",
        "gravity": "top",
        "aspectRatio": "2:2",
        "aspectMode": "cover",
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6chJwhf/ezgif-com-gif-maker.png",
                "size": "full",
                "aspectRatio": "6:4",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "100px",
            "offsetTop": "0px",
            "offsetStart": "0px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/BKJwN57/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "8:2",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xxs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "50px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "50px",
            "offsetTop": "98px",
            "borderWidth": "1px",
            "borderColor": "#00ff00"
          }
        ],
        "position": "absolute",
        "width": "150px",
        "height": "140px",
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "5px",
        "offsetTop": "5px",
        "offsetStart": "5px"
      }
    ],
    "height": "150px"
  },
  "action": {
    "type": "uri",
    "label": "action",
    "uri": "http://line.me/ti/p/~zul.1.02",
  }
}
}
    time.sleep(0.5)
    sendTemplate(to, data)    


def sendZulBots3(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "size": "full",
            "aspectRatio": "2:1",
            "aspectMode": "cover",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xs",
                "color": "#FFFF00",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#0000FF",
            "borderWidth": "1px",
            "borderColor": "#000000",
            "cornerRadius": "5px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xs",
                "color": "#00ff00",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "25px"
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "20px",
            "offsetTop": "22px"
          }
        ],
        "height": "40px",
        "borderWidth": "2px",
        "borderColor": "#0000FF",
        "cornerRadius": "10px"
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)

def sendZulBots2(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/bKcWjLp/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectRatio": "2:1",
            "aspectMode": "cover",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xs",
                "color": "#000000",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#bbccff",
            "borderWidth": "1px",
            "borderColor": "#000fff",
            "cornerRadius": "5px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "xs",
                "color": "#00ff00",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "25px"
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "20px",
            "offsetTop": "22px"
          }
        ],
        "height": "40px",
        "borderWidth": "2px",
        "borderColor": "#000fff",
        "cornerRadius": "10px"
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)

def sendZulBots1(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/y8qYcrc/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/ykmxR0P/ezgif-com-gif-maker.png",
                "size": "xxl",
                "aspectRatio": "6:2",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "140px",
                "height": "15px",
                "offsetTop": "0px",
                "offsetStart": "20px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "44px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "height": "50px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)


def sendZulBots0(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "size": "lg",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
            "offsetTop": "30px",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "H E L P",
                "size": "lg",
                "color": "#ff0000",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "28px",
                "offsetTop": "2px"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "30px",
            "borderWidth": "1px",
            "borderColor": "#ffffff"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "md",
                "color": "#ff0000",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "30px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "offsetTop": "390px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xs",
                "color": "#00ffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
              }
            ],
            "position": "absolute",
            "offsetTop": "34px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "height": "420px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "15px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)

 
 #=================================================================================#
def sendFlexVid2024(to, vid_url, img_url):
    #img_url = "https://i.ibb.co.com/YFgMQKXz/a97bfba3168f331db7ddbf5e3cebd240.jpg"
    data = {
      "type": "bubble",
      "size": "hecto",
      "hero": {
        "type": "video",
        "url": vid_url,
        "altContent": {
          "type": "box",
          "layout": "vertical",
          "contents": []
        },
        "previewUrl": img_url,
        "aspectRatio": "2:2"
      },
      "styles": {
        "hero": {
          "backgroundColor": "#FFFFFF"
        }
      }
    }
    sendTemplate(to, {"type": "flex", "altText": "TEAM TERMUX", "contents": data})
 
def sendFlexVid2025(to, vid_url, img_url):
    #img_url = "https://i.ibb.co.com/7tWL3r2z/61c5d7029d173fe0ae816aa67c79532a.jpg"
    data = {
      "type": "bubble",
      "size": "hecto",
      "hero": {
        "type": "video",
        "url": vid_url,
        "altContent": {
          "type": "box",
          "layout": "vertical",
          "contents": []
        },
        "previewUrl": img_url,
        "aspectRatio": "2:2"
      },
      "styles": {
        "hero": {
          "backgroundColor": "#FFFFFF"
        }
      }
    }
    sendTemplate(to, {"type": "flex", "altText": "TEAM TERMUX", "contents": data})
    
def sendFlexVid2026(to, vid_url, img_url):
    #img_url = "https://i.ibb.co.com/pB4rwmGR/c587e77101042b11485dd465bfe6df38.jpg"
    data = {
      "type": "bubble",
      "size": "hecto",
      "hero": {
        "type": "video",
        "url": vid_url,
        "altContent": {
          "type": "box",
          "layout": "vertical",
          "contents": []
        },
        "previewUrl": img_url,
        "aspectRatio": "2:2"
      },
      "styles": {
        "hero": {
          "backgroundColor": "#FFFFFF"
        }
      }
    }
    sendTemplate(to, {"type": "flex", "altText": "TEAM TERMUX", "contents": data})    
    
def sendFlexVideo(to, videoUrl, thumbnail='dark'):
    main = ["dark","red","cyan","yellow","green","white"]
    if thumbnail in main:
       thumbnail = f"https://i.ibb.co.com/pB4rwmGR/c587e77101042b11485dd465bfe6df38.jpg" 
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1655063343-oxyzbOrK', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {
        'messages': [{
            'type': 'video',
            'originalContentUrl': videoUrl,
            'previewImageUrl': thumbnail,
        }]
    }
    requests.post(url, headers=headers, data=json.dumps(data))   

def sendTemplate(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1655063343-oxyzbOrK', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendMentionZul(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendTextTemplate330(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "bubble",
  "size": "micro",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/2vrfT6P/hlth-adt-menu-c.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1500:2130",
            "aspectMode": "fit"
          }
        ],
        "width": "167px",
        "position": "absolute"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/th7j0nT/hlth-adt-menu-h.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "260:67.5",
            "aspectMode": "fit"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/mcMLDQk/hlth-adt-menu-anim-h.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1665:420",
            "aspectMode": "fit",
            "position": "absolute",
            "animated": True
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "7px",
                "color": "FFFFFF", 
                "weight": "bold"
              }
            ],
            "height": "10px",
            "width": "90px",
            "position": "absolute",
            "offsetTop": "12px",
            "offsetStart": "50px",
            "justifyContent": "center",
            "alignItems": "center"
          }
        ],
        "width": "167px",
        "height": "43px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": text,
            "size": "9px",
            "color": "FFFFFF", 
            "lineSpacing": "2px",
            "wrap": True, 
            "action": 
              {
                "type": "uri",
                "label": "action",
                "uri": "https://line.me/ti/p/~zul.1.02"
             }
          }
        ],
        "paddingStart": "18px",
        "paddingEnd": "5px",
        "paddingTop": "2px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/ctfkH8f/hlth-adt-menu-f.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "255:55",
            "aspectMode": "cover"
          },
          {
            "type": "image",
            "url": "https://i.ibb.co/rs843XQ/hlth-adt-menu-anim-f.png",
            "align": "center",
            "size": "full",
            "aspectRatio": "1665:207",
            "aspectMode": "cover",
            "animated": True,
            "position": "absolute"
          }
        ],
        "width": "167px",
        "height": "18px"
      }
    ],
    "paddingAll": "0px",
    "height": "100%",
    "backgroundColor": "#000000"
  }
}  
}    
    time.sleep(0.5)
    sendTemplate(to, data)    

def sendTextTemplate200(to, text):
    data = {
        "type": "text",
        "text": text,
        "sentBy": {
            "linkUrl": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6",
            "label": "TEAM TERMUX",            
            "iconUrl": "https://i.ibb.co.com/bNBqP5T/07-39-38-9550611aa1fd2611b1d6f286a4e812bf.gif",            
        }
    }
    time.sleep(0.5)
    sendTemplate(to, data)    
    
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
    
def pretyPrintJson(djson):
        print(json.dumps(djson, indent=4, sort_keys=True))   
    
def runtime2(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Menit %02d Detik' % (mins, secs)

def flex3(to, text):
    contact = cl.getProfile()
    mids = [contact.mid]
    status = cl.getContact(mid)
    scover = cl.getProfileCoverURL(mid)
    time.sleep(1)
    data = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/pJvKcvX/ezgif-com-gif-maker-19.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1", "animated": True }, { "type": "image", "url": "https://i.ibb.co.com/QJ230By/ezgif-com-gif-maker-18.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1", "animated": True, "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": text, "size": "7px", "color": "#00ff00", "align": "center", "wrap": True } ], "position": "absolute", "width": "139.5px", "height": "17.5px", "cornerRadius": "2px", "offsetTop": "9px", "offsetStart": "10.5px" }, { "type": "image", "url": "https://i.postimg.cc/J48BmhBc/1663946377912.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1", "animated": True, "position": "absolute" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6" } } }
    sendTemplate(to, data)

def flexvian(to, text):
    contact = cl.getProfile()
    mids = [contact.mid]
    status = cl.getContact(mid)
    scover = cl.getProfileCoverURL(mid)
    time.sleep(1)
    data = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/pJvKcvX/ezgif-com-gif-maker-19.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1", "animated": True }, { "type": "image", "url": "https://i.ibb.co.com/QJ230By/ezgif-com-gif-maker-18.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1", "animated": True, "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": text, "size": "7px", "color": "#00ff00", "align": "center", "wrap": True } ], "position": "absolute", "width": "139.5px", "height": "17.5px", "cornerRadius": "2px", "offsetTop": "9px", "offsetStart": "10.5px" }, { "type": "image", "url": "https://i.postimg.cc/J48BmhBc/1663946377912.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1", "animated": True, "position": "absolute" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6" } } }
    sendTemplate(to, data)

def flex2(to, text):
    contact = cl.getProfile()
    mids = [contact.mid]
    status = cl.getContact(mid)
    scover = cl.getProfileCoverURL(mid)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    time.sleep(1)
    data = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/pJvKcvX/ezgif-com-gif-maker-19.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1", "animated": True }, { "type": "image", "url": "https://i.ibb.co.com/QJ230By/ezgif-com-gif-maker-18.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1", "animated": True, "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": text, "size": "7px", "color": "#00ff00", "align": "center", "wrap": True } ], "position": "absolute", "width": "139.5px", "height": "17.5px", "cornerRadius": "2px", "offsetTop": "9px", "offsetStart": "10.5px" }, { "type": "image", "url": "https://i.postimg.cc/J48BmhBc/1663946377912.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1", "animated": True, "position": "absolute" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6" } } }
    sendTemplate(to, data)         

def flextext(to, text):
    contact = cl.getProfile()
    mids = [contact.mid]
    status = cl.getContact(mid)
    scover = cl.getProfileCoverURL(mid)
    time.sleep(1)
    data = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "carousel", "contents": [ { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/pnTLnnn/ezgif-com-gif-maker-18.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1", "animated": True, "backgroundColor": "#000000" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "SELFBOT LINE", "size": "7px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "115px", "height": "10px", "offsetTop": "21.5px", "offsetStart": "22px" }, { "type": "text", "text": text, "size": "8px", "color": "#00ff00", "wrap": True, "offsetStart": "8px" }, { "type": "image", "url": "https://i.ibb.co.com/pnTLnnn/ezgif-com-gif-maker-18.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1", "animated": True, "backgroundColor": "#000000" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "LINE CORPOROTATION", "size": "7px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "115px", "height": "10px", "offsetStart": "22px", "offsetBottom": "21.5px" } ], "paddingAll": "0px", "backgroundColor": "#000000" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6" } } ] } }
    sendTemplate(to, data)                  

def modflex(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    contact = cl.getContact(mid)
    time.sleep(1)
    data = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/pJvKcvX/ezgif-com-gif-maker-19.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:4" }, { "type": "image", "url": "https://i.ibb.co.com/Fz5jYwQ/ezgif-com-gif-maker-18.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:4", "animated": True, "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "USER : {}".format(contact.displayName), "size": "8px", "color": "#00ffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "129px", "height": "12px", "offsetTop": "82px", "offsetStart": "18px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%H:%M:%S'), "size": "8px", "color": "#00ffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "82px", "height": "12px", "offsetTop": "58px", "offsetEnd": "12px" }, { "type": "image", "url": "https://i.postimg.cc/J48BmhBc/1663946377912.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:4", "animated": True, "position": "absolute" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6" } } }
    sendTemplate(to, data)
def modflex(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
  "type": "bubble",
  "size": "micro",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": "https://s20.directupload.net/images/210728/gtqphkhj.png",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "1:2",
        "animated": True
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://s20.directupload.net/images/210729/k8a9aejc.png",
            "size": "full",
            "aspectRatio": "1:2",
            "aspectMode": "cover",
            "animated": True
          }
        ],
        "position": "absolute",
        "width": "158px",
        "height": "318px",
        "backgroundColor": "#000000",
        "cornerRadius": "10px",
        "offsetTop": "1px",
        "offsetStart": "1px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/JBk6NY0/ezgif-com-gif-maker-12.png",
            "size": "full",
            "aspectRatio": "1:2",
            "aspectMode": "cover",
            "animated": True
          }
        ],
        "position": "absolute",
        "width": "100px",
        "height": "30px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "6px",
        "offsetTop": "5px",
        "offsetEnd": "4px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": " " + datetime.strftime(timeNow,'%H:%M:%S'),
            "size": "12px",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "6px"
          }
        ],
        "position": "absolute",
        "width": "50px",
        "height": "30px",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "6px",
        "offsetTop": "5px",
        "offsetStart": "4px",
        "backgroundColor": "#000000"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/NS7RFxN/ahmadpekok.png",
            "size": "full",
            "aspectRatio": "1:2",
            "aspectMode": "cover",
            "animated": True
          }
        ],
        "position": "absolute",
        "width": "150px",
        "height": "250px",
        "offsetTop": "60px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "ADMIN",
            "size": "10px",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "4px"
          }
        ],
        "position": "absolute",
        "height": "20px",
        "width": "80px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "4px",
        "offsetTop": "50px",
        "offsetEnd": "10px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "BANNED",
            "size": "10px",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "2px"
          }
        ],
        "position": "absolute",
        "height": "20px",
        "width": "80px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "4px",
        "offsetTop": "75px",
        "offsetEnd": "10px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "CREATOR",
            "size": "10px",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "2px"
          }
        ],
        "position": "absolute",
        "height": "20px",
        "width": "80px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "4px",
        "offsetTop": "100px",
        "offsetEnd": "10px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": text,
            "size": "10px",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "2px"
          }
        ],
        "position": "absolute",
        "height": "20px",
        "width": "80px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "4px",
        "offsetTop": "125px",
        "offsetEnd": "10px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "MEDIA",
            "size": "10px",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "2px"
          }
        ],
        "position": "absolute",
        "height": "20px",
        "width": "80px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "2px",
        "offsetTop": "150px",
        "offsetEnd": "10px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "PROTECT",
            "size": "10px",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "2px"
          }
        ],
        "position": "absolute",
        "height": "20px",
        "width": "80px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "4px",
        "offsetTop": "175px",
        "offsetEnd": "10px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "SETTING",
            "size": "10px",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "2px"
          }
        ],
        "position": "absolute",
        "height": "20px",
        "width": "80px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "4px",
        "offsetTop": "200px",
        "offsetEnd": "10px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "STATUS",
            "size": "10px",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "2px"
          }
        ],
        "position": "absolute",
        "height": "20px",
        "width": "80px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "4px",
        "offsetTop": "225px",
        "offsetEnd": "10px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "TRANSLATE",
            "size": "10px",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "2px"
          }
        ],
        "position": "absolute",
        "height": "20px",
        "width": "80px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "4px",
        "offsetTop": "250px",
        "offsetEnd": "10px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "HELP JS",
            "size": "10px",
            "color": "#ffffff",
            "align": "center",
            "offsetTop": "2px"
          }
        ],
        "position": "absolute",
        "height": "20px",
        "width": "80px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "4px",
        "offsetTop": "275px",
        "offsetEnd": "10px"
      }
    ],
    "paddingAll": "0px",
    "cornerRadius": "10px"
  },
  "action": {
    "type": "uri",
    "label": "action",
    "uri": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6"
  }
}
}
    sendTemplate(to, data)
#def modflex(to, text):
    #tz = pytz.timezone("Asia/Jakarta")
   # timeNow = datetime.now(tz=tz)
   # contact = cl.getContact(mid)
   # time.sleep(1)
   # data = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/pJvKcvX/ezgif-com-gif-maker-19.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:4" }, { "type": "image", "url": "https://i.ibb.co.com/Fz5jYwQ/ezgif-com-gif-maker-18.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:4", "animated": True, "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "USER : {}".format(contact.displayName), "size": "8px", "color": "#00ffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "129px", "height": "12px", "offsetTop": "82px", "offsetStart": "18px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%H:%M:%S'), "size": "8px", "color": "#00ffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "82px", "height": "12px", "offsetTop": "58px", "offsetEnd": "12px" }, { "type": "image", "url": "https://i.postimg.cc/J48BmhBc/1663946377912.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:4", "animated": True, "position": "absolute" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6" } } }
   # sendTemplate(to, data)

def sendAhmad(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    contact = cl.getContact(mid)
    time.sleep(1)
    data = {"type": "flex","altText": "TEAM TERMUX ","contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/pJvKcvX/ezgif-com-gif-maker-19.png", "size": "full", "aspectMode": "cover", "aspectRatio": "2:1", "animated": True }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image","url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),"size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "40px", "height": "40px", "offsetTop": "12px", "offsetEnd": "13.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/GdyLZ5d/ezgif-com-gif-maker-69.png", "size": "100px", "aspectRatio": "2:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "100px", "height": "40px", "offsetStart": "8px" }, { "type": "image", "url": "https://i.ibb.co.com/C0yjDzt/ezgif-com-gif-maker-21.png", "size": "full", "aspectMode": "cover", "aspectRatio": "2:1", "animated": True, "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%H:%M:%S'), "size": "7px", "color": "#00ffff", "align": "center" } ], "position": "absolute", "width": "94px", "height": "11px", "offsetTop": "13px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%H:%M:%S'), "size": "7px", "color": "#00ffff", "align": "center" } ], "position": "absolute", "width": "94px", "height": "11px", "offsetTop": "26.5px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(contact.displayName), "size": "7px", "color": "#00ffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "131.5px", "height": "11px", "offsetBottom": "15.5px", "offsetEnd": "13.5px" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6" } } }
    sendTemplate(to, data)

#=====DEF HELP MENU =======
def sendTextTemplate25(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "size": "lg",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
            "offsetTop": "30px",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "H E L P",
                "size": "lg",
                "color": "#ff0000",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "28px",
                "offsetTop": "2px"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "30px",
            "borderWidth": "1px",
            "borderColor": "#ffffff"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "md",
                "color": "#ff0000",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "30px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "offsetTop": "390px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xs",
                "color": "#00ffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
              }
            ],
            "position": "absolute",
            "offsetTop": "34px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "height": "420px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "15px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)
    
def sendTextTemplate26(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "size": "lg",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
            "offsetTop": "30px",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "H E L P",
                "size": "lg",
                "color": "#ff0000",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "28px",
                "offsetTop": "2px"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "30px",
            "borderWidth": "1px",
            "borderColor": "#ffffff"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX",
                "size": "md",
                "color": "#ff0000",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "15px"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "30px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "offsetTop": "390px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xs",
                "color": "#00ffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
              }
            ],
            "position": "absolute",
            "offsetTop": "34px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "height": "420px",
        "backgroundColor": "#000000",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "15px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)
    
def sendTextTemplate903(to, text):
    warna1 = ("#ff00c8","#00daff","#A8FF00","#00ff00","#ffff00","#0000ff","#ff00ff","#00FFFF","#800000","#FF7F00","#BF00FF","#808000","#778899","#40E0D0","#708090","#778899")
    warnanya1 = random.choice(warna1)
    data = {
                           "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/5nwSnJd/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/3zMNx9J/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "position": "absolute",
                    "offsetStart": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co.com/3zMNx9J/ezgif-com-gif-maker-1.png",
                        "size": "xxs",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "40px",
                    "height": "50px",
                    "offsetStart": "60px"
                  }
                ],
                "position": "absolute",
                "width": "160px",
                "height": "50px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/3zMNx9J/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "80px",
                "height": "50px",
                "offsetTop": "0px",
                "offsetStart": "80px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "0px",
                    "offsetStart": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co.com/cNk3TrB/ezgif-com-gif-maker-2.png",
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "10px",
                    "height": "10px",
                    "borderWidth": "1px",
                    "borderColor": "#ffffff",
                    "offsetTop": "4px",
                    "offsetStart": "5px",
                    "cornerRadius": "100px"
                  }
                ],
                "position": "absolute",
                "width": "140px",
                "height": "20px",
                "backgroundColor": "#66669999",
                "borderWidth": "1px",
                "borderColor": "#ffff00",
                "cornerRadius": "5px",
                "offsetTop": "0px",
                "offsetStart": "7px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "𝙎𝙆_𝙏𝙀𝘼𝙈",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "15px",
                "offsetTop": "26px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "40px",
            "backgroundColor": warnanya1,
            "borderWidth": "1px",
            "borderColor": "#ffff00",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "height": "44px",
        "cornerRadius": "12px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)
    
def sendTextTemplate901(to, text):
    data = {
                           "type": "flex",
                                       "altText": "TEAM TERMUX",            
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/5nwSnJd/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/r4NMzr2/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "position": "absolute",
                    "offsetStart": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co.com/r4NMzr2/ezgif-com-gif-maker-1.png",
                        "size": "xxs",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "40px",
                    "height": "50px",
                    "offsetStart": "60px"
                  }
                ],
                "position": "absolute",
                "width": "160px",
                "height": "50px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/r4NMzr2/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "80px",
                "height": "50px",
                "offsetTop": "0px",
                "offsetStart": "80px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "0px",
                    "offsetStart": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co.com/cNk3TrB/ezgif-com-gif-maker-2.png",
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "10px",
                    "height": "10px",
                    "borderWidth": "1px",
                    "borderColor": "#ffffff",
                    "offsetTop": "4px",
                    "offsetStart": "5px",
                    "cornerRadius": "100px"
                  }
                ],
                "position": "absolute",
                "width": "140px",
                "height": "20px",
                "backgroundColor": "#66669999",
                "borderWidth": "1px",
                "borderColor": "#A8FF00",
                "cornerRadius": "5px",
                "offsetTop": "0px",
                "offsetStart": "7px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "𝙎𝙆_𝙏𝙀𝘼𝙈",            
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "15px",
                "offsetTop": "26px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "40px",
            "backgroundColor": "#A8FF00",
            "borderWidth": "1px",
            "borderColor": "#ffff00",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "height": "44px",
        "cornerRadius": "12px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)    

def sendTextTemplate006(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "bubble",
  "size": "micro",
  "hero": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "animated": True,
        "url": "https://i.ibb.co.com/PC0GrXZ/ezgif-com-gif-maker-1.png",
        "size": "full",
        "gravity": "top",
        "aspectRatio": "2:2",
        "aspectMode": "cover",
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6chJwhf/ezgif-com-gif-maker.png",
                "size": "full",
                "aspectRatio": "6:4",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "100px",
            "offsetTop": "0px",
            "offsetStart": "0px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/BKJwN57/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "8:2",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "50px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "50px",
            "offsetTop": "98px",
            "borderWidth": "1px",
            "borderColor": "#ffffff"
          }
        ],
        "position": "absolute",
        "width": "150px",
        "height": "140px",
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "5px",
        "offsetTop": "5px",
        "offsetStart": "5px"
      }
    ],
    "height": "150px"
  },
  "action": {
    "type": "uri",
    "label": "action",
    "uri": "http://line.me/ti/p/~zul.1.02",
  }
}
}
    time.sleep(0.5)
    sendTemplate(to, data)    
    
def sendTextTemplate010(to, text):
    data = {
                                "type": "flex",
                                "altText": "TEAM TERMUX",
                                "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/z6LVpj1/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/9bLBFf0/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "2:6",
                "aspectMode": "cover",
                "offsetTop": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                    "size": "xl",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "-23px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "n\♻️ An\♻️ B", #1
                    "size": "xxs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "102px",
                "height": "300px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "2px",
                "offsetTop": "22px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "SOAK KILLER TEAM",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "4px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "325px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "350px",
            "borderWidth": "2px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/z6LVpj1/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/9bLBFf0/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "2:6",
                "aspectMode": "cover",
                "offsetTop": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                    "size": "xl",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "-22px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "n\♻️ An\♻️ B", #2
                    "size": "xxs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "102px",
                "height": "300px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "2px",
                "offsetTop": "22px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "SOAK KILLER TEAM",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "4px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "325px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "350px",
            "borderWidth": "2px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/z6LVpj1/ezgif-com-gif-maker.png",
            "size": "full",
            "gravity": "top",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/9bLBFf0/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "2:6",
                "aspectMode": "cover",
                "offsetTop": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                    "size": "xl",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "-22px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "n\♻️ An\♻️ B", #3
                    "size": "xxs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "102px",
                "height": "300px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "2px",
                "offsetTop": "22px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "SOAK KILLER TEAM",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "4px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "325px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "350px",
            "borderWidth": "2px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ]
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/z6LVpj1/ezgif-com-gif-maker.png",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/9bLBFf0/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "2:6",
                "aspectMode": "cover",
                "offsetTop": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                    "size": "xl",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "-22px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "n\♻️ An\♻️ B", #4
                    "size": "xxs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "102px",
                "height": "300px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "2px",
                "offsetTop": "22px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "SOAK KILLER TEAM",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "4px"
                  }
                ],
                "position": "absolute",
                "width": "102px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "325px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "350px",
            "borderWidth": "2px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ]
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/z6LVpj1/ezgif-com-gif-maker.png",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/9bLBFf0/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "2:6",
                "aspectMode": "cover",
                "offsetTop": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                    "size": "xl",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "-22px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "n\♻️ An\♻️ B", #5
                    "size": "xxs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "102px",
                "height": "300px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "22px",
                "offsetStart": "2px",
                "cornerRadius": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "SOAK KILLER TEAM",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "4px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "325px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "350px",
            "borderWidth": "2px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ]
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/z6LVpj1/ezgif-com-gif-maker.png",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/9bLBFf0/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "2:6",
                "aspectMode": "cover",
                "offsetTop": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/6tQK6Y2/ezgif-com-gif-maker.png",
                    "size": "xl",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "-22px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "n\♻️ An\♻️ B", #6
                    "size": "xxs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "102px",
                "height": "300px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "2px",
                "offsetTop": "22px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "SOAL KILLER TEAM",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "4px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "325px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "350px",
            "borderWidth": "2px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ]
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/z6LVpj1/ezgif-com-gif-maker.png",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/9bLBFf0/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "2:6",
                "aspectMode": "cover",
                "offsetTop": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "-22px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "n\♻️ An\♻️ B", #7
                    "size": "xxs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "102px",
                "height": "300px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "2px",
                "offsetTop": "22px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "SOAK KILLER TEAM",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "4px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "325px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "350px",
            "borderWidth": "2px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ]
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/z6LVpj1/ezgif-com-gif-maker.png",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/9bLBFf0/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "2:6",
                "aspectMode": "cover",
                "offsetTop": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                    "size": "xl",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "-22px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "n\♻️ An\♻️ B", #8
                    "size": "xxs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "102px",
                "height": "300px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "2px",
                "offsetTop": "22px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "SOAK KILLER TEAM",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "4px"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "offsetTop": "325px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "350px",
            "borderWidth": "2px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ]
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)

def sendTextTemplate000(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/HBRGznW/ezgif-com-gif-to-apng.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "3:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/ZHD7bJh/1697899790267.jpg",
                    "size": "5xl",
                    "aspectRatio": "6:3",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "160px",
                "height": "75px",
                "offsetTop": "10px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                    "size": "full",
                    "aspectRatio": "2:3",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "44px",
                "height": "50px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "20px",
                "offsetStart": "10px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/rdT34Rs/ezgif-com-gif-to-apng.png",
                    "size": "5xl",
                    "aspectRatio": "8:5",
                    "aspectMode": "cover",
                    "animated": True,
                  }
                ],
                "position": "absolute",
                "width": "156px",
                "height": "86px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/k1crQmp/ezgif-com-gif-to-apng-1.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "animated": True,
                  }
                ],
                "position": "absolute",
                "width": "4px",
                "height": "4px",
                "cornerRadius": "100px",
                "offsetTop": "5px",
                "offsetStart": "60px",
                "borderWidth": "1px",
                "borderColor": "#000000"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "👥:{}".format(cl.getContact(mid).displayName),
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  },
                  {
                    "type": "text",
                    "text": text,
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  },
                  {
                    "type": "text",
                    "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M'),
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "98px",
                "height": "22px",
                "offsetTop": "55px",
                "offsetStart": "55px",
                "backgroundColor": "#000000",
                "cornerRadius": "2px",
                "borderWidth": "1px",
                "borderColor": "#ffffff"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "SELFBOOT V-23 ",
                    "size": "5px",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "5px"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "20px",
                "offsetTop": "80px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "86px",
            "borderWidth": "1px",
            "borderColor": "#000000",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "RESPON SB ",
                "size": "8px",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/k1crQmp/ezgif-com-gif-to-apng-1.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "animated": True,
                  }
                ],
                "position": "absolute",
                "width": "4px",
                "height": "4px",
                "cornerRadius": "100px",
                "offsetTop": "2px",
                "offsetStart": "52px"
              }
            ],
            "position": "absolute",
            "width": "62px",
            "height": "12px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "4px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "height": "90px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)    
    
def sendTextTemplate002(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/r4NMzr2/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
            "flex": 1,
            "offsetTop": "-10px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/37tfY5s/ezgif-com-gif-maker-1.png",
                "size": "full",
                "aspectRatio": "2:6",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "400px",
            "offsetTop": "400px",
            "offsetStart": "0px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "30px",
                "offsetStart": "5px",
                "wrap": True,
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                    "size": "md",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "-22px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "18px",
                    "height": "18px",
                    "borderWidth": "1px",
                    "borderColor": "#ffffff",
                    "cornerRadius": "2px",
                    "offsetTop": "0px",
                    "offsetStart": "1px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "18px",
                    "height": "18px",
                    "borderWidth": "1px",
                    "borderColor": "#ffffff",
                    "cornerRadius": "2px",
                    "offsetTop": "0px",
                    "offsetEnd": "1px"
                  }
                ],
                "position": "absolute",
                "width": "140px",
                "height": "20px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "5px",
                "offsetTop": "1px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": " TEAM TERMUX",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "25px"
                  }
                ],
                "position": "absolute",
                "width": "140px",
                "height": "20px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "5px",
                "offsetTop": "763px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "146px",
            "height": "786px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "flex": 1,
        "spacing": "xl",
        "backgroundColor": "#000000",
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px",
        "height": "800px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)      

def sendTextTemplate100(to, text):
    data = {
                                "type": "flex",
                                "altText": "TEAM TERMUX",
                                "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/59j6Jt4/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "4:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/KyN30hn/ezgif-com-gif-maker-3.png",
                "size": "5xl",
                "aspectRatio": "8:6",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/ZG4jqV0/ezgif-com-gif-maker-1.png",
                    "size": "full",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "2px"
                  }
                ],
                "position": "absolute",
                "width": "154px",
                "height": "60px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [],
                "position": "absolute",
                "width": "154px",
                "height": "84px",
                "backgroundColor": "#77773333"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/z4gYmC3/ezgif-com-gif-maker-2.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "20px",
                    "height": "20px",
                    "offsetTop": "5px",
                    "offsetStart": "5px",
                    "cornerRadius": "100px"
                  }
                ],
                "position": "absolute",
                "width": "30px",
                "height": "30px",
                "cornerRadius": "100px",
                "offsetTop": "51px",
                "offsetStart": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "118px",
                "height": "65px",
                "offsetTop": "40px",
                "offsetStart": "12px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "84px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "height": "90px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    sendTemplate(to, data) 
   
def sendTextTemplate15(to, text):
    data = {
            "type": "flex",
            "altText": "TEAM TERMUX",
            "contents":{
  "type": "bubble",
  "size": "micro",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "text",
            "text":  text,
            "size": "xxs",
            "wrap": True,
            "weight": "regular",
            "offsetStart": "3px"
          }
        ],
        "margin": "xs",
        "spacing": "md",
        "backgroundColor": "#000000"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "soak ᴋɪʟʟᴇʀ",
            "align": "center",
            "size": "xs"
          }
        ],
        "paddingAll": "2px",
        "backgroundColor": "#ffffff",
        "margin": "xs"
      }
    ],
    "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": "#FF0000",
    "cornerRadius": "10px",
    "spacing": "xs"
  },
  "styles": {
    "body": {
      "backgroundColor": "#ffff00"
    }
  }
}
}
    time.sleep(0.5)
    sendTemplate(to, data)    

def sendTextTemplate(to, text):
    data = {
            "type": "flex",
            "altText": "TEAM TERMUX",
            "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    }
  },
  "type": "bubble",
  "size": "micro",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "contents": [
             {
            "type": "separator",
            "color": "#b1fc03"            
            },
            {
            "contents": [
            {
            "type": "separator",
            "color": "#b1fc03" 
   },
   {
            "text": text,
           "size": "xxs",
           "color": "#ffffff",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#b1fc03"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#b1fc03"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    time.sleep(0.5)
    sendTemplate(to, data)
        
def sendTextTemplate5(to, text):
    data = {
        "type": "text",
        "text": text,
        "sentBy": {
            "label": "TEAM TERMUX",
            "iconUrl": "https://i.ibb.co.com/bNBqP5T/07-39-38-9550611aa1fd2611b1d6f286a4e812bf.gif",            
            "linkUrl": "http://line.me/ti/p/~zul.1.02"
        }
    }
    time.sleep(0.5)
    sendTemplate(to, data)    

def sendTextTemplate28(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#000000" #999999"
    },
    "footer": {
      "backgroundColor": "#ff0000" #0000" #cc9999"
    }
  },
  "type": "bubble",
  "size": "micro",
      "body": {
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#9d2933"            
      },
      {
        "type": "separator",
        "color": "#9d2933"            
      },
      {         
         "contents": [
          {   
          "type": "separator",
          "color": "#9d2933"            
            },
           {
            "contents": [
              {
            "text": " sᴇᴛᴛɪɴɢ ʙᴏᴛ ᴏɴ/ᴏғғ ", #ᴘᴇʟᴀᴋᴜ:{} ".format(cl.getContact(mid).displayName),
           "size": "xxs",
           "align": "center",
           "color": "#ffffff",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#9d2933"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#9d2933"
         },
         {
       "contents": [             
         { 
           "type": "separator",
           "color": "#9d2933"
            },
           {
            "contents": [
              {
          "text": text,
           "size": "xxs",
          # "align": "center",
           "color": "#ffffff",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#9d2933"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#9d2933"
         },
         {
       "contents": [             
          {
            "type": "separator",
            "color": "#9d2933"
            },
             {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/2PzJWmL/ezgif-com-gif-maker.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/2PzJWmL/ezgif-com-gif-maker.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~zul.1.02",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/2PzJWmL/ezgif-com-gif-maker.png", #camerahttps://i.ibb.co/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/camera/"
          },
            "flex": 1
            },
          {
          "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/2PzJWmL/ezgif-com-gif-maker.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/__Roy_soak",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/2PzJWmL/ezgif-com-gif-maker.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/2PzJWmL/ezgif-com-gif-maker.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#9d2933"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#9d2933"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    time.sleep(0.5)
    sendTemplate(to, data)

def sendTextTemplate1(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/2yptfqj/ezgif-com-gif-to-apng.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "6:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/DYT9yGS/ezgif-com-gif-to-apng-3.png",
                "size": "15px",
                "aspectRatio": "6:2",
                "aspectMode": "cover",
                "animated": True,
              }
            ],
            "position": "absolute",
            "width": "80px",
            "height": "15px",
            "offsetTop": "12px",
            "offsetStart": "60px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "6px",
                "color": "#ff00ff",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "10px",
            "offsetTop": "1px",
            "offsetStart": "4px"
          }
        ],
        "paddingAll": "0px",
        "height": "20px",
        "cornerRadius": "15px",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02",
        }
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)

def sendTextTemplate2(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "??𝘾𝘿_𝘽??𝙏𝙕",
                                        "contents": {
  "styles": {"body": {
            "backgroundColor": "#000000"},"footer": {"backgroundColor": "#000000"}},
            "type": "bubble","size": "micro","body": {"contents": [{"contents": [{
             "type": "separator","color": "#c20c27"},{"type": "separator","color": "#c20c27"
              },{"contents": [{   "type": "separator","color": "#c20c27"
              },{"contents": [
              {"text": text, "size": "xxs",
              "color": "#ffffff","wrap": True,"weight": "bold","type": "text"
              }],"type": "box","spacing": "md","layout": "vertical"},{
              "type": "separator","color": "#c20c27"}],"type": "box","layout": "horizontal"},{"type": "separator","color": "#c20c27"},{
              "contents": [
          {
            "type": "separator",
            "color": "#c20c27"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co.com/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~zul.1.02",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "url": "https://i.ibb.co.com/kSMSnWn/20190427-191235.png", #camerahttps://i.ibb.co/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/camera/"
          },
            "flex": 1
            },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/__Roy_Soak",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co.com/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co.com/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#c20c27"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#c20c27"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    time.sleep(0.5)
    sendTemplate(to, data)
    
def sendTextTemplate23(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#000000" #999999"
    },
    "footer": {
      "backgroundColor": "#000000" #0000" #cc9999"
    }
  },
  "type": "bubble",
  "size": "micro",
      "body": {
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#9d2933"            
      },
      {
        "type": "separator",
        "color": "#9d2933"      
      },
      {         
         "contents": [
          {   
          "type": "separator",
          "color": "#9d2933"
            },
           {
            "contents": [
              {
            "text": " ᴄᴇᴋ ɢʀᴏᴜᴘ_ғʀɪᴇɴᴅ ", #ᴘᴇʟᴀᴋᴜ:{} ".format(cl.getContact(mid).displayName),
           "size": "xxs",
           "align": "center",
           "color": "#ffffff",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#9d2933"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#9d2933"
         },
         {
       "contents": [
         { 
           "type": "separator",
           "color": "#9d2933"
            },
           {
            "contents": [
              {
          "text": text,
           "size": "xxs",
          # "align": "center",
           "color": "#ffffff",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#9d2933"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#9d2933"
         },
         {
       "contents": [
          {
            "type": "separator",
            "color": "#9d2933"
            },
             {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/2PzJWmL/ezgif-com-gif-maker.png",            
            "size": "xl",
            "action": {
            "type": "uri",            
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
          "animated": True,
            "url": "https://i.ibb.co.com/2PzJWmL/ezgif-com-gif-maker.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line            
            "size": "xl",
            "action": {
            "type": "uri",            
            "uri": "http://line.me/ti/p/~zul.1.02",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/2PzJWmL/ezgif-com-gif-maker.png", #camerahttps://i.ibb.co/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone            
            "size": "xl",
            "action": {
            "type": "uri",            
            "uri": "line://nv/camera/"
          },
            "flex": 1
            },
          {
          "type": "image",
           "animated": True,
            "url": "https://i.ibb.co.com/2PzJWmL/ezgif-com-gif-maker.png", #smule            
            "size": "xl",
            "action": {
            "type": "uri",            
            "uri": "Https://smule.com/__Roy_Soak",
            },         
            "flex": 1          
          },
          {
          "type": "image",
           "animated": True,
            "url": "https://i.ibb.co.com/2PzJWmL/ezgif-com-gif-maker.png",            
            "size": "xl",
            "action": {
            "type": "uri",            
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/2PzJWmL/ezgif-com-gif-maker.png",            
            "size": "xl",
            "action": {
            "type": "uri",         
            "uri": "line://nv/timeline"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#9d2933"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#9d2933"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    time.sleep(0.5)
    sendTemplate(to, data)
      
def sendTextTemplate00(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/y8qYcrc/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/ykmxR0P/ezgif-com-gif-maker.png",
                "size": "xxl",
                "aspectRatio": "6:2",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "140px",
                "height": "15px",
                "offsetTop": "0px",
                "offsetStart": "20px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "44px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "height": "50px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)
    
def sendTextTemplate011(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "bubble",
  "size": "micro",
  "hero": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "animated": True,
        "url": "https://i.ibb.co.com/0BhBrKQ/ezgif-com-gif-maker.png",
        "size": "full",
        "aspectRatio": "2:3",
        "aspectMode": "cover",
        "gravity": "top"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/FxpT0x8/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectRatio": "2:2",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/th0QRRY/ezgif-com-gif-maker.png",
                "size": "lg",
                "aspectRatio": "8:1",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "20px",
            "backgroundColor": "#ffffff",
            "offsetTop": "54px",
            "borderWidth": "1px",
            "borderColor": "#bbcfcc",
            "offsetStart": "0px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "50px",
            "offsetTop": "0px",
            "offsetStart": "0px"
          }
        ],
        "position": "absolute",
        "width": "154px",
        "height": "74px",
        "borderWidth": "1px",
        "borderColor": "#bbcfcc",
        "cornerRadius": "8px",
        "offsetTop": "2px",
        "offsetStart": "2px"
      }
    ],
    "height": "80px",
    "borderWidth": "1px",
    "borderColor": "#bbcfcc",
    "cornerRadius": "10px"
  },
  "action": {
    "type": "uri",
    "label": "action",
    "uri": "http://line.me/ti/p/~zul.1.02",
  }
}
}
    time.sleep(0.5)
    sendTemplate(to, data)   
    
def sendTextTemplate100(to, text):    
    data = {
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/59j6Jt4/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "4:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/KyN30hn/ezgif-com-gif-maker-3.png",
                "size": "5xl",
                "aspectRatio": "8:6",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/ZG4jqV0/ezgif-com-gif-maker-1.png",
                    "size": "full",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "2px"
                  }
                ],
                "position": "absolute",
                "width": "154px",
                "height": "60px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [],
                "position": "absolute",
                "width": "154px",
                "height": "84px",
                "backgroundColor": "#77773333"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/z4gYmC3/ezgif-com-gif-maker-2.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "20px",
                    "height": "20px",
                    "offsetTop": "5px",
                    "offsetStart": "5px",
                    "cornerRadius": "100px"
                  }
                ],
                "position": "absolute",
                "width": "30px",
                "height": "30px",
                "cornerRadius": "100px",
                "offsetTop": "51px",
                "offsetStart": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "118px",
                "height": "65px",
                "offsetTop": "15px",
                "offsetStart": "28px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "84px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "height": "90px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)    
    
   #Def Musik

def sendTextTemplate10(to, text):
    data = {
                                "type": "flex",
                                "altText": "TEAM TERMUX",
                                "contents": {
"type": "carousel",
"contents": [
{
"type": "bubble",
"size": "nano",
"body": {
"backgroundColor": "#00ff00",
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 1
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"size": "full",
"aspectMode": "cover",
"aspectRatio": "4:5",
"gravity": "bottom",
"action": {
"uri": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f",
"type": "uri",
}
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u9e7b95e0fe30d1b8a23a6c83e73a5d8f",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "Hiburan",
"align": "center",
"color": "#000000",
"weight": "bold",
"size": "xxs",
"weight": "bold",
"offsetTop": "1px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "9px",
"backgroundColor": "#ffd700",
"offsetStart": "7px",
"height": "15px",
"width": "45px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://thumbs.gfycat.com/UnkemptWhiteKakapo-max-1mb.gif",
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://wa.me/6281357942356",
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "92px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://thumbs.gfycat.com/UnkemptWhiteKakapo-max-1mb.gif",
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://joox.com"
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "67px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
"size": "xl",
"action": {
"type": "uri",
"uri": "Https://smule.com/__Roy_Soak",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/ZHtFDts/20190427-185307.png",
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/chat",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
"size": "full",
"action": {
"type": "uri",
"uri": "http://line.me/ti/p/~zul.1.02",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
"size": "full",
"action": {
"type": "uri",
"uri": "https://youtube.com",
},
"flex": 0
}
],
"position": "absolute",
"offsetTop": "25px",
"offsetStart": "5px",
"height": "180px",
"width": "25px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "🕙 "+ datetime.strftime(timeNow,'%H:%M:%S'),
"weight": "bold",
"color": "#ffffff",
#"align": "center",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "98px",
"backgroundColor": "#ff0000",
"offsetStart": "50px",
"height": "16px",
"width": "63px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": text, #📆 "+ datetime.strftime(timeNow,'%Y-%m-%d'),
"weight": "bold",
"color": "#ffffff",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "115px",
"backgroundColor": "#0000ff",
"offsetStart": "33px",
"height": "14px",
"width": "80px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "TEAM TERMUX",
"weight": "bold",
"color": "#00ff00",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "130px",
#"backgroundColor": "#33ffff",
"offsetStart": "8px",
"height": "50px",
"width": "110px"
}
],
#"backgroundColor": "#",
"paddingAll": "0px"
}
},
]
}
}
    sendTemplate(to, data)
    
def sendTextTemplate500(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/WfHJw7r/ezgif-com-gif-maker-2.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "4:4",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/TcM9Cy4/ezgif-com-gif-maker.png",
                "size": "full",
                "aspectRatio": "6:3",
                "aspectMode": "cover",
                "offsetTop": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "5px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "15px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "2px",
                "offsetTop": "0px",
                "offsetStart": "1px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "44px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/TgR7PYb/ezgif-com-gif-maker-1.png",
                "size": "full",
                "aspectRatio": "3:2",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "50px"
          }
        ],
        "paddingAll": "0px",
        "height": "50px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)       
    
def sendTextTemplate600(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/DL9SzvX/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/DL9SzvX/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "8:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co.com/vQygHZ0/ezgif-com-gif-maker.png",
                        "size": "xl",
                        "aspectRatio": "8:2",
                        "aspectMode": "cover",
                        "offsetTop": "-8px"
                      }
                    ],
                    "position": "absolute",
                    "width": "146px",
                    "height": "18px",
                    "backgroundColor": "#b08800",
                    "borderWidth": "1px",
                    "borderColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "22px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "1px",
                "offsetStart": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/DL9SzvX/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:3",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                        "size": "full",
                        "aspectMode": "cover",
                        "aspectRatio": "2:3"
                      }
                    ],
                    "position": "absolute",
                    "width": "58px",
                    "height": "78px",
                    "borderWidth": "1px",
                    "borderColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "62px",
                "height": "82px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "24px",
                "offsetStart": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/DL9SzvX/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "test",
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "82px",
                    "height": "16px",
                    "backgroundColor": "#0000ff",
                    "borderWidth": "1px",
                    "borderColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "86px",
                "height": "20px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "24px",
                "offsetEnd": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/DL9SzvX/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "tost",
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "82px",
                    "height": "16px",
                    "backgroundColor": "#ff0000",
                    "borderWidth": "1px",
                    "borderColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "86px",
                "height": "20px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "45px",
                "offsetEnd": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/YBLJ1Lv/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "86px",
                "height": "40px",
                "offsetTop": "65px",
                "backgroundColor": "#000000",
                "offsetEnd": "1px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/DL9SzvX/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:3",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": text,
                        "size": "xs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic",
                        "offsetStart": "2px"
                      },
                      {
                        "type": "text",
                        "text": "📀",
                        "size": "xs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic",
                        "offsetStart": "2px",
                        "offsetTop": "5px"
                      },
                      {
                        "type": "text",
                        "text": "📀",
                        "size": "xs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic",
                        "offsetTop": "10px",
                        "offsetStart": "2px"
                      }
                    ],
                    "position": "absolute",
                    "width": "146px",
                    "height": "72px",
                    "backgroundColor": "#0cbcb0",
                    "borderWidth": "1px",
                    "borderColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "76px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "106px",
                "offsetStart": "1px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "184px",
            "backgroundColor": "#bbcc00",
            "borderWidth": "1px",
            "borderColor": "#000000",
            "cornerRadius": "8px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/qxnJVSG/ezgif-com-gif-maker-1.png",
                "size": "md",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "30px"
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "190px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/hVmT0Cq/ezgif-com-gif-maker.png",
                "size": "md",
                "aspectRatio": "6:6",
                "aspectMode": "cover",
                "offsetTop": "110px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "190px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/kccc28M/ezgif-com-gif-maker-6.png",
                "size": "xxs",
                "aspectRatio": "2:2",
                "aspectMode": "cover",
                "offsetTop": "80px",
                "offsetStart": "-5px"
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "190px"
          }
        ],
        "paddingAll": "0px",
        "height": "190px",
        "borderWidth": "1px",
        "borderColor": "#000000",
        "cornerRadius": "10px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)   

def sendTextTemplate911(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/2yptfqj/ezgif-com-gif-to-apng.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "6:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/DYT9yGS/ezgif-com-gif-to-apng-3.png",
                "size": "15px",
                "aspectRatio": "6:2",
                "aspectMode": "cover",
                "animated": True,
              }
            ],
            "position": "absolute",
            "width": "80px",
            "height": "15px",
            "offsetTop": "12px",
            "offsetStart": "60px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "6px",
                "color": "#ff00ff",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "10px",
            "offsetTop": "1px",
            "offsetStart": "4px"
          }
        ],
        "paddingAll": "0px",
        "height": "20px",
        "cornerRadius": "15px",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02",
        }
      }
    }
  ]
}
}
    time.sleep(0.5)
    sendTemplate(to, data)
    
def sendFoter(to, text):
    time.sleep(1)
    data = {
        "type": "text",
        "text": text,
        "sentBy": {
             "label": "• TEAM TERMUX •",
             "iconUrl": "https://s20.directupload.net/images/210719/mrc6uorh.gif",
             "linkUrl": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6"
         }
     }
    sendTemplate(to, data)

def failOverAPI():
    try:
        result = requests.get("https://api.boteater.xyz",timeout=0.5)
        if result.status_code == 200:
            return "https://api.boteater.xyz"
        else:
            return "https://api.boteater.us"
    except:
        return "https://api.boteater.us"

def cytmp4(to,url):
    import pafy
    vid = pafy.new(url,basic=False)
    result = vid.streams[-1]
    return result.url
    links = cytmp4(anunya);links = 'https://'+cl.google_url_shorten(links)
    
def pendekin(to,url):
    req_url = 'https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAzrJV41pMMDFUVPU0wRLtxlbEU-UkHMcI'
    payload = {'longUrl': url}
    headers = {'content-type': 'application/json'}
    r = requests.post(req_url, data=json.dumps(payload), headers=headers)
    resp = json.loads(r.text)
    return resp['id']

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = cl.genOBSParams({'oid': mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "update profile failed"
        cl.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("vp.mp4")

def changeProfileVideo(to):
    if settings['changevp']['picture'] == None:
        return cl.sendReplyMessage(msg_id, to, "Foto tidak ditemukan")
    elif settings['changevp']['video'] == None:
        return cl.sendReplyMessage(msg_id, to, "Video tidak ditemukan")
    else:
        path = settings['changevp']['video']
        files = {'file': open(path, 'rb')}
        obs_params = cl.genOBSParams({'oid': cl.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return cl.sendReplyMessage(msg_id, to, "Gagal update profile")
        path_p = settings['changevp']['picture']
        settings['changevp']['status'] = False
        cl.updateProfilePicture(path_p, 'vp')
def siderMembers(to, mid):
    try:
        arrData = ""
        textx = (str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getChats([to],True,True).chats[0].chatName))
                except:
                    no = "\n╚══[ Success ]"
       # cl.sendMessage(msg.to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(msg.to, "[ INFO ] Error :\n" + str(error))

def siderMembers1(to, mid):
    try:
        arrData = ""        
        textx = "".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getChats([to],True,True).chats[0]
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)           
            textx += mention+wait["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getChats([to],True,True).chats[0].chatName))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        #contact = cl.getContact(op.param2).picturePath
        #image = 'http://dl.profile.line.naver.jp'+contact
        #cl.sendImageWithURL(op.param1, image)
        #cl.sendMessage(msg.to, None, contentMetadata={"STKID":"389588135","STKPKGID":"14901992","STKVER":"1"}, contentType=7)             
    except Exception as error:
        cl.sendMessage(msg.to, "[ INFO ] Error :\n" + str(error))
        
def mentionMembers(to, mid):
    try:
        arrData = ""
        ginfo = cl.getChats(to)
        textx = "╭─「 Daftar anggota 」\n├↘\n├↘1. "
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n├↘\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "├↘ {}. ".format(str(no))
            else:
                textx += "╰─「 Mentions {} Member 」".format(str(len(mid)))
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(msg.to, "[ INFO ] Error :\n" + str(error))

def sendMentionn(cl,to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@KaleraTeam_ "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        try:
            try:
                if 'kolori' in ps:contact = cl.getContact(ps.split('##')[1])
                else:contact = cl.getContact(to)
                cu = "http://profile.line-cdn.net/" + contact.pictureStatus
                cc = str(contact.displayName)
            except Exception as e:
                cdb = cl.getContact(cl.profile.mid)
                cc = str(cdb.displayName)
                cu = "http://profile.line-cdn.net/" + cdb.pictureStatus
            cl.sendMessage(to, textx, {'AGENT_LINK': "line://app/1655063343-oxyzbOrK?type=fotext&text=I'm%20VynnL",'AGENT_ICON': "http://dl.profile.line-cdn.net/" + self.getProfile().picturePath,'AGENT_NAME':ps,'MSG_SENDER_ICON':cu,'MSG_SENDER_NAME':cc,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except:
            try:
                cl.sendMessage(to, textx, {'AGENT_LINK': "line://app/1655063343-oxyzbOrK?type=fotext&text=I'm%20VynnL",'AGENT_ICON': "http://dl.profile.line-cdn.net/" + self.getProfile().picturePath,'MSG_SENDER_NAME': self.getContact(to).displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + self.getContact(to).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
            except:
                try:
                    cl.sendMessage(to, textx, {'AGENT_LINK': "line://app/1655063343-oxyzbOrK?type=fotext&text=I'm%20VynnL",'AGENT_ICON': "http://dl.profile.line-cdn.net/" + self.getProfile().picturePath,'MSG_SENDER_NAME': self.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + self.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
                except:
                    cl.sendMessage(to, textx, {'AGENT_LINK': "line://app/1655063343-oxyzbOrK?type=fotext&text=I'm%20VynnL",'AGENT_ICON': "http://dl.profile.line-cdn.net/" + self.getProfile().picturePath,'AGENT_NAME':ps,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
                    
def sendMentionV2(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@CakaraBots "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    
def FakeStickerV2(to, spkg,sid, mids=[]): #DONE
    if clMID in mids: mids.remove(clMID)
    parsed_len = len(mids)//140+1
    result = '「 Mention Members 」\n'
    mention = '@netizent...\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*140:(point+1)*140]:
            no += 1
            result += ' %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += ''
        if result:
            cl.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees}),'STKPKGID':spkg,'STKID':sid}, 7)
        result = ''

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "ʜᴀʏ ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getChats([to],True,True).chats[0]
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["welcome"]
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".cl.getChats([to],True,True).chats[0]
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        #cl.sendMessage(msg.to, None, contentMetadata={"STKID":"2713783","STKPKGID":"3524","STKVER":"1"}, contentType=7)             
    except Exception as error:
        cl.sendMessage(msg.to, "[ INFO ] Error :\n" + str(error))

def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "ᴡᴀʜ ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getChats([to],True,True).chats[0]
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["leavemsg"]
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n┗━━[ {} ]".format(str(cl.getChats([to],True,True).chats[0].chatName))
                except:
                    no = "\n┗━━[ Success ]"    
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        #cl.sendMessage(msg.to, None, contentMetadata={"STKID":"21802193","STKPKGID":"1663535","STKVER":"1"}, contentType=7)             
    except Exception as error:
        cl.sendMessage(msg.to, "[ INFO ] Error :\n" + str(error))

def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@KhieGans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    cl.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(cl.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + cl.getContact("u176ef6889643e290ba5801bffc83457b").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def khieMention(to, text="", mids=[]):
        arrData = ""
        arr = []
        mention = "@Mmk "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 5
                else:slen = len(textx);elen = len(textx) + 5
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def SoakKiller(to, mid):
    try:
        aa = '{"S":"0","E":"5","M":'+json.dumps(mid)+'}'
        text_ = '@Khiez'
        cl.sendMessage(to, text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
        logError(error)

def sendMention(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(msg.to, "[ INFO ] Error :\n" + str(error))

def mentionMembers2(to, mids=[]):
    if clMID in mids: mids.remove(clMID)
    parsed_len = len(mids)//20+1
    result = '╭───「 Mention 」\n'
    mention = '@zeroxyuuki\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '│ %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '╰───「 TEAM TERMUX 」\n'
        if result:
            if result.endswith('\n'): result = result[:-1]
            cl.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''

#message.createdTime -> 00:00:00
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 24 hours
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")

def removeCmd(cmd, text):
	key = Setmain["keyCommand"]
	#if Setmain["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd
def helpjs():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage1 = "╭─╼Help Js \n"+\
                  "├⌬ " + key + "nukeall\n" + \
                  "├⌬ " + key + "bantai: no\n" + \
                  "├⌬ " + key + "sapu: no\n" + \
                  "├⌬ " + key + "#bypass\n" + \
                  "├⌬ " + key + "#cancel\n" + \
                  "├⌬ " + key + "Set js\n" + \
                  "├⌬ " + key + "Set bypass\n" + \
                  "╰┅BERIKUT KOMEN JS & BYPASS"
    return helpMessage1
def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type in [11,122]:
            if op.param1 in protectqr:
                try:
                    if cl.getChats(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            cl.reissueGroupTicket(op.param1)
                            X = cl.getChats(op.param1)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            cl.deleteOtherFromChat(op.param1,[op.param2])
                            cl.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                except:pass
        if op.type in [19,133]:
            if op.param2 in wait["blacklist"]:
                cl.deleteOtherFromChat(op.param1,[op.param2])
                cl.sendMessage(op.param1,"contact ini ʙʟᴀᴄᴋʟɪsᴛ")
        if op.type in [126,133,124]:
          if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
            if op.param2 in wait["blacklist"]:
                cl.cancelChatInvitation(op.param1,[op.param3]);cl.deleteOtherFromChat(op.param1,[op.param2])
                wait["blacklist"][op.param2] = True
            if op.param3 in wait["blacklist"]:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                cl.cancelChatInvitation(op.param1,[op.param3]);cl.deleteOtherFromChat(op.param1,[op.param2])
                wait["blacklist"][op.param2] = True                   
        if op.type in [124]:
            if clMID in op.param3:
                if wait["autoJoin"] == True:
                    cl.acceptChatInvitation(op.param1)
                    group = cl.getChats([op.param1]).chats[0]
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)                          
                    ginfo = cl.getChats([op.param1],True,True).chats[0]
                    data = {
                        "type": "flex",
                        "altText": "TEAM TERMUX",                        
                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "kilo",
      "body": {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/9rLgZYh/ezgif-com-gif-to-apng-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "6:4",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "60px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "2px",
                "offsetTop": "1px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getContact(clMID).pictureStatus),
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "60px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "2px",
                "offsetTop": "1px",
                "offsetEnd": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getChats([op.param1]).chats[0].picturePath),
                    "size": "full",
                    "aspectRatio": "4:3",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "60px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "offsetTop": "1px",
                "offsetStart": "74px",
                "cornerRadius": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "{}".format(cl.getContact(op.param2).displayName),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "15px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "offsetTop": "63px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "{}".format(ginfo.chatName),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "15px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "offsetTop": "63px",
                "offsetStart": "74px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "{}".format(cl.getContact(clMID).displayName),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "15px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "offsetTop": "63px",
                "offsetEnd": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/SPJsszm/ezgif-com-gif-maker-2.png",
                    "size": "full",
                    "aspectRatio": "8:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co.com/ScVq1BP/ezgif-com-gif-maker-3.png",
                        "size": "full",
                        "aspectRatio": "8:1",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "244px",
                    "height": "26px",
                    "offsetTop": "1px",
                    "offsetStart": "0px"
                  }
                ],
                "position": "absolute",
                "width": "244px",
                "height": "26px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "2px",
                "offsetTop": "80px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "250px",
            "height": "110px",
            "borderWidth": "1px",
            "borderColor": "#000000",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px",
            "backgroundColor": "#77779999"
          }
        ],
        "paddingAll": "0px",
        "height": "120px",        
      }
    }
  ]
}
}
                time.sleep(0.5)
                sendTemplate(op.param1, data)
                quisdata[op.param1] = {
                        "point": {},
                        "saklar": False,
                        "quest": "",
                        "tmp": [],
                        "asw": []
                }
            if clMID in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptChatInvitation(op.param1)
                        cl.deleteSelfFromChat(op.param1)
                    else:
                        cl.acceptChatInvitation(op.param1)                      

        if op.type in [13,124]:
            if op.param1 in protectinvite:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    babi = op.param3.replace("",',')
                    memek = babi.split(",")
                    for sodok in memek:
                       cl.cancelChatInvitation(op.param1,[sodok])
                       cl.deleteOtherFromChat(op.param1,[op.param2])
                       wait["blacklist"][op.param2] == True
        if op.type in [19,133]:
            if op.param3 in admin:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                  wait["blacklist"][op.param2] = True
                  try:
                      if op.param3 not in wait["blacklist"]:
                          cl.deleteOtherFromChat(op.param1,[op.param2]);cl.findAndAddContactsByMid;cl.inviteIntoChat(op.param1,[op.param3])
                  except:pass
        if op.type in [19,133]:
            if op.param3 in Bots:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                  wait["blacklist"][op.param2] = True
                  try:
                      if op.param3 not in wait["blacklist"]:
                          cl.deleteOtherFromChat(op.param1,[op.param2]);cl.findAndAddContactsByMid;cl.inviteIntoChat(op.param1,[op.param3])
                  except:pass
 
#____________________________________________________________________BATAS REMAX
        if op.type in [15,128]:
           #if op.param1 in welcome:
             if wait["welcomeOn"] == True:
                ginfo = cl.getChats([op.param1],True,True).chats[0]
             #   cl.updateGroup(group)
                contact = cl.getContact(op.param2)
                #cover = cl.getProfileCoverURL(op.param2)
                leaveMembers(op.param1, [op.param2])
                
        if op.type in [17,130]:
           #if op.param1 in welcome:
             if wait["welcomeOn"] == True:
                ginfo = cl.getChats([op.param1],True,True).chats[0]
             #   cl.updateGroup(group)
                contact = cl.getContact(op.param2)
                #cover = cl.getProfileCoverURL(op.param2)
                welcomeMembers(op.param1, [op.param2])
                
        if op.type in [17,130]:
            if op.param1 in welcome:
                ginfo = cl.getChats(op.param1)
                contact = cl.getContact(op.param2)
                #cover = cl.getProfileCoverURL(op.param2)
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                G = cl.getChats([op.param1], True , False).chats[0]
                time.sleep(1)
                data = {            
                        "type": "flex",
                        "altText": "TEAM TERMUX",
                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "kilo",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/HBRGznW/ezgif-com-gif-to-apng.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "6:3",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getChats([op.param1]).chats[0].picturePath),
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "220px",
                "height": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/XCmTTTD/ezgif-com-gif-to-apng-2.png",
                    "size": "full",
                    "aspectRatio": "6:6",
                    "aspectMode": "cover",
                    "animated": True,
                  }
                ],
                "position": "absolute",
                "width": "256px",
                "height": "70px",
                "offsetTop": "60px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/ZHD7bJh/1697899790267.jpg",
                    "size": "full",
                    "aspectRatio": "2:3",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "45px",
                "height": "55px",
                "offsetTop": "50px",
                "offsetEnd": "14px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "size": "full",
                    "aspectRatio": "7:3",
                    "aspectMode": "cover",
                    "animated": True,
                    "url": "https://i.ibb.co.com/99tQw2d/ezgif-com-gif-to-apng-1.png"
                  }
                ],
                "position": "absolute",
                "width": "256px",
                "height": "116px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "56px",
                "height": "56px",
                "cornerRadius": "100px",
                "offsetTop": "12px",
                "offsetStart": "13px",
                "borderWidth": "1px",
                "borderColor": "#000000"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "W E L C O M E ",
                    "size": "xxs",
                    "color": "#ff0000",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "200px",
                "height": "15px",
                "offsetTop": "0px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "{}".format(ginfo.chatName),
                    "size": "6px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  },
                  {
                    "type": "text",
                    "text": "👥:{}".format(cl.getContact(op.param2).displayName),
                    "size": "6px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  },
                  {
                    "type": "text",
                    "text": " ᴍᴇᴛ ɢᴀʙᴜɴɢ ɢᴀᴇs",
                    "size": "6px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  },
                  {
                    "type": "text",
                    "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M:%S'),
                    "size": "6px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  },
                  {
                    "type": "text",
                    "text": "📅:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "6px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "160px",
                "height": "160px",
                "offsetTop": "50px",
                "offsetStart": "70px"
              }
            ],
            "position": "absolute",
            "width": "256px",
            "height": "116px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "height": "120px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02",
        }
      }
    }
  ]
}
}
                time.sleep(0.5)
                sendTemplate(op.param1, data)

        if op.type in [15,128]:
            if op.param1 in leave:
                ginfo = cl.getChats(op.param1)
                contact = cl.getContact(op.param2)
                #cover = cl.getProfileCoverURL(op.param2)
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                G = cl.getChats([op.param1], True , False).chats[0]
                time.sleep(1)
                data = {            
                        "type": "flex",
                        "altText": "TEAM TERMUX",
                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "kilo",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/HBRGznW/ezgif-com-gif-to-apng.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "6:3",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getChats([op.param1]).chats[0].picturePath),
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "220px",
                "height": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/XCmTTTD/ezgif-com-gif-to-apng-2.png",
                    "size": "full",
                    "aspectRatio": "6:6",
                    "aspectMode": "cover",
                    "animated": True,
                  }
                ],
                "position": "absolute",
                "width": "256px",
                "height": "70px",
                "offsetTop": "60px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/ZHD7bJh/1697899790267.jpg",
                    "size": "full",
                    "aspectRatio": "2:3",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "45px",
                "height": "55px",
                "offsetTop": "50px",
                "offsetEnd": "14px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "size": "full",
                    "aspectRatio": "7:3",
                    "aspectMode": "cover",
                    "animated": True,
                    "url": "https://i.ibb.co.com/99tQw2d/ezgif-com-gif-to-apng-1.png"
                  }
                ],
                "position": "absolute",
                "width": "256px",
                "height": "116px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "56px",
                "height": "56px",
                "cornerRadius": "100px",
                "offsetTop": "12px",
                "offsetStart": "13px",
                "borderWidth": "1px",
                "borderColor": "#000000"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "L E A V E",
                    "size": "xxs",
                    "color": "#ff0000",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "200px",
                "height": "15px",
                "offsetTop": "0px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "{}".format(ginfo.chatName),
                    "size": "6px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  },
                  {
                    "type": "text",
                    "text": "👥:{}".format(cl.getContact(op.param2).displayName),
                    "size": "6px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  },
                  {
                    "type": "text",
                    "text": " ɴᴀʜ ᴋᴀɴ ʙᴀᴘᴇʀ ɢᴀᴇs",
                    "size": "6px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  },
                  {
                    "type": "text",
                    "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M:%S'),
                    "size": "6px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  },
                  {
                    "type": "text",
                    "text": "📅:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "6px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "160px",
                "height": "160px",
                "offsetTop": "50px",
                "offsetStart": "70px"
              }
            ],
            "position": "absolute",
            "width": "256px",
            "height": "116px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "height": "120px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02",
        }
      }
    }
  ]
}
}
                time.sleep(0.5)
                sendTemplate(op.param1, data)

        if op.type in [17,130]:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                        	cl.deleteOtherFromChat(op.param1,[op.param2])
                    except:pass

            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    X = cl.getChats(op.param1)
                    X.preventedJoinByTicket = True
                    cl.updateGroup(X)
                    cl.deleteOtherFromChat(op.param1,[op.param2])                        
                return
#        if op.type in [5]:
#            #print ("[ 5 ] NOTIFIED AUTO ADD")
#            if wait["autoAdd"]:
#                time.sleep(1)
#                cl.sendText(op.param1,"━━━━━━━━━━━━━━━━━━\n           ≛ ᴏᴘᴇɴ ᴏʀᴅᴇʀ ≛\n      ◈𝕭᳟𝖔᳟ⷮ??᳟ⷷ𝖘᳟ⷶᱻ᪶ᷟ𝖕𝖗᳟𝖔᳟𝖙᳟𝖊᳟𝖈᳟𝖙᳟☠᪵͞𝓚̲𝓲̲ᷤ𝓵̲ⷪ𝓵̲ⷶ𝓮̲ᷜ𝓻̲͞☠᪵◈\n━━━━━━━━━━━━━━━━━━\n▣ Selfbot Template\n▣ Simple login memakai helper.\n▣ Sewa helper Template\n▣ Bot js\n━━━━━━━━━━━━━━━━━━\n       ◈Ready Bot Golang◈\n━━━━━━━━━━━━━━━━━━\n▣ App Golang CL \n━━━━━━━━━━━━━━━━━━\n▣ Ready Bot Golang War◈\n━━━━━━━━━━━━━━━━━━\n▣ Bot Golang War:\n    ●type Sbgo induk\n    ●type Sbgo Multy Fetch\n    ●type Bot CL\n━━━━━━━━━━━━━━━━━━\n    ◈Ready Token primary◈\n━━━━━━━━━━━━━━━━━━\n━━━━━━━━━━━━━━━━━━\n▣ Pemasangan Bot Protect Untuk:\n▣ Room Chat.\n▣ Room Smule.\n▣ Room Event.\nɴʙ: harga kepoin aja\n▣ line.me/ti/p/~zul.1.02 \n━━━━━━━━━━━━━━━━━━")
 #       if op.type in [5]:
#            print ("[ 5 ] NOTIFIED AUTO BLOCK CONTACT")
#            if wait["autoBlock"] == True:
#                cl.blockContact(op.param1)
 #               cl.sendMessage(msg.to, "nyaman nyaman nyaman nyaman nyaman nyaman    ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.👿.👿.👿 ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.")

        if op.type in [65]:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = cl.getChats(at)
                                ryan = cl.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "╭─「 Gambar Dihapus 」\n│ Pengirim : "
                                ret_ = "│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                cl.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                cl.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = cl.getChats(at)
                                ryan = cl.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "╭─「 Pesan Dihapus 」\n"
                                ret_ += "│ Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n│ Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                ret_ += "\n╰───────────"
                                cl.sendMessage(at, str(ret_))
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)
        if op.type in [65]:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = cl.getChats(at)
                                ryan = cl.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "╭─「 Sticker Dihapus 」\n"
                                ret_ += "│ Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                ret_ += "\n╰───────────"
                                cl.sendMessage(at, str(ret_))
                                cl.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)
        if op.type in [19,133]:
            if op.param1 in protectkick:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    cl.deleteOtherFromChat(op.param1,[op.param2])
                else:pass
        if op.type in [32,126]:
            if op.param1 in protectcancel:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            cl.deleteOtherFromChat(op.param1,[op.param2])
                    except:pass                        
                return
        if op.type in [55]:
            if op.param2 in wait["blacklist"]:
                cl.deleteOtherFromChat(op.param1,[op.param2]);cl.sendMessage(op.param1,"contact ini ʙʟᴀᴄᴋʟɪsᴛ")
            else:pass
            if op.param1 in read["readPoint"]:
                if op.param2 in read["readMember"][op.param1]:
                    pass
                else:
                    read["readMember"][op.param1][op.param2] = True
            else:pass

        if op.type in [55]:
            if cctv['cyduk1'][op.param1]==True:
                if op.param1 in cctv['point1']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem1'][op.param1]:
                        pass
                    else:
                        time.sleep(0.5)
                        cctv['sidermem1'][op.param1] += "\n❑ " + Name
                        siderMembers1(op.param1, [op.param2])                        


        if op.type == 55:
            if cctv['cyduk2'][op.param1]==True:
                if op.param1 in cctv['point2']:
                    contact = cl.getContact(op.param2)
                    Name = contact.displayName
                    Pict = "https://profile.line-scdn.net/{}".format(contact.pictureStatus)
                    if Name in cctv['sidermem2'][op.param1]:
                        pass
                    else:
                        time.sleep(0.5)
                        cctv['sidermem2'][op.param1] += "\n❑ " + Name
                        ab = {"type":"bubble","size":"deca","body":{"type":"box","layout":"vertical","contents":[{"type":"image","url":"https://i.ibb.co.com/gRYLdmY/line.png","aspectRatio":"5.92:2","gravity":"center","align":"center","aspectMode":"cover","animated":True,"size":"full"},{"type":"box","layout":"vertical","contents":[{"type":"image","url":Pict,"size":"47px","gravity":"center","align":"center","aspectMode":"cover"}],"paddingAll":"0px","position":"absolute","offsetStart":"15px","offsetTop":"12px"},{"type":"box","layout":"vertical","contents":[{"type":"image","url":"https://i.ibb.co.com/ct1YKXt/sider.png","aspectRatio":"5.92:2","gravity":"center","align":"center","aspectMode":"cover","size":"5xl"}],"paddingAll":"0px","position":"absolute"},{"type":"box","layout":"vertical","contents":[{"type":"image","url":"https://i.ibb.co.com/tC3hYX2/lightdoy.png","size":"5px","gravity":"center","align":"center","aspectMode":"cover","animated":True}],"paddingAll":"0px","position":"absolute","offsetEnd":"69.5px","offsetBottom":"7.5px"},{"type":"box","layout":"vertical","contents":[{"type":"text","text":Name,"size":"10px","color":"#e91100","weight":"bold","align":"center","gravity":"center"}],"paddingAll":"0px","position":"absolute","offsetStart":"95px","width":"95px","offsetTop":"19px"},{"type":"box","layout":"vertical","contents":[{"type":"text","text":"Nah kan...ngintip","size":"9px","gravity":"center","align":"center","wrap":True,"weight":"bold","color":"#ffffff","maxLines":2}],"position":"absolute","offsetStart":"85px","width":"100px","height":"25px","offsetBottom":"11px"},{"type":"box","layout":"vertical","contents":[{"type":"image","url":"https://i.ibb.co.com/tC3hYX2/lightdoy.png","size":"5px","gravity":"center","align":"center","aspectMode":"cover","animated":True}],"paddingAll":"0px","position":"absolute","offsetTop":"33px","offsetStart":"67px"}],"paddingAll":"0px"}}
                        dt1 = {"type": "flex", "altText": "TEAM TERMUX", "contents": ab}
                        sendTemplate(op.param1, dt1)

        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        time.sleep(0.5)
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = cl.getContact(op.param2)
                        #cover = cl.getProfileCoverURL(op.param2)
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        warna1 = ("#00ff00","#ffff00","#0000ff","#ff00ff","#00FFFF","#800000","#FF7F00","#BF00FF")
                        warnanya1 = random.choice(warna1)
                        foto1 = ("https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png","https://i.ibb.co/Xs9Jtyr/ezgif-com-gif-maker.png","https://i.ibb.co/r4NMzr2/ezgif-com-gif-maker-1.png","https://i.ibb.co/rFfr3N4/ezgif-com-gif-maker-2.png","https://i.ibb.co/2WwgNBX/ezgif-com-gif-maker-3.png")
                        foto2 = ("https://i.ibb.co/y6cdp2X/ezgif-com-gif-maker-3.png","https://i.ibb.co/sjcgTHr/ezgif-com-gif-maker-4.png","https://i.ibb.co/2jvwXdf/ezgif-com-gif-maker-5.png","https://i.ibb.co/CstR9Q1/ezgif-com-gif-maker-6.png","https://i.ibb.co/RBW4LBr/ezgif-com-gif-maker-7.png")
                        f1 = random.choice(foto1)
                        f2 = random.choice(foto2)
                        foto3 = ("https://i.ibb.co/DYBJ14f/ezgif-com-gif-maker-1.png","https://i.ibb.co/023DpDP/ezgif-com-gif-maker-2.png","https://i.ibb.co/KLC3FjS/ezgif-com-gif-maker-3.png")
                        foto4 = ("https://i.ibb.co/y6cdp2X/ezgif-com-gif-maker-3.png","https://i.ibb.co/sjcgTHr/ezgif-com-gif-maker-4.png","https://i.ibb.co/2jvwXdf/ezgif-com-gif-maker-5.png","https://i.ibb.co/CstR9Q1/ezgif-com-gif-maker-6.png","https://i.ibb.co/RBW4LBr/ezgif-com-gif-maker-7.png")
                        f3 = random.choice(foto1)
                        f4 = random.choice(foto2)
                        data = {     
                                "type": "flex",
                                "altText": "TEAM TERMUX",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/hLxg84Q/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/tLg5TJV/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "animated": True,
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/6vDrx6D/IMG-20240625-WA0033.jpg", 
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "70px",
                    "height": "70px",
                    "borderWidth": "1px",
                    "borderColor": "#ff0000",
                    "cornerRadius": "100px",
                    "offsetTop": "18px",
                    "offsetStart": "15px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "100px",
                "cornerRadius": "100px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "40px",
                "height": "40px",
                "cornerRadius": "100px",
                "offsetTop": "50px",
                "borderWidth": "1px",
                "borderColor": warnanya1,
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "CCTV",
                    "size": "xs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "20px",
                "offsetTop": "1px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "📅:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "xxs",
                    "weight": "bold",
                    "color": "#000000",
                    "style": "italic",
                    "offsetTop": "2px"
                  }
                ],
                "position": "absolute",
                "width": "80px",
                "height": "20px",
                "backgroundColor": "#bbccff",
                "borderWidth": "1px",
                "borderColor": warnanya1,
                "cornerRadius": "5px",
                "offsetTop": "1px",
                "offsetEnd": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M'),
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "20px",
                "backgroundColor": "#bbcc00",
                "borderWidth": "1px",
                "borderColor": warnanya1,
                "cornerRadius": "5px",
                "offsetTop": "22px",
                "offsetEnd": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "👥:{}".format(cl.getContact(op.param2).displayName),
                    "size": "xs",
                    "color": "#f0f0f0",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "156px",
                "height": "20px",
                "offsetTop": "85px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": " NAH KAN NGINTIP TERUS\nAWAS BINTITAN LHO",
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetStart": "2px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "TEAM TERMUX",
                        "color": "#00ffff",
                        "weight": "bold",
                        "size": "xxs",
                        "style": "italic",
                        "offsetStart": "25px",
                        "offsetTop": "2px"
                      }
                    ],
                    "position": "absolute",
                    "width": "156px",
                    "height": "18px",
                    "backgroundColor": "#000000",
                    "borderWidth": "1px",
                    "borderColor": warnanya1,
                    "offsetTop": "28px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "50px",
                "backgroundColor": "#bcbcbc",
                "borderWidth": "1px",
                "borderColor": warnanya1,
                "offsetTop": "102px"
              }
            ],
            "position": "absolute",
            "width": "152px",
            "height": "152px",
            "backgroundColor": "#01202acc",
            "borderWidth": "2px",
            "borderColor": warnanya1,
            "cornerRadius": "8px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": warnanya1,
        "cornerRadius": "10px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
                        time.sleep(0.5)
                        sendTemplate(op.param1, data)

        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          random.choice(ABC).deleteOtherFromChat(to, [msg._from])
                      except:
                          try:
                              cl.deleteOtherFromChat(to, [msg._from])
                          except:
                              cl.deleteOtherFromChat(to, [msg._from])
   
        if op.type == 25 or op.type == 26:
            try:
                print ("[ 25 ] SEND MESSAGE")
                #print(op)
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                to = msg.to
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != cl.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                    if msg.contentType == 0:
                        if text is None:
                            return
                    elif msg.contentType == 16:
                        if wait["likeOn"] == True:
                            try:
                                contact = cl.getContact(sender);tz = pytz.timezone("Asia/Jakarta");timeNow = datetime.now(tz=tz)
                                ret_ = "╔══[ Details Post ]"
                                if msg.contentMetadata["serviceType"] == "GB":
                                    auth = "\n╠❂🇮🇩➢ Penulis : {}".format(str(contact.displayName))
                                else:
                                    auth = "\n╠❂🇮🇩➢ Penulis : {}".format(str(msg.contentMetadata["serviceName"]))
                                purl = "\n╠❂🇮🇩➢ URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                ret_ += auth
                                ret_ += purl
                                if "mediaOid" in msg.contentMetadata:
                                    object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                    if msg.contentMetadata["mediaType"] == "V":
                                        if msg.contentMetadata["serviceType"] == "GB":
                                            ourl = "\n╠❂🇮🇩➢ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                            murl = "\n╠❂??🇩➢ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                        else:
                                            ourl = "\n╠❂🇮🇩➢ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                            murl = "\n╠❂🇮🇩➢ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                        ret_ += murl
                                    else:
                                        if msg.contentMetadata["serviceType"] == "GB":
                                            ourl = "\n╠❂🇮🇩➢ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                        else:
                                            ourl = "\n╠❂🇮🇩➢ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                    ret_ += ourl
                                if "stickerId" in msg.contentMetadata:
                                    stck = "\n╠❂🇮🇩➢ Stiker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                    ret_ += stck
                                if "text" in msg.contentMetadata:
                                    text = "\n╠❂🇮🇩➢ Tulisan :\n╠❂🇮🇩➢ {}".format(str(msg.contentMetadata["text"]))
                                    ret_ += text
                                ret_ += "\n╚══[ Finish ]"
                                sendpostTemplate(to, data)
                            except:                     
                                data = {"type": "flex","altText": "TEAM TERMUX","contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/9rLgZYh/ezgif-com-gif-to-apng-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "3:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus),
                    "size": "full",
                    "aspectRatio": "3:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "80px",
                "height": "60px",
                "offsetTop": "20px",
                "offsetStart": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/XCmTTTD/ezgif-com-gif-to-apng-2.png",
                    "size": "xl",
                    "aspectRatio": "3:2",
                    "aspectMode": "cover",
                    "animated": True,
                  }
                ],
                "position": "absolute",
                "width": "156px",
                "height": "86px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/NZp1jN2/ezgif-com-gif-to-apng-4.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "animated": True,
                  }
                ],
                "position": "absolute",
                "width": "15px",
                "height": "15px",
                "offsetTop": "70px",
                "offsetStart": "4px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/NZp1jN2/ezgif-com-gif-to-apng-4.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "animated": True,
                  }
                ],
                "position": "absolute",
                "width": "15px",
                "height": "15px",
                "cornerRadius": "100px",
                "offsetTop": "70px",
                "offsetEnd": "4px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/DYT9yGS/ezgif-com-gif-to-apng-3.png",
                    "size": "25px",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                    "animated": True,
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "76px",
                "offsetStart": "17px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": " AUTO LIKE ",
                    "size": "8px",
                    "color": "#ff0000",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "15px",
                "offsetTop": "2px",
                "offsetStart": "55px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰"+ datetime.strftime(timeNow,'%H:%M:%S'),
                    "size": "6px",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "90px",
                "height": "15px",
                "offsetTop": "10px",
                "offsetStart": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "📅"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "6px",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "160px",
                "height": "15px",
                "offsetTop": "10px",
                "offsetStart": "100px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "👥{}".format(cl.getContact(sender).displayName),
                    "size": "8px",
                    "color": "#ffff00",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "180px",
                "height": "15px",
                "offsetTop": "60px",
                "offsetStart": "30px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "86px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "height": "90px",
        "cornerRadius": "15px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02"
      }
    }
  ]
}
}
                                sendTemplate(to, data)
            except:pass
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
              if wait["respontag"] == True:                
                contact = cl.getContact(msg._from)
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                warna1 = ("#00ff00","#ffff00","#0000ff","#ff00ff","#00FFFF","#800000","#FF7F00","#BF00FF")
                warnanya1 = random.choice(warna1)
                kata1 = ("Tag mele Tampol","Gue lagi sibuk Bos","Ada sayang ada","Tag Terus cipok nih","Tampol nih","Bangke tag trus","G Usah sok kenal","Sibuk Gw Bego","Apa sih lo tag2","Orangnya lgi kojom","Tidug gw jir","Uuucchhhh ada syang","Jangan suka tag","Bangke Lo tag2","Jangan suka tag","Kangen Lo ya","Cie...tag ngajak kojom","HHH...Nunggu ya")
                katanya1 = random.choice(kata1)
                foto1 = ("https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png","https://i.ibb.co/Xs9Jtyr/ezgif-com-gif-maker.png","https://i.ibb.co/r4NMzr2/ezgif-com-gif-maker-1.png","https://i.ibb.co/rFfr3N4/ezgif-com-gif-maker-2.png","https://i.ibb.co/2WwgNBX/ezgif-com-gif-maker-3.png")
                foto2 = ("https://i.ibb.co/sjcgTHr/ezgif-com-gif-maker-4.png","https://i.ibb.co/2jvwXdf/ezgif-com-gif-maker-5.png","https://i.ibb.co/CstR9Q1/ezgif-com-gif-maker-6.png","https://i.ibb.co/RBW4LBr/ezgif-com-gif-maker-7.png","https://i.ibb.co/S3rvN6v/ezgif-com-gif-maker-1.png","https://i.ibb.co/fv78YKD/ezgif-com-gif-maker-2.png","https://i.ibb.co/y6cdp2X/ezgif-com-gif-maker-3.png")
                f1 = random.choice(foto1)
                f2 = random.choice(foto2)
                #cover = cl.getProfileCoverURL(sender)
                name = re.findall(r'@(\w+)', msg.text)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                mentionees = mention['MENTIONEES']
                for mention in mentionees:
                     if mention ['M'] in clMID:
                        XFUCK = {                                      
                                    "type": "flex",
                                    "altText": "TEAM TERMUX",
                                    "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/8MKgPwd/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:2",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "RESPON TAG",
                    "size": "xs",
                    "color": "#ffffcc",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "30px"
                  }
                ],
                "position": "absolute",
                "width": "148px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "5px",
                "offsetTop": "1px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M:%S'),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "regular"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "15px",
                "backgroundColor": "#0000ff",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "3px",
                "offsetTop": "22px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "📅:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "regular"
                  }
                ],
                "position": "absolute",
                "width": "80px",
                "height": "15px",
                "backgroundColor": "#ff0000",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "3px",
                "offsetTop": "22px",
                "offsetEnd": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "70px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "2px",
                "offsetTop": "38px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/ZHD7bJh/1697899790267.jpg", 
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "70px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "2px",
                "offsetTop": "38px",
                "offsetEnd": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Nama:{}".format(contact.displayName),
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "regular"
                  }
                ],
                "position": "absolute",
                "width": "148px",
                "height": "15px",
                "backgroundColor": "#bbcf00",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "3px",
                "offsetTop": "105px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": katanya1,
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "regular",
                    "offsetStart": "4px"
                  }
                ],
                "position": "absolute",
                "width": "148px",
                "height": "18px",
                "backgroundColor": "#bbcf00",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "3px",
                "offsetTop": "120px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": f2,
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "150px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co.com/Z2kf9Lj/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "150px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "140px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "8px",
            "offsetTop": "3px",
            "offsetStart": "3px",
            "backgroundColor": "#03303acc"
          }
        ],
        "paddingAll": "0px",
        "height": "150px",
        "borderWidth": "2px",
        "borderColor": "#000000",
        "cornerRadius": "10px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
                        sendTemplate(to, XFUCK)
                        sid = str(wait["AddstickerTag"]["sid"])
                        spkg = str(wait["AddstickerTag"]["spkg"])
                        cl.sendSticker(to, spkg, sid)              
            
        if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
              if wait["detectMention1"] == True:
                contact = cl.getContact(msg._from)
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
              #  cover = cl.getProfileCoverURL(sender)
                name = re.findall(r'@(\w+)', msg.text)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                mentionees = mention['MENTIONEES']
                for mention in mentionees:
                     if mention ['M'] in clMID:
                        XFUCK = wait["balasan"]
                        cl.sendMessage(to, XFUCK)
                        cl.sendMessage(to, None, contentMetadata={"STKID":"51626512","STKPKGID":"11538","STKVER":"1"}, contentType=7)
                        
        if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
              if wait["detectMention2"] == True:
                contact = cl.getContact(msg._from)
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
              #  cover = cl.getProfileCoverURL(sender)
                name = re.findall(r'@(\w+)', msg.text)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                mentionees = mention['MENTIONEES']
                for mention in mentionees:
                     if mention ['M'] in clMID:
                        #XFUCK = wait["balasan"]
                        cl.sendMessage(to, None, contentMetadata={"STKID":"51626512","STKPKGID":"11538","STKVER":"1"}, contentType=7)
        
        
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            stickername = str(text)
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
                     
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if temptag["stealtag"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention["M"] in clMID:
                           contact = cl.getContact(msg._from)
                           anu = contact.displayName
                           cl.sendReplyMessage(msg.id,to, " " +anu+ " {}".format(wait["Tag"]))
                           sid = str(wait["AddstickerTag"]["sid"])
                           spkg = str(wait["AddstickerTag"]["spkg"])
                           cl.sendSticker(to, spkg, sid)
                           break
                                                                                                    
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in clMID:
                           sendTextTemplate200(to, "Don't Tag Me !!")
                           cl.deleteOtherFromChat(to, [msg._from])
                           break
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    sendTextTemplate200(to,"「Cek ID Sticker」\n°❂° STKID : " + msg.contentMetadata["STKID"] + "\n°❂° STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n°❂° STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        sendTextTemplate200(msg.to,"╭─「 Contact Info 」\n├↘ Nama : " + msg.contentMetadata["displayName"] + "\n├↘ MID : " + msg.contentMetadata["mid"] + "\n├↘ Status Msg : " + contact.statusMessage + "\n├↘ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(to, image)

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            stickername = str(text)
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 16:
                    if wait["Timeline"] == True:
                            ret_ = "「 Detail Postingan 」"
                            if msg.contentMetadata["serviceType"] == "GB":
                                contact = cl.getContact(sender)
                                auth = "\n• Penulis : {}".format(str(contact.displayName))
                            else:
                                auth = "\n• Penulis : {}".format(str(msg.contentMetadata["serviceName"]))
                            ret_ += auth
                            if "stickerId" in msg.contentMetadata:
                                stck = "\n• Stiker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                ret_ += stck
                            if "mediaOid" in msg.contentMetadata:
                                object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                if msg.contentMetadata["mediaType"] == "V":
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                        murl = "\n• Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                        murl = "\n• Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                    ret_ += murl
                                else:
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                ret_ += ourl
                            if "text" in msg.contentMetadata:
                                text = "\n• Tulisan : {}".format(str(msg.contentMetadata["text"]))
                                purl = "\n• Post URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                ret_ += purl
                                ret_ += text
                            sendTextTemplate200(to, str(ret_))

               if msg.contentType == 7:
                 #if msg._from in admin:
                    if wait["AddstickerTag"]["status"] == True:
                        wait["AddstickerTag"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerTag"]["spkg"] = msg.contentMetadata['STKPKGID']
                        cl.sendMessage(msg.to, "🛑Add Stickers Tag Succes ♪")
                        wait["AddstickerTag"]["status"] = False     
               if msg.contentType == 7:
                 #if msg._from in admin:
                    if wait["AddstickerSider"]["status"] == True:
                        wait["AddstickerSider"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerSider"]["spkg"] = msg.contentMetadata['STKPKGID']
                        cl.sendMessage(msg.to, "🛑Add stickers sider ♪")
                        wait["AddstickerSider"]["status"] = False                   
               if msg.contentType == 7:
                 #if msg._from in admin:
                    if wait["AddstickerPesan"]["status"] == True:
                        wait["AddstickerPesan"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerPesan"]["spkg"] = msg.contentMetadata['STKPKGID']
                        cl.sendMessage(msg.to, "🛑Succes add Stickers ♪")
                        wait["AddstickerPesan"]["status"] = False                   
               if msg.contentType == 7:
                 #if msg._from in admin:
                    if wait["AddstickerWelcome"]["status"] == True:
                        wait["AddstickerWelcome"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerWelcome"]["spkg"] = msg.contentMetadata['STKPKGID']
                        cl.sendMessage(msg.to, "🛑Succes add Stickers ♪")
                        wait["AddstickerWelcome"]["status"] = False                   
               if msg.contentType == 7:
                 #if msg._from in admin:
                    if wait["AddstickerLeave"]["status"] == True:
                        wait["AddstickerLeave"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerLeave"]["spkg"] = msg.contentMetadata['STKPKGID']
                        cl.sendMessage(msg.to, "🛑Succes add Stickers Leave ♪")
                        wait["AddstickerLeave"]["status"] = False                   
               if msg.contentType == 0:
                    msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
               if msg.contentType == 1:
                    path = cl.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'Gambarnya dibawah',"data":path,"from":msg._from,"createdTime":msg.createdTime}
               if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n\n「 Sticker Info 」"
                   ret_ += "\n• Sticker ID : {}".format(stk_id)
                   ret_ += "\n• Sticker Version : {}".format(stk_ver)
                   ret_ += "\n• Sticker Package : {}".format(pkg_id)
                   ret_ += "\n• Sticker Url : line://shop/detail/{}".format(pkg_id)
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = cl.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}
                            
               if msg.contentType == 7:
                   #if msg._from in admin:
                       try:
                           if wait["sticker"] == True:
                               wait["stickers"][wait["stk"]] = msg.contentMetadata
                               wait["stk"] = {}
                               wait["sticker"] = False
                               f=codecs.open("wait.json","w","utf-8")
                               json.dump(wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                               sendTextTemplate200(msg.to,"🛑Tersimpan")
                       except Exception as e:
                           sendFoter(msg.to,"{}".format(str(e)))
               if msg.contentType == 2:
               	if settings["changevp"] == True:
               		contact = cl.getProfile()
               		path = cl.downloadFileURL("https://obs.line-scdn.net/{}".format(contact.pictureStatus))
               		path1 = cl.downloadObjectMsg(msg_id)
               		settings["changevp"] = False
               		changeVideoAndPictureProfile(path, path1)
               		sendTextTemplate200(msg.to, "🛑succes")
                       
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    sendTextTemplate200(msg.to,"「Cek ID Sticker」\n°❂° STKID : " + msg.contentMetadata["STKID"] + "\n°❂° STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n°❂° STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        sendTextTemplate200(msg.to," ╭─「 Contact Info 」\n├↘ Nama : " + msg.contentMetadata["displayName"] + "\n├↘ MID : " + msg.contentMetadata["mid"] + "\n├↘ Status Msg : " + contact.statusMessage + "\n╰─ 「Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(to, image)
#ADD Bots
               if msg.contentType == 13:
                 #if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        sendTextTemplate200(msg.to,"🛑Sudah dalam daftar bot\nSilahkan ketik refresh")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        sendTextTemplate200(msg.to,"🛑Masuk dalam daftar bots\nSilahkan ketik refresh")
#                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        sendTextTemplate200(msg.to,"🛑Berhasil menghapus dari anggota bot\nSilahkan ketik refresh")
                    else:
                        wait["dellbots"] = True
                        sendTextTemplate200(msg.to,"??Contact itu bukan anggota bot\nSilahkan ketik refresh")
#ADD STAFF
                 #if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        sendTextTemplate200(msg.to,"🛑Contact itu sudah jadi staff\nSilahkan ketik refresh")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        sendTextTemplate200(msg.to,"🛑Berhasil menambahkan ke staff\nSilahkan ketik refresh")
#                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        sendTextTemplate200(msg.to,"🛑Berhasil menghapus dari staff\nSilahkan ketik refresh")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        sendTextTemplate200(msg.to,"🛑Contact itu bukan staff\nSilahkan ketik refresh")
#ADD ADMIN
                 #if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        sendTextTemplate200(msg.to,"🛑Contact itu sudah jadi admin\nSilahkan ketik refresh")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        sendTextTemplate200(msg.to,"🛑Berhasil menambahkan ke admin\nSilahkan ketik refresh")
#                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        sendTextTemplate200(msg.to,"🛑Berhasil menghapus dari admin\nSilahkan ketik refresh")
                    else:
                        wait["delladmin"] = True
                        sendTextTemplate200(msg.to,"🛑Contact itu bukan admin\nSilahkan ketik refresh")
#ADD BLACKLIST
                 #if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        sendTextTemplate200(msg.to,"🛑Contact itu sudah ada di blacklist\nSilahkan ketik refresh")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        sendTextTemplate200(msg.to,"🛑Masuk daftar blacklist\nSilahkan ketik refresh")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        sendTextTemplate200(msg.to,"🛑Unbaned blacklist\nSilahkan ketik refresh")
                    else:
                        wait["dblacklist"] = True
                        sendTextTemplate200(msg.to,"🛑Contact itu tidak ada di blacklist")
#TALKBAN
                 #if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        sendTextTemplate200(msg.to,"🛑Contact itu sudah ada di Talkban\nSilahkan ketik refresh")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        sendTextTemplate200(msg.to,"🛑Berhasil menambahkan ke Talkban user\nSilahkan ketik refresh")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        sendTextTemplate200(msg.to,"🛑Berhasil menghapus dari Talkban user\nSilahkan ketik refresh")
                    else:
                        wait["Talkdblacklist"] = True
                        sendTextTemplate200(msg.to,"🛑Contact itu tidak ada di Talkban\nSilahkan ketik refresh")
#UPDATE FOTO
               if msg.contentType == 1:
                #if msg._from in admin:
                  if wait["Addimage"] == True:
                    try:
                        cl.downloadObjectMsg(msg.id,'path','dataFoto/'+wait["Img"]+'.jpg')
                        sendTextTemplate200(msg.to, "🛑Berhasil menambahkan gambar")
                        wait["Img"] = {}                
                        wait["Addimage"] = False
                    except Exception as e:
                        cl.downloadObjectMsg(msg.id,'path','dataFoto/'+wait["Img"]+'.jpg')
                        sendTextTemplate200(msg.to, "🛑Berhasil menambahkan gambar")
                        wait["Img"] = {}
                        wait["Addimage"] = False
               if msg.contentType == 2:
                #if msg._from in admin:
                  if wait["Addvideo"] == True:
                    try:
                        cl.downloadObjectMsg(msg.id,'path','dataVideo/'+wait["Video"]+'.mp4')
                        sendTextTemplate200(msg.to, "🛑Berhasil menambahkan video")
                        wait["Video"] = {}                
                        wait["Addvideo"] = False
                    except Exception as e:
                        cl.downloadObjectMsg(msg.id,'path','dataVideo/'+wait["Video"]+'.mp4')
                        sendTextTemplate200(msg.to, "🛑Berhasil menambahkan video")
                        wait["Video"] = {}
                        wait["Addvideo"] = False
               if msg.toType == 2:
                 #if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     cl.updateGroupPicture(to, path)
                     sendTextTemplate200(msg.to, "🛑Success")
               if msg.contentType == 1:
                   #if msg._from in admin:
                       if clMID in wait["changeFoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del wait["changeFoto"][clMID]
                            cl.updateProfilePicture(path)
                            sendTextTemplate200(msg.to,"🛑Foto berhasil dirubah")
                   #if msg._from in admin:
                       if clMID in settings["changeCover"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del settings["changeCover"][clMID]
                            cl.updateProfileCover(path)
                            sendTextTemplate200(msg.to, "🛑Updated")                                                            

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "chatbot on":
                            #if msg._from in admin:
                                wait["selfbot"] = True
                                ret = "Chatbot Enable."
                                cl.sendMessage(to, str(ret))

                        elif cmd == comd["help"]:
                          #if msg._from in admin:
                             #contact = cl.getProfile()
                             #mids = [contact.mid]
                             #cover = cl.getProfileCoverURL(sender)
                             #listTimeLiking = time.time()
                             #tz = pytz.timezone("Asia/Jakarta")
                             #timeNow = datetime.now(tz=tz)
                             ginfo = cl.getChats([to],True,True).chats[0]
                             data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX", 
                                       "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "   ⚙️ ᴹᵉⁿᵘ \n   ⚙️ ᴹᵉⁿᵘ1 \n   ⚙️ ᴹᵉⁿᵘ2 \n   ⚙️ ᴹᵉⁿᵘ3 \n   ⚙️ ᴹᵉⁿᵘ4 \n   ⚙️ ᴹᵉⁿᵘ5 \n   ⚙️ ᴹᵉⁿᵘ6 \n   ⚙️ ᴹᵉⁿᵘ7 \n  ⚙️ ᴹᵉⁿᵘ8 \n  ⚙️ ᴴᵉˡᵖ \n   ⚙️ ᴴᵉˡᵖ1\n   ⚙️ !ᴘʀᴏᴍᴀx ᴏɴ/ᴏғғ\n   ⚙️ !ᴘʀᴏɪɴᴠɪᴛᴇ ᴏɴ/ᴏғғ\n   ⚙️ !ᴘʀᴏᴋɪᴄᴋ ᴏɴ/ᴏғғ\n   ⚙️ !ᴘʀᴏǫʀ ᴏɴ/ᴏғғ\n   ⚙️ !ᴘʀᴏᴊᴏɪɴ ᴏɴ/ᴏғғ",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  TEAM TERMUX", 
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "5px",
                "offsetTop": "2px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⚙️ ᴍᴇ\n⚙️ ᴄᴠᴘ\n⚙️ sᴇᴛᴛɪɴɢ\n⚙️ ʀᴜɴᴛɪᴍᴇ\n⚙️ sᴘᴇᴇᴅ-sᴘ\n⚙️ clear chat\n⚙️ ʙʏᴇᴍᴇ\n⚙️ ʀᴇᴊᴇᴄᴛ\n⚙️ ʟᴇᴀᴠᴇᴀʟʟ\n⚙️ ʟɪsᴛғʀɪᴇɴᴅ\n⚙️ ғʀɪᴇɴᴅʟɪsᴛ\n⚙️ ɢʀᴜᴘʟɪsᴛ\n⚙️ ᴏᴘᴇɴ ǫʀ\n⚙️ ᴄʟᴏsᴇ ǫʀ\n⚙️ ᴛᴀɢᴀʟʟ\n⚙️ ɪɴᴠɪᴛᴇ @\n⚙️ ʙʟᴏᴄᴋ @",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX", 
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⚙️ ʙᴏᴛᴀᴅᴅ「@」\n⚙️ ʙᴏᴛᴅᴇʟʟ「@」\n⚙️ sᴛᴀғғ「@」\n ⚙️ sᴛᴀғᴅᴇʟʟ「@」\n⚙️ ᴀᴅᴍɪɴ「@」\n⚙️ ᴀᴅᴍɪɴᴅᴇʟʟ「@」\n⚙️ ʀᴇʙᴏᴏᴛ\n⚙️ ʙᴀɴ「@\n⚙️ ʙʟ\n⚙️ ʙᴀɴ:ᴏɴ\n⚙️ ᴜɴʙᴀɴ:oɴ\n⚙️ ᴜɴʙᴀɴ「@」\n⚙️ ʙᴀɴʟɪsᴛ\n⚙️ ᴄʙᴀɴ\n⚙️ ʀᴇғʀᴇsʜ\n⚙️ ᴊᴏɪɴᴛɪᴄᴋᴇᴛ oɴ/oғғ",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "TEAM TERMUX", 
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⚙️ ɢᴍɪᴅ @\n⚙️ ɢᴇᴛ ɪᴅ @\n⚙️ ɢᴇᴛᴍɪᴅ @\n⚙️ ɢᴇᴛʙɪᴏ @\n⚙️ ɢᴇᴛɪɴғᴏ @\n⚙️ ɢᴇᴛᴘʀᴏғɪʟᴇ @\n⚙️ ɢᴇᴛᴘɪᴄᴛᴜʀᴇ @\n⚙️ ɪɴғᴏ @\n⚙️ ᴋᴇᴘᴏ @\n⚙️ ᴘᴘᴠɪᴅᴇᴏ @\n⚙️ ᴋᴏɴᴛᴀᴋ @\n⚙️ ᴄᴏɴᴛᴀᴄᴛ:「ᴍɪᴅ」\n⚙️ ɢɴᴀᴍᴇ「ᴛᴇxᴛ」\n⚙️ ᴍʏᴍɪᴅ\n⚙️ ᴍʏʙɪᴏ\n⚙️ ᴍʏғᴏᴛᴏ\n⚙️ ᴀᴜᴛᴏʟᴇᴀᴠᴇ oɴ/oғғ \n⚙️ ᴀᴜᴛᴏʙʟᴏᴄᴋ oɴ/oғғ",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  TEAM TERMUX", 
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "size": "full",
            "gravity": "top",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⚙️ ᴄᴇᴋ sɪᴅᴇʀ\n⚙️ ᴄᴇᴋ ʟᴇᴀᴠᴇ \n⚙️ ᴄᴇᴋ ᴘᴇsᴀɴ \n⚙️ ᴄᴇᴋ ʀᴇsᴘᴏɴ \n⚙️ ᴄᴇᴋ ʀᴇsᴘᴏɴ² \n⚙️ sᴇᴛ sɪᴅᴇʀ: ᴛᴇxᴛ \n⚙️ sᴇᴛ ᴘᴇsᴀɴ: ᴛᴇxᴛ \n⚙️ sᴇᴛ ʀᴇsᴘᴏɴ: ᴛᴇxᴛ \n⚙️ sᴇᴛ ʀᴇsᴘᴏɴ²: ᴛᴇxᴛ \n⚙️ sᴇᴛ ᴡᴇʟᴄᴏᴍᴇ:  \n⚙️ sᴇᴛ ʟᴇᴀᴠᴇ: ᴛᴇxᴛ\n⚙️ ʟɪᴋᴇ ᴏɴ/ᴏғғ \n⚙️ ᴘᴏsᴛ oɴ/oғғ \n⚙️ sᴛɪᴄᴋᴇʀ oɴ/oғғ \n⚙️ ɪɴᴠɪᴛᴇ oɴ/ᴏғғ \n⚙️ ᴜɴsᴇɴᴅ oɴ/oғғ \n⚙️ ʀᴇsᴘᴏɴ oɴ/oғғ \n⚙️ ʀᴇsᴘᴏɴ² oɴ/oғғ \n⚙️ ᴀᴜᴛᴏᴀᴅᴅ oɴ/oғғ \n⚙️ ᴡᴇʟᴄᴏᴍᴇ oɴ/oғғ \n⚙️ ᴄᴏɴᴛᴀᴄᴛ oɴ/oғғ",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  TEAM TERMUX", 
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    }
  ]
}
}                           
                             sendTemplate(to, data)                                    
                            
                        elif cmd == comd["help1"]:
                          #if msg._from in admin:
                             #contact = cl.getProfile()
                             #mids = [contact.mid]
                             #cover = cl.getProfileCoverURL(sender)
                             #listTimeLiking = time.time()
                             #tz = pytz.timezone("Asia/Jakarta")
                             #timeNow = datetime.now(tz=tz)
                             ginfo = cl.getChats([to],True,True).chats[0]
                             data = {
                                       "type": "flex",
                                       "altText": "TEAM TERMUX", 
                                       "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " ⚙️ Addsticker\n⚙️ Addmp3\n⚙️ Addaudio\n⚙️ Addimg\n⚙️ Dellsticker\n⚙️ Dellaudio\n⚙️ Dellmp3\n⚙️ Dellvideo\n⚙️ Dellimg\n⚙️ Liststicker\n⚙️ Listimage\n ⚙️ Listvideo\n⚙️ Listaudio\n⚙️ Listmp3\n⚙️ Lihat「No」\n⚙️ Cctv metro",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  TEAM TERMUX", 
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "5px",
                "offsetTop": "2px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⚙️ ᴀᴅᴅᴍᴇ「@」\n⚙️ ᴍʏʙᴏᴛ\n⚙️ sambutan on/off\n⚙️ leave on/off\n⚙️ ʟɪsᴛᴘᴇɴᴅɪɴɢ\n⚙️ ʙʟᴏᴄᴋᴄᴏɴᴛᴀᴄᴛ\n⚙️ ʟᴋsᴛʙʟᴏᴄᴋ\n⚙️ ᴀᴜᴛᴏᴊᴏɪɴ oɴ/oғғ \n⚙️ ᴀᴜᴛᴏʀᴇᴊᴇᴄᴛ oɴ/oғғ \n⚙️ ʟɪsᴛᴍɪᴅ\n⚙️ ᴀᴅᴅᴀsɪs\n⚙️ ʙʀᴏᴀᴅᴄᴀsᴛ:「ᴛᴇxᴛ」\n⚙️ Smule「id」\n⚙️ Joox「text」\n⚙️ mp4「text」\n⚙️ mp3「text」\n⚙️ Yutube「text」\n⚙️ Ytvid「text」",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  TEAM TERMUX", 
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⚙️ ᴍʏɴᴀᴍᴇ\n⚙️ ᴍʏᴘʀᴏғɪʟᴇ\n⚙️ ᴍʏᴘɪᴄᴛᴜʀᴇ\n⚙️ ᴍʏᴄᴏᴠᴇʀ\n⚙️ ᴍʏᴠɪᴅᴇᴏ\n⚙️ ᴋᴀʟᴇɴᴅᴇʀ\n⚙️ ᴍᴇᴍᴘɪᴄᴛ\n⚙️ ᴜᴘᴅᴀᴛᴇɢʀᴜᴘ\n⚙️ ɢʀᴜᴘᴘɪᴄᴛ\n⚙️ ɪɴғᴏɢʀᴏᴜᴘ「ɴᴏ」\n⚙️ ɪɴғᴏᴍᴇᴍ「ɴᴏ」\n⚙️ smule on/off \n⚙️ yt on/off \n⚙️ call on/off \n⚙️ gusur \n⚙️ ange",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  TEAM TERMUX", 
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⚙️ ˢⁱᵇᵘᵏ ᵒⁿ \n⚙️ ˢᵖᵃᵐᶜᵃˡˡ ᵒⁿ \n⚙️ ᴾᵃⁿᵍᵍⁱˡ ⁿᵒ @\n⚙️ ˢᵗᵃᵍ: ⁿᵒ \n⚙️ ˢᶜᵃˡˡ: ⁿᵒ \n ⚙️ ˢᵗᵃᵍ @ \n⚙️ ˢᶜᵃˡˡ \n⚙️ ᵀⁱᵏᵗᵒᵏ ᵒⁿ \n⚙️ ʸᵗ ᵒⁿ \n⚙️ !ˢᵐᵘˡᵉ ᵒⁿ \n⚙️ ᴶᵒᵒˣ ᴶᵘᵈᵘˡ \n⚙️ ᴹʸ ˡᵒᵛᵉ @\n⚙️ ᴵⁿᵛᵈᵐⁱᵈ [ᴹⁱᵈ]\n⚙️ ᵁⁿˢ \n⚙️ ᴮᵒᵗᶜʰᵃᵗ ᵒⁿ\n⚙️ ᴮᵈᵃʸ @\n⚙️ ɢᴇᴛᴄᴀʟʟ\n⚙️ ᴠᴄᴀʟʟ\n⚙️ ᴘᴜsᴋᴜɴ ᴏɴ/ᴏғғ\n⚙️ sᴇʟɪɴɢ ᴏɴ/ᴏғғ ",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  TEAM TERMUX", 
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/9tdnpsd/1652980705963.jpg",
            "size": "full",
            "gravity": "top",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co.com/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⚙️ setjs:「ᴛᴇxᴛ」\n⚙️ .js\n⚙️ nukers on/off\n⚙️ nuke on/off\n⚙️ Koment Bypas\n⚙️ setbypas:「ᴛᴇxᴛ」\n⚙️ gusur 「ɴᴏ」\n⚙️ gasak「ɴᴏ」\n⚙️ !desah \n⚙️ !pass \n⚙️ !gasak \n⚙️ !go\n⚙️ Set sideron: 「ᴛᴇxᴛ」\n ⚙️ Set sideroff: 「ᴛᴇxᴛ」\n⚙️ Set mention: 「ᴛᴇxᴛ」",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "  TEAM TERMUX", 
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    }
  ]
}
}                            
                             sendTemplate(to, data)              
                                                       
                        elif cmd == "chatbot off":
                            #if msg._from in admin:
                                wait["selfbot"] = False
                                ret = "Chatbot Disable"
                                cl.sendMessage(to, str(ret))

                        elif cmd == "clear":
                            #if msg._from in admin:
                                process = os.popen('cd /tmp/ && rm -r *')
                                a = process.read()
                                ret = "Cleared Temp File"
                                cl.sendMessage(to, str(ret))
    
                        elif cmd == "menu":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ret = "1. • remote\n"
                                ret += "2. • group\n"
                                ret += "3. • profile\n"
                                ret += "4. • baned\n"
                                ret += "5. • setting\n"
                                ret += "6. • protect\n"
                                ret += "7. • Translete\n"
                                ret += "8. • Admin\n"
                                ret += "9. • Help js\n"
                                sendTextTemplate25(to, str(ret))    
                                
                        elif cmd == "remote":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ret = "• Tag: (numb)\n"
                                ret += "• Gurl (numb)\n"
                                ret += "• Bye: (numb)\n"
                                ret += "• Close(numb)\n"
                                ret += "• Infogrup (numb)\n"
                                ret += "• Infomem (numb)\n"
                                ret += "• Bantai: (numb)"
                                sendTextTemplate200(to, str(ret))    
    
                        elif cmd == "group":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ret = "• Me\n"
                                ret += "• Mid\n"
                                ret += "• Addfriend @\n"
                                ret += "• Block @\n"
                                ret += "• Cek @\n"
                                ret += "• Find @\n"
                                ret += "• Rename @\n"
                                ret += "• Mid @\n"
                                ret += "• Speed|Sp\n"
                                ret += "• Stag\n"
                                ret += "• Tag\n"
                                ret += "• Tagall sticker\n"
                                ret += "• Ginfo\n"
                                ret += "• Buka qr\n"
                                ret += "• Tutup qr\n"
                                ret += "• @bye\n"
                                ret += "• Url\n"
                                ret += "• Idline (idline)\n"
                                ret += "• Gruplist\n"
                                ret += "• Gnamegrup (text)\n"
                                ret += "• Call @\n"
                                ret += "• Fotgbc (Text)\n"
                                ret += "• Fotfbc (Text)\n"
                                ret += "• Flexgbc (Text)\n"
                                ret += "• Flexfbc (Text)\n"
                                ret += "• Clearallfriend\n"
                                ret += "• Clearchat\n"
                                ret += "• Refresh\n"
                                ret += "• Sider (on|off)\n"
                                ret += "• Broadcast: (Text)\n"
                                ret += "• Setkey (key)\n"
                                ret += "• Mykey\n"
                                ret += "• Resetkey\n"
                                ret += "• Unsend (numb)\n"
                                ret += "• Jumlah: (jumlh)\n"
                                ret += "• Spamtag (jumlh)\n"
                                ret += "• Spamtag @ (jumlh)\n"
                                ret += "• Spamcall (numb)\n"
                                ret += "• Spamcall: (jumlh)\n"
                                ret += "• Spamcall\n"
                                ret += "• Gift: (mid)(jumlh)\n"
                                ret += "• Spam: (mid)(jumlh)\n"
                                ret += "• Spam on|jumlah|text\n"
                                ret += "• Tag (jumlah di pm)"
                                sendTextTemplate200(to, str(ret))

                        elif cmd == "profile":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ret = "• Myname\n"
                                ret += "• Mybio\n"
                                ret += "• Mypict\n"
                                ret += "• Myvideo\n"
                                ret += "• Steal @\n"
                                ret += "• Video @\n"
                                ret += "• Pict @\n"
                                ret += "• Cover\n"
                                ret += "• Bio\n"
                                ret += "• Name:\n"
                                ret += "• Cvp: (link yt)"
                                sendTextTemplate200(to, str(ret))

                        elif cmd == "admin":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ret = "• Blc\n"
                                ret += "• Cban\n"
                                ret += "• Bot:on\n"
                                ret += "• Bot:repeat\n"
                                ret += "• Staff:on\n"
                                ret += "• Staff:repeat\n"
                                ret += "• Admin:on\n"
                                ret += "• Admin:repeat\n"
                                ret += "• Botadd @\n"
                                ret += "• Botdell @\n"
                                ret += "• Staffadd @\n"
                                ret += "• Staffdell @\n"
                                ret += "• Adminadd @\n"
                                ret += "• Admindell @\n"
                                ret += "• Kick @\n"
                                ret += "• Ulti @"
                                sendTextTemplate200(to, str(ret))

                        elif cmd == "baned":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ret = "• Blc\n"
                                ret += "• Banlist\n"
                                ret += "• Cban\n"
                                ret += "• Ban:on\n"
                                ret += "• Unban:on\n"
                                ret += "• Ban @\n"
                                ret += "• Unban @\n"
                                ret += "• Talkban @\n"
                                ret += "• Untalkban @\n"
                                ret += "• Talkbanlist @"
                                sendTextTemplate200(to, str(ret))

                        elif cmd == "setting":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ret = "• protect on\n"
                                ret = "• protect:on/off (no gc)\n"
                                ret = "• CekSider\n"
                                ret += "• CekSpam\n"
                                ret += "• CekPesan\n"
                                ret += "• CekRespon\n"
                                ret += "• Cekwelcome\n"
                                ret += "• CekLeave\n"
                                ret += "• Cekcomment\n"
                                ret += "• Sticker tag\n"
                                ret += "• Sticker sider\n"
                                ret += "• Sticker pesan\n"
                                ret += "• Sticker Welcome\n"
                                ret += "• Sticker Leave\n"
                                ret += "• Setreject: (jumlah)\n"
                                ret += "• Setliff: (liff ny)\n"
                                ret += "• Setsider: (Text)\n"
                                ret += "• Setcomment: (Text)\n"
                                ret += "• Setwelcome: (Text)\n"
                                ret += "• Setleave: (Text)\n"
                                ret += "• respon1 on/off\n"
                                ret += "• Setrespon1: (Text)\n"
                                ret += "• Setcall: (Text)\n"
                                ret += "• Setcall1: (Text)\n"
                                ret += "• Setrespon: (Text)\n"
                                ret += "• Setpesan: (Text)\n"
                                ret += "• Setcban: (Text)\n"
                                ret += "• Setbye: (Text)\n"
                                ret += "• Sethelp: (Text)\n"
                                ret += "• Setspeed: (Text)\n"
                                ret += "• sider2 on/off\n"
                                ret += "• Setsider2:(Text)\n"
                                ret += "• Setsider on: (Text)\n"
                                ret += "• Setsider off: (Text)\n"
                                ret += "• Setkick: (Text)\n"
                                ret += "• Settagall: (Text)\n"
                                ret += "• Setunsend: (Text)\n"
                                ret += "• Myname: (Text)\n"
                                ret += "• Udatefoto\n"
                                ret += "• Updategrup\n"
                                ret += "• Autojoin (On|Off)\n"
                                ret += "• Autochat (On|Off)\n"
                                ret += "• Autoleave (On|Off)\n"
                                ret += "• Autoread (On|Off)\n"
                                ret += "• Autoblock (On|Off)\n"
                                ret += "• Autolike (On|Off)\n"
                                ret += "• Respon (On|Off)\n"
                                ret += "• Respon2 (On|Offa)\n"
                                ret += "• Responcall (On|Off)\n"
                                ret += "• Sticker (On|Off)\n"
                                ret += "• Unsend (On|Off)\n"                              
                                ret += "• Contact: (On|Off)\n"
                                ret += "• Autoadd (On|Off)\n"
                                ret += "• Jointicket (On|Off\n"
                                ret += "• Welcomemsg (On|Off)\n"
                                ret += "• Leavemsg (On|Off)"
                                ret += "• Snule (On|Off)"
                                ret += "• Tiktok url (On|Off)"
                                ret += "• Yt url (On|Off)"
                                sendTextTemplate200(to, str(ret))

                        elif cmd == "media":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ret = "• Addsticker: (Text)\n"
                                ret += "• Dellsticker: (Text)\n"
                                ret += "• Stickerlist\n"
                                ret += "• Addtext: (Text)\n"
                                ret += "• Deltext: (Text)\n"
                                ret += "• List text\n"
                                ret += "• Corona\n"
                                ret += "• Info bmkg\n"
                                ret += "• Acara tv\n"
                                ret += "• Info loker\n"
                                ret += "• Ciname xx1\n"
                                ret += "• Fs (text)\n"
                                ret += "• Cctv code\n"
                                ret += "• Cctv (number)\n"
                                ret += "• Github (search)\n"
                                ret += "• Ytmp3 (query)\n"
                                ret += "• Ytmp4 (query )\n"
                                ret += "• Porn (search)\n"
                                ret += "• Randomname\n"
                                ret += "• Lyrik (search)\n"
                                ret += "• Joox: (search)\n"
                                ret += "• Cuaca (wilayah)\n"
                                ret += "• Sholat (wilayah)\n"
                                ret += "• Surahlist\n"
                                ret += "• Surah (ayat)\n"
                                ret += "• Fancytext (text)\n"
                                ret += "• Acaratv (search)\n"
                                ret += "• Zodiak (bintang)\n"
                                ret += "• Instagram (search)\n"
                                ret += "• Ponsel (type)\n"
                                ret += "• Google (search)\n"
                                ret += "• Resi-jnt: (resi)\n"
                                ret += "• Resi-pos: (resi)\n"
                                ret += "• Resi-rex: (resi)\n"
                                ret += "• Resi-ninja: (resi)\n"
                                ret += "• Resi-sicepat: (resi)\n"
                                ret += "• Anime: (search)\n"
                                sendTextTemplate200(to, str(ret))

                        #elif cmd == "protect":
                          #if wait["selfbot"] == True:
                            ##if msg._from in admin:
                                #ret += "• Notag On|Off\n"
                                #ret += "• Pinvite On|Off\n"
                                #ret += "• Pqr On|Off\n"
                                #ret += "• Pjoin On|Off \n"
                                #ret += "• Pkick On|Off\n"
                                #ret += "• Pcancell On|Off"
                                #sendTextTemplate200(to, str(ret))

                        elif cmd == "translate":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ret = "❑ Indo: Text\n"
                                ret += "❑ Jawa: Text\n"
                                ret += "❑ Jp: Text\n"
                                ret += "❑ Thai: Text\n"
                                ret += "❑ Eng: Text\n"
                                ret += "❑ Arab: Text\n"
                                ret += "❑ Korea: Text\n"
                                ret += "❑ India: Text\n"
                                ret += "❑ China: Text\n"
                                ret += "❑ Rusia: Text\n"
                                ret += "❑ Spanyol: Text\n"
                                ret += "❑ Franchis: Text\n"
                                ret += "❑ Malay: Text\n"
                                ret += "❑ Itali: Text\n"
                                ret += "❑ Filipin: Text\n"
                                ret += "❑ Turki: Text\n"
                                ret += "❑ Vietnam: Text\n"
                                ret += "❑ Belanda: Text\n"
                                ret += "❑ German: Text"
                                sendTextTemplate200(to, str(ret))

                        elif cmd == "cmd list":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                vian = "╭─「👥 Cmd List 👥」\n"
                                for u in comd:
                                    vian += "├❑ {} : {}\n".format(u,comd[u])
                                vian += '╰────────'
                                cl.sendMessage(to, str(vian))
                            
                        elif cmd.startswith("footgbc"):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                khie = text.split(" ")
                                hey = text.replace(khie[0] + " ", "")
                                text = "{}".format(hey)
                                groups = cl.getAllChatIds()
                                for gr in groups:
                                    flextezt(gr, text)
 
                        elif cmd.startswith("textgbc "):
                            #if msg._from in admin:
                                sep = text.split(" ")
                                bc = text.replace(sep[0] + " ","")
                                saya = cl.getAllChatIds()
                                for rom in saya:
                                    cl.sendMessage(rom,"🛑BROADCAST \n\n"+bc)
                                cl.sendMessage(msg.to, "🛑Berhasil broadcast ke {} group".format(str(len(saya))))
 
                        elif cmd.startswith("flexgbc "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                rah = text.split(" ")
                                matt = text.replace(rah[0] + " ","")
                                chat = "{}".format(matt)
                                groups = cl.getAllChatIds()
                                for gr in groups:
                                    cl.sendMessage(gr, chat)
                        elif text.lower() == "mid" or text.lower() == "mid":
                            data = {"type": "text","text": "{}".format(msg._from),"sentBy":{"label": " • TEAM TERMUX•","iconUrl": "https://i.ibb.co.com/DkxfZFn/de9b402e111bc99dc7c5d2609cea06db.gif","linkUrl": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6"}}
                            sendTemplate(to, data)
                                
#____________DATA_PROMO________  

                        elif cmd == "me" or text.lower() == 'aku':
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                sendMention(to, sender, "「USER SB」\n", "")                                
                                cl.sendContact(to, sender)
                               
                        elif cmd.startswith("flexfbc "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                rah = text.split(" ")
                                matt = text.replace(rah[0] + " ","")
                                chat = "{}".format(matt)
                                friends = cl.getAllContactIds()
                                for friend in friends:
                                    cl.sendMessage(friend, chat)
                                    time.sleep(1)
                                cl.sendMessage(msg.to, "🛑Succes friend cast to {} friend ".format(str(len(friends))))
                            
                        elif cmd.startswith("fotfbc"):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                khie = text.split(" ")
                                hey = text.replace(khie[0] + " ", "")
                                text = "{}".format(hey)
                                groups = cl.getAllChatIds()
                                for friend in friends:
                                    cl.sendMessage(friend, text)
                              
                        elif cmd == "status":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                #tz = pytz.timezone("Asia/Jakarta")
                                #timeNow = datetime.now(tz=tz)
                                md = "╭─「 STATUS BOTS 」\n"
                                if wait["ytube"] == True: md+="├ ✓  ❑ Youtube Url\n"
                                else: md+="├ ✗  ❑ Youtube Url\n"
                                if wait["tiktok"] == True: md+="├ ✓  ❑ Tiktok Url\n"
                                else: md+="├ ✗  ❑ Tiktok Url\n"
                                if wait["rsmule"] == True: md+="├ ✓  ❑ Smule\n"
                                else: md+="├ ✗  ❑ Smule\n"
                                if wait["sticker"] == True: md+="├ ✓  ❑ Sticker\n"
                                else: md+="├ ✗  ❑ Sticker\n"
                                if wait["contact"] == True: md+="├ ✓  ❑ Contact\n"
                                else: md+="├ ✗  ❑ Contact\n"
                                if wait["unsend"] == True: md+="├ ✓  ❑ Unsend\n"
                                else: md+="├ ✗  ❑ Unsend\n"
                                if wait["Timeline"] == True: md+="├ ✓  ❑ Timeline\n"
                                else: md+="├ ✗  ❑ Timeline\n"
                                if wait["respontag"] == True: md+="├ ✓  ❑ Respon\n"
                                else: md+="├ ✗  ❑ Respon\n"
                                if temptag["stealtag"] == True: md+="├ ✓  ❑ Respon2\n"
                                else: md+="├ ✗  ❑ Respon2\n"
                                if wait["autoBlock"] == True: md+="├ ✓  ❑ Auto Block\n"
                                else: md+="├ ✗  ❑ Auto Block\n"
                                if wait["talkban"] == True: md+="├ ✓  ❑ Talkban\n"
                                else: md+="├ ✗  ❑ Talkban\n"
                                if wait["Mentionkick"] == True: md+="├ ✓  ❑ Notag\n"
                                else: md+="├ ✗  ❑ Notag\n"
                                if wait["detectMention"] == True: md+="├ ✓  ❑ Respon2\n"
                                else: md+="├ ✗  ❑ Respon2\n"
                                if wait["autoJoin"] == True: md+="├ ✓  ❑ Autojoin\n"
                                else: md+="├ ✗  ❑ Autojoin\n"
                                if wait["autoCancel"]["on"] == True: md+="├ ✓  ❑ AutoReject : " + str(wait["autoCancel"]["members"]) + "\n"
                                else: md+="├ ✗  ❑ AutoReject\n"
                                if wait["autoAdd"] == True: md+="├ ✓  ❑ Autoadd\n"
                                else: md+="├ ✗  ❑ Autoadd\n"
                                if wait["likeOn"] == True: md+="├ ✓  ❑ Autolike\n"
                                else: md+="├ ✗  ❑ Autolike\n"
                                if wait["responGc"] == True: md+="├ ✓  ❑ Respon Gc\n"
                                else: md+="├ ✗  ❑ Respon Gc\n"
                                if msg.to in welcome: md+="├ ✓  ❑ Welcome\n"
                                else: md+="├ ✗  ❑ Welcome\n"
                                if wait["autoLeave"] == True: md+="├ ✓  ❑ Autoleave\n"
                                else: md+="├ ✗  ❑ Autoleave\n"
                                if msg.to in protectqr: md+="├ ✓  ❑ Protectqr\n"
                                else: md+="├ ✗  ❑ Protectqr\n"
                                if msg.to in protectjoin: md+="├ ✓  ❑ ProtectJoin\n"
                                else: md+="├ ✗  ❑ ProtectJoin\n"
                                if msg.to in protectkick: md+="├ ✓  ❑ ProtectKick\n"
                                else: md+="├ ✗  ❑ ProtectKick\n"
                                if msg.to in protectcancel: md+="├ ✓  ❑ ProtectCancell\n"
                                else: md+="├ ✗  ❑ ProtectCancell\n"
                                if msg.to in protectinvite: md+="├ ✓  ❑ ProtectInvite\n╰─❑ Soak-Bots ❑"
                                else: md+="├ ✗  ❑ ProtectInvite\n╰───────────────"
                                sendTextTemplate200(to, str(md))
                                                                
                        elif cmd == "rejectall":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ginvited = cl.getGroupIdsInvited()
                                if ginvited != [] and ginvited != None:
                                    for gid in ginvited:
                                        cl.rejectGroupInvitation(gid)
                                    sendZulBots3(msg.to, "🛑Rejected {} Group Invite".format(str(len(ginvited))))
                                else:
                                    sendZulBots3(msg.to, "🛑Nothing")
                                
                        elif cmd == "cancelall":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                if msg.toType == 2:
                                    group = cl.getChats(to)
                                    if group.invitee is None or group.invitee == []:
                                        cl.sendMessage(msg.to, "🛑Nothing")
                                    else:
                                        invitee = [contact.mid for contact in group.invitee]
                                        for inv in invitee:
                                            cl.cancelChatInvitation(to, [inv])
                                        cl.sendMessage(msg.to, "🛑Cancelled {} Group Pending".format(str(len(invitee))))
                                
                        elif cmd == "accept:all":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                if msg.toType == 2:
                                    group = cl.getChats(to)
                                    if group.invitee is None or group.invitee == []:
                                        cl.sendMessage(msg.to, "🛑No Have Groups Invitation.")
                                    else:
                                        invitee = [contact.mid for contact in group.invitee]
                                        for acc in invitee:
                                            cl.acceptChatInvitation(to, [acc])
                                        cl.sendMessage(msg.to, "🛑Join {} Groups".format(str(len(invitee))))
                              
                        elif cmd == "logout":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                sendZulBots3(msg.to, "🛑Logout Success ♪")
                                sys.exit("Logout")
                               
                        elif cmd == "help js":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               helpMessage1 = helpjs()
                               cl.sendMessage(to, str(helpMessage1))
                              
                        elif cmd == "about":
                            if wait["selfbot"] == True:
                                #if msg._from in admin:
                                    try:
                                        arr = []
                                        today = datetime.today()
                                        thn = 2018 
                                        bln = 8    #isi bulannya yg sewa
                                        hr = 9   #isi tanggalnya yg sewa
                                        future = datetime(thn, bln, hr)
                                        days = (str(future - today))
                                        comma = days.find(",")
                                        days = days[:comma]
                                        h = cl.getContact(clMID)
                                        groups = cl.getAllChatIds()
                                        contactlist = cl.getAllContactIds()
                                        kontak = cl.getContacts(contactlist)
                                        favorite = cl.getFavoriteMids()
                                        fil = cl.getSettings().privacyReceiveMessagesFromNotFriend
                                        seal = cl.getSettings().e2eeEnable
                                        blockedlist = cl.getBlockedContactIds()
                                        src = cl.getSettings().privacySearchByUserid
                                        kontak2 = cl.getContacts(blockedlist)
                                        status = {"kick": "", "invite": ""}
                                        peler = {"receivercount": 0, "sendcount": 0}
                                        try:cl.deleteOtherFromChat(to, [clMID]);status["kick"] = "Normal"
                                        except:status["kick"] = "Limit"
                                        try:cl.inviteIntoChat(to, [clMID]);status["invite"] = "Normal"
                                        except:status["invite"] = "Limit"
                                        if src == True:alid = "Add From LineID : True"
                                        else:alid = "Add From LineID : False"                            
                                        if seal == True:letsel = "Letter Sealing : True"
                                        if seal == False:letsel = "Letter Sealing : False"
                                        if fil == True:fpes = "Filter Message : False"
                                        if fil == False:fpes = "Filter Message : True"
                                        kontol = "╭── • ABOUT SELFBOT • ──"
                                        kontol += "\n├ ◌ User : {}".format(h.displayName)
                                        kontol += "\n├ ◌ Group : {}".format(str(len(groups)))
                                        kontol += "\n├ ◌ Friend : {}".format(str(len(kontak)))
                                        kontol += "\n├ ◌ Favorite: {}".format(str(len(favorite)))
                                        kontol += "\n├ ◌ Blocked : {}".format(str(len(kontak2)))
                                        kontol += "\n├ ◌ Chat send : {}".format(str(peler["sendcount"]))
                                        kontol += "\n├ ◌ Chat received : {}".format(str(peler["receivercount"]))
                                        kontol += "\n├ ◌ {}".format(alid)
                                        kontol += "\n├ ◌ {}".format(letsel)
                                        kontol += "\n├ ◌ {}".format(fpes)
                                        kontol += "\n├ ◌ Kick : %s" % status["kick"]
                                        kontol += "\n├ ◌ Invite : %s" % status["invite"]
                                        kontol += "\n├ ◌ Type : Selfbot"
                                        kontol += "\n├ ◌ Version : V3\n╰────────────────"
                                        sendTextTemplate200(to, str(kontol))
                                    except Exception as e:
                                        cl.sendReplyMessage(msg.id,to, str(e))
                               
                        elif cmd.startswith("mid "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendReplyMessage(msg.id,to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)
                               cl.sendMessage(to, None, contentMetadata={'mid': key1}, contentType=13)

                        elif ("Steal " in msg.text):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendReplyMessage(msg.id,to, "╭─「 Contact Info 」\n│ Nama : "+str(mi.displayName)+"\n│ Mid : " +key1+"\n│ Status Msg"+str(mi.statusMessage))
                               cl.sendMessage(to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   cl.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   cl.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif ("/ti/g/" in msg.text):
                           if msg._from in admin or msg._from in staff:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                    if l not in n_links:
                                       n_links.append(l)
                                 for ticket_id in n_links:
                                    group = cl.findGroupByTicket(ticket_id)
                                    cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    cl.sendMessage(msg.to, "🛑Masuk : %s" % str(group.name))

                        elif text.lower() == "rchat":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:                     
                               sendZulBots3(msg.to, "🛑Cleared messages")
                               cl.removeAllMessages(op.param2)                              
                               

                        elif text.lower() == "clearchat1":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               try:
                                   gid = cl.getAllChatMids(True, True).memberChatMids
                                   for i in gid:
                                       cl.sendChatRemoved(i, "560993691650228514")
                                       time.sleep(0.5)
                                   cl.sendMessage(msg.to, "Cleared messages")
                               except:
                                   pass
                                
                        elif cmd.startswith("broadcast: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:  
                                sep = text.split(" ")
                                txt = text.replace(sep [0] + " ","")
                                groups = cl.getAllChatIds()
                                for group in groups:
                                    cl.sendMessage(group, "{}".format(str(txt)))
                                cl.sendMessage(msg.to, "🛑Broadcast {} Group".format(str(len(groups))))

                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               cl.sendMessage(msg.to, "🛑Setkey Anda: " + str(Setmain["keyCommand"]))
                               
                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "🛑Gagal mengganti key")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   cl.sendMessage(msg.to, "🛑Update to {}".format(str(key).lower()))

                        elif cmd.startswith("setsider: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "🛑Gagal mengganti key")
                               else:
                                   wait["mention"] = str(key).lower()
                                   cl.sendMessage(msg.to, "🛑Update to {}".format(str(key).lower()))
                        elif cmd.startswith("setsider1: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "🛑Gagal mengganti key")
                               else:
                                   wait["mention"] = str(key).lower()
                                   cl.sendMessage(msg.to, "🛑Update to {}".format(str(key).lower()))
                        elif cmd.startswith("setreject: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "🛑Failed..!!")
                               else:
                                   wait["autoCancel"]["members"] = str(key).lower()
                                   cl.sendMessage(msg.to, "🛑Auto reject set to {}".format(str(key).lower()))

                        elif cmd.startswith("setapikey: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "🛑Gagal mengganti key")
                               else:
                                   wait["apikey"] = str(key).lower()
                                   cl.sendMessage(msg.to, "🛑Success update apikey")
                        
                        elif 'Set welcome: ' in msg.text:
                           #if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate200(msg.to, "🛑Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  sendTextTemplate200(msg.to, "「Welcome Msg」\n🛑Welcome Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set leave: ' in msg.text:
                           #if msg._from in admin:
                              spl = msg.text.replace('Set leave: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate200(msg.to, "🛑Gagal mengganti Autoleave Msg")
                              else:
                                  wait["leavemsg"] = spl
                                  sendTextTemplate200(msg.to, "「Autoleave Msg」\n🛑Autoleave Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif cmd.startswith("setwelcome: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "🛑Failed..!!")
                               else:
                                   wait["welcome"] = str(key).lower()
                                   cl.sendMessage(to, "{}".format(str(key).lower()))

                        elif cmd == "cekliff":
                            #if msg._from in admin:
                               cl.sendMessage(to, "line://app/"+ str(wait["liff"]))
                        elif cmd.startswith("setliff: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "🛑Failed..!!")
                               else:
                                   wait["liff"] = str(key).lower()
                                   cl.sendMessage(to, "{}".format(str(key).lower()))
                        elif cmd.startswith("setleave: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "🛑Failed..!!")
                               else:
                                   wait["leavemsg"] = str(key).lower()
                                   cl.sendMessage(to, "{}".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               sendZulBots3(msg.to, "🛑Succes")

                        elif cmd == "reboot":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               cl.sendMessage(msg.to, "🛑waitting 1 second")
                               time.sleep(5)
                               Setmain["restartPoint"] = msg.to
                               sendTextTemplate200(msg.to, "🛑Be reboot to pee.")
                               restartBot()
                                                          
                        #elif cmd == "runtime":
                          #if wait["selfbot"] == True:
                            ##if msg._from in admin:
                                #eltime = time.time() - mulai
                                #bot = runtime(eltime)
                                #cl.sendMessage(to, bot)
                               
                        elif cmd == "blocklist":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                blockedlist = cl.getBlockedContactIds()
                                kontak = cl.getContacts(blockedlist)
                                num=1
                                msgs="「 Blocked List 」\n"
                                for ids in kontak:
                                    msgs+="\n%i. %s" % (num, ids.displayName)
                                    num=(num+1)
                                msgs+="\n\n🛑Total Blocked : %i" % len(kontak)
                                cl.sendMessage(to, msgs)
                                
                        elif cmd.startswith("delfriend "):
                          #if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.deleteContact(ls)
                                sendZulBots3(msg.to, "🛑Success Remove " + str(contact.displayName) + "🛑to Friendlist")
                                
                        elif msg.text.lower() == "cek add":
                          #if msg._from in admin:
                          #if msg._from in Creator or msg._from in Owner:  
                            contactlist = cl.getAllContactIds()
                            kontak = cl.getContacts(contactlist)
                            num=1
                            msgs="「 Friend List 」\n"
                            for ids in kontak:
                                msgs+="\n%i. %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n\n🛑Total Friend : %i" % len(kontak)
                            cl.sendMessage(to, msgs)
                          
                        elif cmd.startswith("bye:"):
                            if wait["selfbot"] == True:
                              #if msg._from in admin:
                                  separate = cmd.split(":")
                                  number = cmd.replace(separate[0] + ":","")
                                  groups = cl.getAllChatIds()
                                  try:
                                      group = groups[int(number)-1]
                                      G = cl.getChats(group)
                                      try:
                                          cl.deleteSelfFromChat(G.id)
                                      except:
                                          cl.deleteSelfFromChat(G.id)
                                      cl.sendMessage(msg.to, "🛑Leave Group : " + G.name)
                                  except Exception as error:
                                      sendFoter(to, str(error))

                        #elif cmd == '*ginfo':
                          #if msg._from in admin or msg._from in staff:
                            #group = cl.getChats([to]).chats[0]
                            #try:ccreator = group.extra.groupExtra.creator;gcreator = cl.getContact(ccreator).displayName
                            #except:ccreator = None;gcreator = 'Not found'
                            #if not group.extra.groupExtra.inviteeMids:pendings = 0
                            #else:pendings = len(group.extra.groupExtra.inviteeMids)
                            #qr = 'Close' if group.extra.groupExtra.preventedJoinByTicket else 'Open'
                            #if group.extra.groupExtra.preventedJoinByTicket:ticket = 'Not found'
                            #else:ticket = 'https://line.me/R/ti/g/' + str(cl.reissueChatTicket(group.chatMid).ticketId)
                            #created = time.strftime('%d-%m-%Y %H:%M:%S', time.localtime(int(group.createdTime) / 1000))
                            #img ="https://obs.line-scdn.net/{}".format(cl.getChats([to]).chats[0].picturePath)
                            #cl.sendImageWithURL(msg.to, str(img))
                            #if ccreator:cl.sendMessage(msg.to, None, contentMetadata={'mid': ccreator}, contentType=13)
                            #cl.sendReplyMessage(msg.id, to,'「 Group Info 」\n\n    • Group ID : ' + group.chatMid + '\n    • Group Name : ' + group.chatName + '\n    • Pembuat : ' + gcreator + '\n    • Created Time : ' + created + '\n    • Sisa Member : ' + str(len(group.extra.groupExtra.memberMids)) + '\n    • Member Pending : ' + str(pendings) + '\n    • Link QR : ' + qr)
                        #elif cmd.startswith("ginfo "):
                          #if msg._from in admin or msg._from in staff:
                            #sep = msg.text.split(" ");num = msg.text.replace(sep[0] + " ","");gids = [a for a in cl.getAllChatMids(True, True).memberChatMids];gid = gids[int(num) - 1];group = cl.getChats([gid], True , False).chats[0]
                            #try:ccreator = group.extra.groupExtra.creator;gcreator = cl.getContact(ccreator).displayName
                            #except:ccreator = None;gcreator = 'Not found'
                            #if not group.extra.groupExtra.inviteeMids:pendings = 0
                            #else:pendings = len(group.extra.groupExtra.inviteeMids)
                            #qr = 'Close' if group.extra.groupExtra.preventedJoinByTicket else 'Open'
                            #if group.extra.groupExtra.preventedJoinByTicket:ticket = 'Not found'
                            #else:ticket = 'https://line.me/R/ti/g/' + str(cl.reissueChatTicket(group.chatMid).ticketId)
                            #created = time.strftime('%d-%m-%Y %H:%M:%S', time.localtime(int(group.createdTime) / 1000))
                            #img ="https://obs.line-scdn.net/{}".format(cl.getChats([gid]).chats[0].picturePath)
                            #cl.sendImageWithURL(msg.to, str(img))
                            #if ccreator:cl.sendMessage(msg.to, None, contentMetadata={'mid': ccreator}, contentType=13)
                            #cl.sendReplyMessage(msg.id, to,'「 Informasi Group 」\n\n•   ID : ' + group.chatMid + '\n•   Group Name : ' + group.chatName + '\n•   Creator : ' + gcreator + '\n•   Created Time : ' + created + '\n•   Group Member : ' + str(len(group.extra.groupExtra.memberMids)) + '\n•   Group Pending : ' + str(pendings) + '\n•   QR Status : ' + qr)
                        elif cmd == '*gid':
                          if msg._from in admin or msg._from in staff:
                            cl.sendMessage(msg.to, "🛑Group Id : {}".format(cl.getChats([to]).chats[0].chatMid))                        

                        elif cmd.startswith("infogrup "):
                          #if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getAllChatIds()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getChats(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "╭───「 Group Info 」───"
                                ret_ += "\n├↘ Nama Group : {}".format(G.name)
                                ret_ += "\n├↘ ID Group : {}".format(G.id)
                                ret_ += "\n├↘ Pembuat : {}".format(gCreator)
                                ret_ += "\n├↘ Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n├↘ Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n├↘ Jumlah Pending : {}".format(gPending)
                                ret_ += "\n├↘ Group Qr : {}".format(gQr)
                                ret_ += "\n├↘ Group Ticket : {}".format(gTicket)
                                ret_ += "\n├↘ Picture Url : http://dl.profile.line-cdn.net/{}".format(G.pictureStatus)
                                ret_ += "\n╰──────────────"
                                cl.sendMessage(to, str(ret_))
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except:
                                pass

                        elif cmd.startswith("gurl "):
                          #if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getAllChatIds()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getChats(group)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                try:
                                    gCreator = G.creator.mid
                                    dia = cl.getContact(gCreator)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan = '「 Sukses Open Qr 」\n• Creator :  '
                                    diaa = str(dia.displayName)
                                    pesan = ''
                                    pesan2 = pesan+"@a\n"
                                    xlen = str(len(zxc)+len(xpesan))
                                    xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':dia.mid}
                                    zx2.append(zx)
                                    zxc += pesan2
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += xpesan+zxc
                                ret_ += "• Nama : {}".format(G.name)
                                ret_ += "\n• Group Qr : {}".format(gQr)
                                ret_ += "\n• Pendingan : {}".format(gPending)
                                ret_ += "\n• Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(receiver, ret_, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                            except:
                                pass

                        elif cmd.startswith("close "):
                          #if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getAllChatIds()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getChats(group)
                                G.preventedJoinByTicket = True
                                cl.updateGroup(G)
                                try:
                                    gCreator = G.creator.mid
                                    dia = cl.getContact(gCreator)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan = '「 Sukses Close Qr 」\n• Creator :  '
                                    diaa = str(dia.displayName)
                                    pesan = ''
                                    pesan2 = pesan+"@a\n"
                                    xlen = str(len(zxc)+len(xpesan))
                                    xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':dia.mid}
                                    zx2.append(zx)
                                    zxc += pesan2
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += xpesan+zxc
                                ret_ += "• Nama : {}".format(G.name)
                                ret_ += "\n• Group Qr : {}".format(gQr)
                                ret_ += "\n• Pendingan : {}".format(gPending)
                                ret_ += "\n• Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(receiver, ret_, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                            except:
                                pass

                        elif cmd.startswith("infomem "):
                          #if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getAllChatIds()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getChats(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "├↘ "+ str(no) + ". " + mem.displayName
                                cl.sendMessage(msg.to,"├↘ Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\n「Total %i Members」" % len(G.members))
                            except: 
                                pass

                        elif cmd == "gruplist":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getAllChatIds()
                               for i in gid:
                                   G = cl.getChats([i], True , False).chats[0]
                                   print(G)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.chatName+ "\n"
                               cl.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "buka qr":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getChats(to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                   cl.sendMessage(msg.to, "🛑Open Link Groups")

                        elif cmd == "tutup qr":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getChats(to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   cl.sendMessage(msg.to, "🛑Blocked Url Groups")

                        elif cmd == "url":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                if msg.toType == 2:
                                   x = cl.getChats(to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      cl.updateGroup(x)
                                   gurl = cl.reissueGroupTicket(to)
                                   cl.sendMessage(msg.to, "🛑Nama : "+str(x.name)+ "\nUrl : http://line.me/R/ti/g/"+gurl)
                                                        
                        elif cmd.startswith("food "):
                          #if msg._from in admin:
                              query = text.replace("food ","")
                              cond = query.split("|")
                              search = str(cond[0])
                              r = requests.get("https://cryptic-ridge-9197.herokuapp.com/api/imagesearch/{}".format(str(search)))
                              data=r.text
                              data=json.loads(r.text)
                              if data != []:
                                  ret_ = []                                	
                                  for food in data:
                                      if 'http://' in food["url"]:
                                          pass
                                      else:
                                          if len(ret_) >= 10:
                                              pass
                                          else:
                                              ret_.append({
                                                  "imageUrl": "{}".format(str(food["url"])),
                                                  "action": {
                                                      "type": "uri",
                                                      "label": "Send Image",
                                                      "uri": "line://app/1655063343-oxyzbOrK?type=image&img={}".format(str(food["url"]))
                                                      }
                                                  }
                                              )
                                  k = len(ret_)//10
                                  for aa in range(k+1):
                                      data = {
                                          "type": "template",
                                          "altText": "I'm Zulkifli mokoagow",
                                          "template": {
                                              "type": "image_carousel",
                                              "columns": ret_[aa*10 : (aa+1)*10]
                                          }
                                      }
                                      sendTemplate(to, data)                                                                        
#================================================================#
                        elif cmd == "test":
                          #if msg._from in admin:
                            getUserActivity("u2ea8f5cdd95abb824b55ec060bd068d3", to)
  
                        elif cmd == "order" or cmd == "promo":
                          if wait["selfbot"] == True:
                                kontol = wait["order"]
                                sendTextTemplate200(to, str(kontol))
                        elif cmd == "liff" or cmd == "liffs":
                            #if msg._from in admin:
                                cl.sendMessage(msg.to, "https://liff.line.me/1657747580-NKGjO7DQ\n\nhttps://liff.line.me/1657747590-KEX2A7qm\n\nhttps://liff.line.me/1657747595-5r8BAk4P")
                                                    
                        elif cmd == "creator" or cmd == "developer":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                status = cl.getContact(sender)                               	
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                cover = cl.getProfileCoverURL(sender)
                                time.sleep(1)
                                data = { "type": "flex", "altText": "TEAM TERMUX", "contents":{ "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/pJvKcvX/ezgif-com-gif-maker-19.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:4", "animated": True }, { "type": "image", "url": "https://i.ibb.co.com/YyDR7TM/ezgif-com-gif-maker-22.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:4", "animated": True, "position": "absolute" }, { "type": "image", "url": "https://i.postimg.cc/J48BmhBc/1663946377912.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:4", "animated": True, "position": "absolute" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u773deee72a5f9e1c43351acd93cdbf2d" } } }
                                sendTemplate(to, data)
                                                        
                        elif cmd == "randomtiktok":
                          #if msg._from in admin:
                            contact = cl.getContact(sender)
                            time.sleep(1)
                            data = {
                                "type": "video",
                                "originalContentUrl": "https://rest.farzain.com/api/tiktok.php?apikey=fn",
                                "previewImageUrl": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                }
                            sendTemplate(to, data)
                            
                        elif cmd.startswith("uns"):                         
                          #if msg._from in admin:
                                sep = msg.text.split(" ")
                                args = msg.text.replace(sep[0] + " ","")
                                mes = 0
                                cl.unsendMessage(msg.id)
                                try:
                                   mes = int(args)
                                except:
                                    mes = 1
                                M = cl.getRecentMessagesV2(to, 1001)
                                MId = []
                                for ind,i in enumerate(M):
                                    if ind == 0:
                                        pass
                                    else:
                                        if i._from == cl.profile.mid:
                                            MId.append(i.id)
                                def unsMes(id):
                                    cl.unsendMessage(id)
                                for i in MId:
                                    thread2 = threading.Thread(target=unsMes, args=(i,))
                                    thread2.start()
                                    thread2.join()                     
                                    
                        elif cmd.startswith("dell "): #x
                          #if msg._from in admin:
                              sep = msg.text.split("dell ")
                              args = msg.text.replace(sep[0] + "dell ","")
                              mes = int(sep[1])
                              M = cl.getRecentMessagesV2(to, 1001)
                              MId = []                                            
                              for ind,i in enumerate(M):
                                  if ind == 0:
                                      pass                   
                                  else:
                                      if i._from == cl.profile.mid:
                                          MId.append(i.id)
                                          if len(MId) == mes:
                                              break                           
                              def unsMes(id):
                                  cl.unsendMessage(id)               
                              for i in MId:
                                  thread1 = threading.Thread(target=unsMes, args=(i,))
                                  #thread1.daemon = True
                                  thread1.start()
                                  thread1.join()                                                            
                              cl.unsendMessage(msg.id)              
                              
                        elif cmd.startswith("clear "): #x
                          #if msg._from in admin:
                                args = removeCmd("clear", text)
                                mes = 0
                                try:
                                   mes = int(args[1])
                                except:
                                    mes = 1
                                M = cl.getRecentMessagesV2(to, 101)
                                MId = []
                                for ind,i in enumerate(M):
                                    if ind == 0:
                                        pass
                                    else:
                                        if i._from == cl.profile.mid:
                                            MId.append(i.id)
                                            if len(MId) == mes:
                                                break
                                def unsMes(id):
                                    cl.unsendMessage(id)
                                for i in MId:
                                    thread1 = threading.Thread(target=unsMes, args=(i,))
                                    thread1.start()
                                    thread1.join()
                                cl.unsendMessage(msg_id)
                                
                        elif cmd.startswith(comd["unsend"]):
                            #if msg._from in admin:
                                sep = text.split(" ")
                                args = text.replace(sep[0] + " ", "")
                                mes = 0
                                try:
                                    mes = int(args[1])
                                except:
                                    mes = 1
                                M = cl.getRecentMessagesV2(to, 101)
                                MId = []
                                for ind, i in enumerate(M):
                                    if ind == 0:
                                        pass
                                    else:
                                        if i._from == cl.profile.mid:
                                            MId.append(i.id)
                                            if len(MId) == mes:
                                                break

                                def unsMes(id):
                                    cl.unsendMessage(id)

                                for i in MId:
                                    thread1 = threading.Thread(target=unsMes, args=(i,))
                                    thread1.start()
                                    thread1.join()
                                cl.sendMessage(msg.to, "🛑pesan di urungkan")       
          
#================================================================#
                        elif cmd == "dor" or text.lower() == "tagg" or text.lower() == "itil":
                          #if msg._from in admin:
                              group = cl.getChats([to])
                              data=[]
                              for contact in group.chats[0].extra.groupExtra.memberMids:
                                  data.append(contact)
                              k = len(data)//20
                              for aa in range(k+1):
                                  if aa == 0:dd = '╭──「 Mention Message 」─';no=aa
                                  else:dd = '├「 Mention Message 」─';no=aa*20
                                  msgas = dd
                                  for i in data[aa*20 : (aa+1)*20]:
                                      no+=1
                                      if no == len(data):msgas+='\n│{}. @!\n╰──「 TEAM TERMUX 」'.format(no)
                                      else:msgas+='\n│{}. @!'.format(no)
                                  cl.sendMentionV2(to, msgas, data[aa*20 : (aa+1)*20])
                                                                                                                          
                        elif cmd == "tag":
                          #if msg._from in admin:
                            group = cl.getChats(to)
                            nama = cl.getChatMemberMids(to)
                            nama.remove(cl.getProfile().mid)
                            cl.datamention(to,'Mention',nama)                                                                                                                                          
   
                        elif cmd == comd["tagall"]:
                          #if msg._from in admin:
                            members = []
                            if msg.toType == 1:
                                room = cl.getCompactRoom(to)
                                members = [mem.mid for mem in room.contacts]
                            elif msg.toType == 2:
                                group = cl.getChats([to], True, False)
                                members = [mem for mem in group.chats[0].extra.groupExtra.memberMids]
                            else:
                                return cl.sendMessage(msg.to, '🛑Komen di ubah')
                            if members:
                                mentionMembers2(to, members)
        
                        elif cmd.startswith("tag: "):
                          #if msg._from in admin:
                            separate = msg.text.split(":")
                            number = msg.text.replace(separate[0] + ":"," ")
                            groups = cl.getAllChatIds()
                            gid = groups[int(number)-1]                                                                                                      
                            members = []
                            if msg.toType == 1:
                                room = cl.getCompactRoom(gid)
                                members = [mem.mid for mem in room.contacts]
                            elif msg.toType == 2:
                                group = cl.getChats([gid], True, False)
                                members = [mem for mem in group.chats[0].extra.groupExtra.memberMids]
                            else:
                                return cl.sendMessage(msg.to, '🛑Failed mentionall members, use this command only on room or group chat')
                            if members:
                                mentionMembers2(gid, members)
                                cl.sendMessage(msg.to, "🛑Remote Mentions Group: " + str(group.name))      
 
                        elif msg.text.lower().startswith("tagpen "):
                          if wait["selfbot"] == True:
                            if msg._from in admin or msg._from in staff:
                               separate = msg.text.split(" ")
                               number = msg.text.replace(separate[0] + " ","")
                               groups = cl.getAllChatMids().memberChatMids
                               try:
                                  _gd = list(groups)
                                  soak = _gd[int(number)-1]
                                  G = cl.getChats([soak]).chats[0]
                                  anu = cl.getChats([soak]).chats[0].chatMid
                                  sogok = cl.getChats([soak]).chats[0].chatName
                                  data = list(G.extra.groupExtra.inviteeMids)
                                  k = len(data)//20
                                  cl.sendReplyMessage(msg.id, to, "• Done Tag Pendingan\n• Di Groups : "+sogok)
                                  for aa in range(k+1):
                                          if aa == 0:dd= "╭─「 ᴀʙsᴇɴsɪ ᴍᴇᴍʙᴇʀ 」─";no=aa
                                          else:dd = ' ';no=aa*20
                                          msgas = dd
                                          for i in data[aa*20 : (aa+1)*20]:
                                                  no += 1 
                                                  if no == len(data):msgas+='\n├•{}. @!\n╰─「 𝚂𝙾𝙰𝙺_𝙺𝙸𝙻𝙻𝙴𝚁 」─'.format(no)
                                                  else:msgas+='\n├•{}. @!'.format(no)
                                          cl.sendMention(to, str(msgas), data[aa*20 : (aa+1)*20])
                               except Exception as error:
                                      logError(error)
                               pass             
                               
                        elif text.lower().startswith("infogid "):
                          #if msg._from in admin:
                              separate = text.split(" ")
                              number = text.replace(separate[0] + " ","")
                              group = cl.getChats([number]).chats[0]
                              ret_ = "╭───「[ Member List ]」"
                              no = 0 + 1
                              for mem in group.extra.groupExtra.memberMids:
                                  ret_ += "\n│ {}. {}".format(str(no), str(cl.getContact(mem).displayName))
                                  no += 1
                              ret_ += "\n╰───「[ Total {} ]」".format(str(len(group.extra.groupExtra.memberMids)))
                              cl.sendReplyMessage(msg.id, to, str(ret_))
                              
                        elif cmd == "pendinglist":
                          #if wait["selfbot"] == True:
                            #if msg._from in admin:
                            	if msg.toType == 2:
                                    toz = cekpending(to)
                                    if toz:pendingGroup(to,toz)                               
#                            else:cl.sendMessage(msg.to, "🛑「 PENDINGAN KOSONG 」🛑")
                                
                        elif cmd == "crot":
                          #if msg._from in admin:
                            if msg.toType == 2:
                                toz = cekmember(to)
                                if toz:memberGroup(to,toz) 
             
                        elif cmd == "stick":
                          #if wait["selfbot"] == True:
                            #if msg._from in admin:
                                soak = cl.getChats([to]).chats[0]
                                ayo = list(soak.extra.groupExtra.memberMids)
                                sk = len(ayo)//147
                                cl.unsendMessage(msg.id)
                                for jos in range(sk+1):
                                    kui = "Mentions \n"
                                    dlogokjaran = []
                                    for i in ayo[jos*147 : (jos+1)*147]:
                                        cokk = "@roybot\n"
                                        moh = {"S":str(len(kui)), "E":str(len(kui)+16), "M":i}
                                        dlogokjaran.append(moh)
                                        kui += cokk
                                    if dlogokjaran != []:
                                        raimu = {
                                            'STKTXT': '[Sticker]',
                                            'STKOPT': '0',
                                            'STKVER': '1',
                                            'STKID': '52002742',
                                            'STKPKGID': '11537', #11538
                                            'MENTION': str('{"MENTIONEES":' + json.dumps(dlogokjaran) + '}')
                                        }
                                        cl.sendMessage(to,kui[:-1],raimu,7)

                        elif cmd == "gcall":
                          #if wait["selfbot"] == True:
                            #if msg._from in admin:
                                a = cl.getGroupCall(to);print(a);k = len(a.memberMids)//20                        
                                if a.memberMids is not None:
                                  #k = len(a.memberMids)//20
                                  for i in range(k+1):
                                     try:
                                         if i == 0:aa = 'INFO CALL GROUP\nName Group: {}\nDurasi Panggilan: {}'.format(cl.getChats([to]).chats[0].chatName,humanize.naturaltime(datetime.fromtimestamp(int(a.started)//1000)));no = i
                                         else:aa = 'INFO CALL GROUP\nName Group: {}\nDurasi Panggilan: {}:'.format(cl.getChats([to]).chats[0].chatName,humanize.naturaltime(datetime.fromtimestamp(int(a.starter)//1000)));no=i*20
                                         ret = aa
                                         for b in a.memberMids[i*20 : (i+1)*20]:
                                             no += 1;c = a.hostMids                        
                                             if a.mediaType == 1:typenya = 'Voice Call Group'
                                             if a.mediaType == 2:typenya = 'Video Call Group'
                                             if no == len(a.memberMids):ret+='\n• {}. @!\n › Type: {}\n• Host: @!'.format(no,typenya)
                                             else:ret+='\n• {}. @!'.format(no)
                                         cl.sendMentionn(to, ret,"",a.memberMids[i*20 : (i+1)*20]+[c])
                                     except:
                                         if a.mediaType == 3:typenya = 'Group Live'
                                         if i == 0:aa = 'INFO LIVE\nName Grup: {}\nDurasi Live : {}\n• Talent:'.format(cl.getChats([to]).chats[0].chatName,humanize.naturaltime(datetime.fromtimestamp(int(a.started)//1000)));no = i
                                         else:aa = 'INFO LIVE GROUP \nName Group: {}\nDurasi Live: {}\n• Talent:'.format(cl.getChats([to]).chats[0].chatName,humanize.naturaltime(datetime.fromtimestamp(int(a.starter)//1000)));no=i*20
                                         ret = aa
                                         for b in a.memberMids[i*20 : (i+1)*20]:
                                             no += 1;c = a.hostMids                        
                                             if no == len(a.memberMids):ret+='\n• {}. @!\n › Type: {}\n• Host: @!'.format(no,typenya)
                                             else:ret+='\n• {}. @!'.format(no)
                                         cl.sendMentionn(to, ret,"",a.memberMids[i*20 : (i+1)*20]+[c])                                         
                                else:cl.sendReplyMessage(msg.id, to,'🛑Tidak Ada Aktifitas Group')                     


                        elif cmd == "tagall sticker":
                          #if msg._from in admin:
                            members = []
                            if msg.toType == 1:
                                room = cl.getCompactRoom(to)
                                members = [mem.mid for mem in room.contacts]
                            elif msg.toType == 2:
                                group = cl.getChats(to)
                                members = [mem.mid for mem in group.members]
                            else:
                                return sendZulBots3(msg.to, '🛑Failed mentionall members, use this command only on room or group chat')
                            if members:
                                cl.sendMessage(to,"11538" ,"51626512", members)
                        
                        elif "https://www.smule.com/p/" in msg.text.lower() or "https://link.smule.com/" in msg.text.lower() or "https://www.smule.com/c/" in msg.text.lower() or "https://www.smule.com/" in msg.text.lower():
                            if wait["rsmule"] == True:
                                time.sleep(0.5)
                                rr1 = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                                rr2 = re.findall(rr1, text)
                                roy = []
                                for skbot in rr2:
                                    if skbot not in roy:
                                        roy.append(skbot)
                                        headers = {
                                            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/51.0.2704.106",
                                            "Apikey": "Bstm0109"
                                        }
                                for teamsk in roy:
                                    rr3 = teamsk
                                    data = json.loads(requests.get("https://jvrestapi.site/smuledl="+rr3,headers=headers).text)
                                    sk1=data["result"]
                                    skbot = "{}".format(data["result"]["thumbnail"])
                                    skbot2 = "{}".format(data["result"]["mp4Url"])
                                    skbot1 = "{}".format(data["result"]["mp3Url"])
                                    pp = "{}".format(data["result"]["thumbnail"])
                                    roysoak = "╭──[  𝙎𝙢𝙪𝙡𝙚 𝙙𝙤𝙬𝙣𝙡𝙤𝙖𝙙..♪♪"
                                    roysoak += "\n├• S𝙢𝙪𝙡𝙚-𝙞𝙙 : "+str(sk1["username"])
                                    roysoak += "\n├• J𝙪𝙙𝙪𝙇 : "+str(sk1["title"])
                                    roysoak += "\n├• T𝘆𝗽𝗘 : "+str(sk1["type"])
                                    roysoak += "\n├• 𝘿𝙞𝙗𝙪𝙖𝙩 : "+str(sk1["created"])
                                    roysoak += "\n├• 𝘿𝙞𝙥𝙪𝙩𝙖𝙧 : "+str(sk1["listens"])
                                    roysoak += "\n├• 𝘿𝙚𝙨𝙠𝙧𝙞𝙥𝙨𝙞 : "+str(sk1["caption"])                                                                   
                                    roysoak += "\n╰──[ ˚TEAM TERMUX♪]"                                    
                                    soak = {     
                                        "type": "flex",
                                        "altText": "TEAM TERMUX",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co.com/kcxnLKc/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:2",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/Z6fcwzM/1628238613409.png",
                "size": "full",
                "aspectRatio": "4:2",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co.com/JBGDynS/ezgif-com-gif-maker-3.png",
                        "size": "xs",
                        "aspectRatio": "8:2",
                        "aspectMode": "cover",
                        "offsetStart": "-44px"
                      }
                    ],
                    "position": "absolute",
                    "width": "158px",
                    "height": "20px",
                    "offsetTop": "64px",
                    "offsetStart": "0px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co.com/JBGDynS/ezgif-com-gif-maker-3.png",
                        "size": "xs",
                        "aspectRatio": "8:2",
                        "aspectMode": "cover",
                        "offsetStart": "25px"
                      }
                    ],
                    "position": "absolute",
                    "width": "158px",
                    "height": "20px",
                    "offsetTop": "64px",
                    "offsetStart": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [],
                    "position": "absolute",
                    "width": "158px",
                    "height": "90px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "𝙎𝙢𝙪𝙡𝙚-𝙞𝙙 : "+str(sk1["username"]),
                        "size": "xxs",
                        "color": "#ffffff",
                        "weight": "bold",
                        "offsetStart": "2px"
                      },
                      {
                        "type": "text",
                        "text": "𝙅𝙪𝙙𝙪𝙇 : "+str(sk1["title"]),
                        "size": "xxs",
                        "color": "#ffffff",
                        "weight": "bold",
                        "offsetStart": "2px"
                      },
                      {
                        "type": "text",
                        "text": "𝗧𝘆𝗽e : "+str(sk1["type"]),
                        "size": "xxs",
                        "weight": "bold",
                        "offsetStart": "2px",
                        "color": "#ffffff", 
                        "color": "#ffffff"
                      },
                      {
                        "type": "text",
                        "text": "creativ desaint roykeane2023 ",
                        "size": "xxs",
                        "weight": "bold",
                        "style": "italic",
                        "offsetTop": "24px",
                        "offsetStart": "20px"
                      }
                    ],
                    "position": "absolute",
                    "width": "158px",
                    "height": "80px",
                    "offsetTop": "0px",
                    "offsetStart": "0px"
                  }
                ],
                "position": "absolute",
                "width": "158px",
                "height": "85px",
                "backgroundColor": "#000000",
                "offsetTop": "75px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": pp,
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "30px",
                "height": "30px",
                "borderWidth": "1px",
                "borderColor": "#00ff00",
                "offsetTop": "1px",
                "offsetStart": "2px",
                "cornerRadius": "5px"
              }
            ],
            "position": "absolute",
            "width": "158px",
            "height": "158px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "10px",
            "offsetTop": "1px",
            "offsetStart": "1px"
          }
        ],
        "paddingAll": "0px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
                                    sendTemplate(to,soak)                                                                   
                                    time.sleep(0.5)
                                    if "video" in data["result"]["type"]:
                                        sendFlexVid2025(to, skbot2, pp)
                                        sendFlexAudio(to,data["result"]["mp3Url"])
                                    else:
                                        sendFlexAudio(to,data["result"]["mp3Url"])
                        
                        elif "https://www.tiktok.com/" in msg.text.lower() or 'https://vt.tiktok.com/' in msg.text.lower():
                            if wait["tiktok"] == True:
                                regex = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                                links = re.findall(regex, text)
                                n_links = []
                                for l in links:
                                    if l not in n_links:
                                        n_links.append(l)
                                for Ticket_id in n_links:
                                    link = Ticket_id
                                    url = f"https://jvrestapi.site/tiktokdl={link}"
                                    apikey = {
                                        "Apikey": "Bstm0109",
                                        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/51.0.2704.106"
                                    }
                                    response = requests.get(url, headers=apikey)
                                    data = response.json()
                                    pp = "{}".format(data["result"]["thumbnail"])
                                    video = "{}".format(data["result"]["vid_nowatermark"])                                    
                                    result = "╭──[  𝗥𝗲𝘀𝗽𝗼𝗻 𝗟𝗶𝗻𝗸 𝗧𝗶𝗸𝘁𝗼𝗸 ♪"
                                    result += "\n├• User-ID  : {}".format(data["result"]["username"])
                                    result += "\n├• Music  : {}".format(data["result"]["music"])
                                    result += "\n├• Play : {}".format(data["result"]["play_count"])
                                    result += "\n├• Share : {}".format(data["result"]["share_count"])
                                    result += "\n├• Comment : {}".format(data["result"]["comment_count"])                                   
                                    result += "\n╰──[ TEAM TERMUX ]"
                                    soak = {                                                                        
                                       "type": "flex",
                                       "altText": "TEAM TERMUX", 
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/HBRGznW/ezgif-com-gif-to-apng.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "TIK TOK ",
                    "size": "xxs",
                    "color": "#ff0000",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "35px"
                  }
                ],
                "position": "absolute",
                "width": "116px",
                "height": "20px",
                "borderWidth": "1px",
                "borderColor": "#ffff00"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/HPjSHBf/ezgif-com-gif-to-apng-1.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "animated": True,
                  }
                ],
                "position": "absolute",
                "width": "5px",
                "height": "5px",
                "cornerRadius": "100px",
                "offsetTop": "4px",
                "offsetEnd": "4px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": pp,
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "116px",
                "height": "116px",
                "offsetTop": "20px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "♻️User-ID : {}".format(data["result"]["username"]),
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  },
                  {
                    "type": "text",
                    "text": "♻️Play : {}".format(data["result"]["play_count"]),
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  },
                  {
                    "type": "text",
                    "text": "♻️Share : {}".format(data["result"]["share_count"]), 
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  },
                  {
                    "type": "text",
                    "text": "♻️Music : {}".format(data["result"]["music"]),
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "116px",
                "height": "60px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffff00",
                "offsetTop": "134px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/0th6341/ezgif-com-gif-to-apng-3.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "animated": True,
                  }
                ],
                "position": "absolute",
                "width": "10px",
                "height": "10px",
                "borderWidth": "1px",
                "borderColor": "#ffff00",
                "offsetTop": "5px",
                "offsetStart": "20px"
              }
            ],
            "position": "absolute",
            "width": "116px",
            "height": "176px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#ffff00",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
                                    time.sleep(0.5)
                                    sendTemplate(to, soak)
                                    #cl.sendReplyMessage(msg.id, to,(result))
                                    sendFlexVid2024(to, video, pp)
                                    time.sleep(0.5)                
                        elif "youtu.be" in text.lower() or "https://youtube.com/shorts" in text.lower() or "https://youtu.be" in msg.text.lower():
                            if wait["ytube"] == True:
                                try:
                                    url = re.search("(?P<url>https?://[^\s]+)", text).group("url")
                                    host = "https://jvrestapi.site/youtubedl=" + url
                                    headers  =  {
                                        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/51.0.2704.106",
                                        "Apikey": "Bstm0109"
                                    }
                                    data   =  requests.get(host, headers=headers).json()                          
                                    pict = "https://i.ibb.co.com/cbH5wDy/pngwing-com-2.png"     
                                    page = str(data["result"]["pageUrl"])
                                    thumb = "https://i.ytimg.com/vi/{}/hq720.jpg".format(page.split("/youtu.be/")[1])
                                    desk = str(data["result"]["title"])
                                    type = str(data["result"]["duration"])
                                    ids = str(data["result"]["author"])
                                    video = data["result"]["videoUrl"]  
                                    audio = data["result"]["audioUrl"]                
                                    soak =  {                                                                                                               
                                      "type": "flex",
                                       "altText": "TEAM TERMUX",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://scdn.line-apps.com/n/channel_devcenter/img/flexsnapshot/clip/clip1.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/TcM9Cy4/ezgif-com-gif-maker.png",
                "size": "full",
                "aspectMode": "cover",
                "animated": True,
                "aspectRatio": "6:1",
                "offsetBottom": "2px"
              }
            ],
            "position": "absolute",
            "height": "15px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#000000",
            "width": "120px",
            "offsetTop": "14px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/4W6bPg9/ezgif-com-gif-to-apng.png",
                "size": "full",
                "aspectRatio": "6:1",
                "aspectMode": "cover",
                "animated": True,
              }
            ],
            "position": "absolute",
            "height": "15px",
            "width": "120px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co.com/HPjSHBf/ezgif-com-gif-to-apng-1.png",
                "size": "full",
                "aspectRatio": "2:2",
                "aspectMode": "cover",
                "animated": True,
              }
            ],
            "position": "absolute",
            "width": "3px",
            "height": "3px",
            "cornerRadius": "100px",
            "offsetStart": "4px",
            "offsetTop": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ ғᴏʀ ᴠɪᴅᴇᴏ ʏᴛᴜʙᴇ",
                "size": "6px",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "10px",
            "offsetTop": "5px",
            "offsetStart": "18px"
          }
        ],
        "paddingAll": "0px",
        "height": "30px",
        "cornerRadius": "10px",
        "borderWidth": "1px",
        "borderColor": "#000000"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~zul.1.02",
      }
    }
  ]
}
}
                                    time.sleep(0.5)
                                    sendTemplate(to, soak)
                                    #cl.sendReplyMessage(msg.id, to,(wowo))
                                    sendFlexVid2026(to, video, thumb)
                                    sendFlexAudio(to, audio) 
                                    time.sleep(0.5)
                                except Exception as error:
                                    cl.sendMessage(to, str(error))
                        
                        elif cmd.startswith("ytvid "):
                          #if msg._from in admin:
                            try:
                                x = text.split(" ")
                                y = text.replace(x[0] + " ","")
                                url = f"https://jvrestapi.site/youtubeplay={y}"                               
                                apikey  =  {                                   
                                    "Apikey": "Bstm0109", 
                                    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/51.0.2704.106"
                                }
                                response = requests.get(url, headers=apikey)                                
                                data = response.json()
                                #video = data["result"]["videoUrl"]                                   
                                video = "{}".format(str(data["result"]["videoUrl"])) 
                                audio = "{}".format(str(data["result"]["audioUrl"])) 
                                #thumb = "{}".format(str(data["result"]["thumbnail"])) 
                                #thumb = data["result"]["thumbnail"]                
                                #print(data)                                       
                                ret_ = "╭──[  Search YouTube ]───"
                                ret_ += "\n├Title : {}".format(str(data["result"]["title"]))
                                ret_ += "\n├Duration : {}".format(str(data["result"]["duration"]))
                                ret_ += "\n├Author : {}".format(str(data["result"]["author"]))
                                ret_ += "\n╰──[ 𝕊𝕖𝕝𝕒𝕞𝕒𝕥 𝕄𝕖𝕟𝕕𝕖𝕟𝕘𝕒𝕣𝕜𝕒𝕟 ]──"
                                sendTextTemplate200(to, str(ret_))
                                sendFlexVideo(to, video)
                                sendFlexAudio(to, audio) 
                                time.sleep(0.5)
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))
                                
                        elif cmd.startswith("joox "):
                          #if msg._from in admin:
                            try:
                                x = text.split(" ")
                                y = text.replace(x[0] + " ","")
                                url = f"https://jvrestapi.site/spotifyplaylist={y}"
                                apikey = {
                                    "Apikey": "Bstm0109",
                                    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/51.0.2704.106"
                                }
                                response = requests.get(url, headers=apikey)
                                data = response.json()
                                #print(data)
                                ret_ = " Joox music \n"
                                ret_ += "\nArtis : {}".format(str(data["results"][0]["Artist"]))
                                ret_ += "\nJudul: {}".format(str(data["results"][0]["Track Name"]))
                                cl.sendMessage(to, str(ret_))
                                sendFlexAudio(to, str(data["results"][0]["Audio URL"]))
                            except Exception as e:
                                print (error)
#===========BOT UPDATE============#
                        elif cmd == "updategrup":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                sendZulBots3(msg.to,"🛑Send a Picture ♪")
                                
                        elif cmd == "updatecover":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                settings["changeCover"][clMID] = True
                                sendZulBots3(msg.to,"🛑Send a Picture ♪")

                        elif cmd == "updatefoto":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                wait["changeFoto"][clMID] = True
                                sendZulBots3(msg.to,"🛑Send a Picture ♪")
                                                             
                        elif cmd.startswith("myname: "):
                          #if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to,"🛑Nama diganti jadi " + string + "")                        

                        elif cmd.startswith("cek "):
                          #if msg._from in admin:
                            separate = msg.text.split(" ")
                            mid = msg.text.replace(separate[0] + " ","")
                            if mid is not None:
                                listMid = mid.split("*")
                                if len(listMid) > 1:
                                    for a in listMid:
                                        cl.sendContact(to,a)
                                else:
                                    cl.sendContact(to,mid)

                        elif cmd.startswith("addtext "):
                            #if msg._from in admin:
                                sep = text.split(" ")
                                apl = text.replace(sep[0] + " ","")
                                sam = apl.split("/")
                                chat1 = sam[0]
                                chat2 = sam[1]
                                apk = ""+chat1
                                tes["Message"][apk] = chat2
                                tes["msg"] = chat1
                                anu = tes["msg"]+'.'
                                cl.sendReplyMessage(msg.id,to,"🛑Command %s created."%chat1)
                                tes["msg"] = {}

                        elif cmd == "list text":
                            #if msg._from in admin:
                                if tes["Message"] == {}:
                                    cl.sendMessage(msg.to,"🛑empty text")
                                else:
                                    mc = ""
                                    jml = 1
                                    for listword in tes["Message"]:
                                        mc += "\n"+str(jml)+". "+listword+""
                                        jml += 1
                                    cl.sendResplyMessage(msg.id,to, "List text :\n"+str(mc))

                        elif cmd.startswith("deltext "):
                            	#if msg._from in admin:
                                    sep = text.split(" ")
                                    xres = text.replace(sep[0] + " ","")
                                    tetx = text.replace(sep[0] + " ","")
                                    if xres in tes["Message"]:
                                        del tes["Message"][xres]                                        
                                        cl.sendReplyMessage(msg.id,to,"Command %s has been removed."%tetx)
                                    else:
                                        cl.sendReplyMessage(msg.id,to,"Command %s does not exist."%tetx)
                            
                        elif cmd == "screen -ls":
                          #if msg._from in admin:
                              process = os.popen('screen -list')
                              a = process.read()
                              cl.sendMessage(to, "{}".format(a))
                              process.close()

                        elif cmd == "liffku":
                          #if msg._from in admin:                              
                            cl.sendMessage(msg.to, "🛑Click Link Lift & izinkan •\n\n1.   ➢ line://app/1655063343-oxyzbOrK\n\n2.   ➢ line://app/1655063343-oxyzbOrK")                             
                               
                        elif cmd == "myname":
                          #if msg._from in admin:
                            h = cl.getContact(sender)
                            cl.sendReplyMessage(msg.id,to,"「 Name 」\n"+str(h.displayName))
                            
                        elif cmd == "mybio":
                          #if msg._from in admin:
                            h = cl.getContact(sender)
                            cl.sendReplyMessage(msg.id,to,"「 Status 」\n"+str(h.statusMessage))
                            
                        elif cmd == "mypict":
                          #if msg._from in admin:
                            h = cl.getContact(sender)
                            image = "http://dl.profile.line-cdn.net/" + h.pictureStatus
                            cl.sendReplyMessage(msg.id,to, image)     

                        elif cmd == "myvideo":
                          #if msg._from in admin:
                            h = cl.getContact(sender)
                            if h.videoProfile == None:
                            	return cl.sendMessage(to, "「 Video 」\n🛑None")
                            cl.sendVideo(msg.to,"http://dl.profile.line-cdn.net/" + h.pictureStatus + "/vp")       
#===========BOT UPDATE============#                                                     
                        elif cmd == "listbot":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n│'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n│"
                                cl.sendMessage(msg.to,"╭─「 User botlist」\n│\n│"+ma+"\n╰──「 Total「%s」User Botlist 」" %(str(len(Bots))))

                        elif cmd == "listadmin":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n│'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n│"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n│'
                                    mb += str(b) + ". " +cl.getContact(m_id).displayName + "\n│"
                                for m_id in staff:
                                    c = c + 1
                                    end = '\n│'
                                    mc += str(c) + ". " +cl.getContact(m_id).displayName + "\n│"
                                cl.sendMessage(msg.to,"╭─「 List Admin Selfbot 」\n│\n│Owner:\n│"+ma+"\n│Admin:\n│"+mb+"\n│Staff:\n│"+mc+"\n╰──「Total「%s」Team 」" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == "listprotect":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                me = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                e = 0
                                gid = protectqr
                                for group in gid:
                                    a = a + 1
                                    end = '\n│'
                                    ma += str(a) + ". " +cl.getChats(group).name + "\n│"
                                gid = protectkick
                                for group in gid:
                                    b = b + 1
                                    end = '\n│'
                                    mb += str(b) + ". " +cl.getChats(group).name + "\n│"
                                gid = protectjoin
                                for group in gid:
                                    d = d + 1
                                    end = '\n│'
                                    md += str(d) + ". " +cl.getChats(group).name + "\n│"
                                gid = protectcancel
                                for group in gid:
                                    c = c + 1
                                    end = '\n│'
                                    mc += str(c) + ". " +cl.getChats(group).name + "\n│"
                                gid = protectinvite
                                for group in gid:
                                    e = e + 1
                                    end = '\n│'
                                    me += str(e) + ". " +cl.getChats(group).name + "\n"
                                cl.sendMessage(msg.to,"╭─「 Setting Protection List 」\n│\n│ PROTECT URL :\n│"+ma+"\n│ PROTECT KICK :\n│"+mb+"\n│ PROTECT JOIN :\n│"+md+"\n│ PROTECT CANCEL:\n│"+mc+"\n│ PROTECT INVITE:\n│"+me+"\n╰──「 Total「%s」Protect 」" %(str(len(protectqr)+len(protectkick)+len(protectjoin)+len(protectcancel)+len(protectinvite))))


                        elif cmd == comd["bye"]:
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                G = cl.getChats(to)
                                sendZulBots3(msg.to, "🛑Selamat Tinggall..")
                                cl.deleteSelfFromChat(to)

                        elif cmd == "respontime":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                get_profile_time_start = time.time()
                                get_profile = cl.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = cl.getAllChatIds()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = cl.getContact(mid)
                                get_contact_time = time.time() - get_contact_time_start
                                sendZulBots3(msg.to, "「 Respontime 」\n\n - Get Profile\n   %.10f\n - Get Contact\n   %.10f\n - Get Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))

                        elif cmd == comd["speed"]:
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                start = time.time()
                                elapsed_time = time.time() - start
                                sendZulBots3(msg.to,"...{}🛑detik".format(str(elapsed_time)))
                                  
                             
                        elif cmd == comd["sider2On"]:
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendTextTemplate911(msg.to, "🛑sɪᴅᴇʀ ᴅɪʜɪᴅᴜᴘᴋᴀɴ")
                                  del cctv['point2'][msg.to]
                                  del cctv['sidermem2'][msg.to]
                                  del cctv['cyduk2'][msg.to]
                              except:
                                  pass
                              cctv['point2'][msg.to] = msg.id
                              cctv['sidermem2'][msg.to] = ""
                              cctv['cyduk2'][msg.to]=True
                              cctv['cyduk'][msg.to]=False
                              cctv['cyduk1'][msg.to]=False

                        elif cmd == comd["sider2Off"]:
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              if msg.to in cctv['point2']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk2'][msg.to]=False
                                  sendTextTemplate911(msg.to, "🛑sɪᴅᴇʀ ᴅɪᴍᴀᴛɪᴋᴀɴ")
                              else:
                                  sendTextTemplate911(msg.to, "🛑sɪᴅᴇʀ ᴅɪᴍᴀᴛɪᴋᴀɴ")(msg.to, "🛑sɪᴅᴇʀ ᴅɪ ᴏғғ")                   
                                                                                          
                        elif cmd == comd["sider1On"]:
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendTextTemplate5(msg.to, "🛑sɪᴅᴇʀ ᴅɪʜɪᴅᴜᴘᴋᴀɴ")
                                  del cctv['point1'][msg.to]
                                  del cctv['sidermem1'][msg.to]
                                  del cctv['cyduk1'][msg.to]
                              except:
                                  pass
                              cctv['point1'][msg.to] = msg.id
                              cctv['sidermem1'][msg.to] = ""
                              cctv['cyduk'][msg.to]=False
                              cctv['cyduk1'][msg.to]=True
                              cctv['cyduk2'][msg.to]=False

                        elif cmd == comd["sider1Off"]:
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              if msg.to in cctv['point1']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk1'][msg.to]=False
                                  sendTextTemplate200(msg.to, "🛑ᴄᴄᴛv ʏᴀɴɢ ᴛᴇʀᴛᴀɴɢᴋᴀᴘ:\n"+cctv['sidermem1'][msg.to])
                              else:
                                  sendTextTemplate200(msg.to, "🛑sɪᴅᴇʀ ᴅɪᴍᴀᴛɪᴋᴀɴ")(msg.to, "🛑sɪᴅᴇʀ ᴅɪ ᴏғғ")                   
                                                               
                        elif cmd == comd["siderOn"]:
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendTextTemplate911(msg.to, "🛑sɪᴅᴇʀ ᴅɪʜɪᴅᴜᴘᴋᴀɴ")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True
                              cctv['cyduk1'][msg.to]=False
                              cctv['cyduk2'][msg.to]=False

                        elif cmd == comd["siderOff"]:
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  sendTextTemplate911(msg.to, "🛑sɪᴅᴇʀ ᴅɪᴍᴀᴛɪᴋᴀɴ")
                              else:
                                  sendTextTemplate911(msg.to, "🛑sɪᴅᴇʀ ᴅɪ ᴏғғ")
                             
                        elif cmd.startswith("find "):
                          #if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                a = cl.getAllChatIds();i = cl.getChats(a)
                                c = []
                                for h in i:
                                    g = [c.append(h.name[0:20]+',.s/'+str(len(h.members))) for d in h.members if key1 in d.mid]
                                h = "╭「 Find Contact 」─"
                                no = 0
                                for group in c:
                                    no += 1
                                    h+= "\n│{}. {} | {}".format(no, group.split(',.s/')[0], group.split(',.s/')[1])
                                cl.sendMessage(to,h+"\n╰─「 {} Groups I Found it 」".format(len(c)))
                                                              
                        elif cmd.startswith("tag "):
                          #if msg._from in admin:
                            text = removeCmd("tag", text)
                            sep = text.split(" ")
                            text = text.replace(sep[0] + " ", text)
                            cond = text.split(" ")
                            jml = int(cond[0])
                            for x in range(jml):
                                name = cl.getContact(to)
                                cl.sendMessage(to, name.mid)
                                
                        elif cmd.startswith("spam "):
                          #if msg._from in admin:
                            dzin = removeCmd("spam", text)
                            line = dzin.split("|")
                            count = int(line[1])
                            text1 = removeCmd("spam"+str(line[0])+"|"+str(count)+"|", text)
                            text2 = count * (text1+"\n")
                            if line[0] == "on":
                                if count <= 1000:
                                    for a in range(count):
                                        cl.sendMessage(to, str(text1))
                                else:
                                    cl.sendMessage(msg.to, "🛑Max 1000.")
                            if line[0] == "off":
                                if count <= 1000:
                                    cl.sendMessage(to, str(text2))
                                else:
                                    cl.sendMessage(msg.to, "🛑Max 1000.")
                            
                        elif cmd.startswith('github '):
                          #if msg._from in admin:
                           args = text.split(" ")
                           search = text.replace(args[0] + " ","")
                           kontol = requests.get("http://dolphinapi.herokuapp.com/api/github?name={}".format(search))
                           data = kontol.text
                           data = json.loads(data)
                           kontol = "GITHUB SEARCH"
                           for b in data["result"]["repository"]:
                               kontol += "\n•{} \n{}".format(str(b["title"]), str(b["url"]))
                           kontol += "GITHUB SEARCH"
                           cl.sendReplyMessage(msg.id,to, str(kontol))

                        elif cmd == "cctv code":
                          #if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data = api.cctv_code()
                           kontol = "RESULT CCTV"
                           for b in data["result"]["active"]:
                               kontol += "\n• {} {}".format(b,data["result"]["active"][b])
                           kontol += "{}\nExample : Cctv (number)"
                           cl.sendMessage(to, str(kontol))
                        elif cmd.startswith('cctv '):
                          #if msg._from in admin:
                              try:
                                  args = text.split(" ")
                                  userId = text.replace(args[0] + " ","")
                                  api = imjustgood(wait["apikey"])
                                  data = api.cctvSearch(userId)
                                  kontol = "DETAIL CCTV INFO"
                                  kontol += "\nArea : {}".format(data["result"]["area"])
                                  kontol += "\nWilayah : {}".format(data["result"]["wilayah"])
                                  cl.sendMessage(to, str(kontol))
                                  time.sleep(1)
                                  sendFlexVid2025(to, "{}".format(data["result"]["video"]))
                              except Exception as error:
                                  cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith('lyrik '):
                          #if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.lyric(userId)
                           vian = "Title : {}".format(data["result"]["title"])
                           vian += "\nArtist : {}".format(data["result"]["artist"])
                           vian += "\n{}".format(data["result"]["lyric"])
                           cl.sendReplyMessage(msg.id,to, str(vian))         

                        elif cmd == "hapus add":
                          #if msg._from in admin:
                            n = len(cl.getAllContactIds())
                            try:
                                cl.clearContacts()
                            except: 
                                pass
                            t = len(cl.getAllContactIds())
                            cl.sendMessage(msg.to,"🛑Type: Friendlist\n • Detail: Clear Contact\n • Before: %s Friendlist\n • After: %s Friendlist\n • Total removed: %s Friendlist\n • Status: Succes.."%(n,t,(n-t)))
#===========Hiburan============#
                        elif cmd.startswith("eng:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('en', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("indo:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('id', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("jp:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('ja', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("india:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('hi', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("sunda:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('su', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("china:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('zh-cn', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("arab:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('ar', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)

                        elif cmd.startswith("rusia:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('ru', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("thai:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('th', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("spanyol:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('es', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("franchis:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('fr', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("korea:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('ko', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("malay:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('ms', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("turki:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('tr', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("jawa:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('jw', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("itali:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('it', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("belanda:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('nl', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("filipin:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('tl', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("german:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('de', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                        elif cmd.startswith("vietnam:"):
                          #if msg._from in admin:
                            try:
                                proses = text.split(" ")
                                query = text.replace(proses[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                res = api.translate('vi', query)
                                vian = "{}".format(res["result"]["translate"])
                                cl.sendReplyMessage(msg.id,to, str(vian))
                            except Exception as error:
                                print(error)
                                
                        elif cmd.startswith("joox:"):
                           #if msg._from in admin:
                                set = text.split(" ")
                                userId = text.replace(set[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                data = api.joox(userId)
                                title = "{}".format(data["result"]["title"])
                                durasi = "{}".format(data["result"]["duration"])
                                artis = "{}".format(data["result"]["singer"])
                                size = "{}".format(data["result"]["size"])
                                img = "{}".format(data["result"]["thumbnail"])
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)                                
                                KONTOL = { "type": "flex", "altText": "Zul_Bost", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/pJvKcvX/ezgif-com-gif-maker-19.png", "size": "full", "aspectMode": "cover", "aspectRatio": "2:1", "animated": True }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(img), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "40px", "height": "40px", "offsetTop": "12px", "offsetEnd": "13.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/GdyLZ5d/ezgif-com-gif-maker-69.png", "size": "100px", "aspectRatio": "2:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "100px", "height": "40px", "offsetStart": "8px" }, { "type": "image", "url": "https://i.ibb.co/C0yjDzt/ezgif-com-gif-maker-21.png", "size": "full", "aspectMode": "cover", "aspectRatio": "2:1", "animated": True, "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(artis), "size": "7px", "color": "#00ffff", "align": "center" } ], "position": "absolute", "width": "94px", "height": "11px", "offsetTop": "13px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(durasi), "size": "7px", "color": "#00ffff", "align": "center" } ], "position": "absolute", "width": "94px", "height": "11px", "offsetTop": "26.5px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(title), "size": "7px", "color": "#00ffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "131.5px", "height": "11px", "offsetBottom": "15.5px", "offsetEnd": "13.5px" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u914dd921845a59e01005b674177a1552" } } }
                                sendTemplate(to, KONTOL)  
                                sendFlexAudio(to, "{}".format(data["result"]["mp3Url"]))                        

                        elif cmd.startswith('ytmp3 '):
                          #if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api  = imjustgood(wait["apikey"])
                           data = api.youtube(userId)
                           tz = pytz.timezone("Asia/Jakarta")
                           timeNow = datetime.now(tz=tz)
                           autor = "{}".format(data["result"]["author"])
                           audio = "{}".format(data["result"]["audioUrl"])
                           durasi = "Durasi : {}".format(data["result"]["duration"])
                           img = "{}".format(data["result"]["thumbnail"])
                           title = "{}".format(data["result"]["title"])
                           wath = "{}".format(data["result"]["watched"])
                           KONTOL = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/pJvKcvX/ezgif-com-gif-maker-19.png", "size": "full", "aspectMode": "cover", "aspectRatio": "2:1", "animated": True }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(img), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "40px", "height": "40px", "offsetTop": "12px", "offsetEnd": "13.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/GdyLZ5d/ezgif-com-gif-maker-69.png", "size": "100px", "aspectRatio": "2:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "100px", "height": "40px", "offsetStart": "8px" }, { "type": "image", "url": "https://i.ibb.co/C0yjDzt/ezgif-com-gif-maker-21.png", "size": "full", "aspectMode": "cover", "aspectRatio": "2:1", "animated": True, "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(autor), "size": "7px", "color": "#00ffff", "align": "center" } ], "position": "absolute", "width": "94px", "height": "11px", "offsetTop": "13px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(durasi), "size": "7px", "color": "#00ffff", "align": "center" } ], "position": "absolute", "width": "94px", "height": "11px", "offsetTop": "26.5px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(title), "size": "7px", "color": "#00ffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "131.5px", "height": "11px", "offsetBottom": "15.5px", "offsetEnd": "13.5px" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u914dd921845a59e01005b674177a1552" } } }
                           sendTemplate(to, KONTOL)         
                           sendFlexAudio(to, "{}".format(data["result"]["audioUrl"]))

                        elif cmd.startswith('porn '):
                          #if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api  = imjustgood(wait["apikey"])
                           data = api.porn(userId)
                           tz = pytz.timezone("Asia/Jakarta")
                           timeNow = datetime.now(tz=tz)
                           durasi = "Durasi : {}".format(data["result"]["duration"])
                           quality = "Quality : {}".format(data["result"]["quality"])
                           img = "{}".format(data["result"]["thumbnail"])
                           title = "{}".format(data["result"]["title"])
                           wath = "{}".format(data["result"]["watched"])
                           time.sleep(1)
                           KONTOL = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/pJvKcvX/ezgif-com-gif-maker-19.png", "size": "full", "aspectMode": "cover", "aspectRatio": "2:1", "animated": True }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(img), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "40px", "height": "40px", "offsetTop": "12px", "offsetEnd": "13.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/GdyLZ5d/ezgif-com-gif-maker-69.png", "size": "100px", "aspectRatio": "2:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "100px", "height": "40px", "offsetStart": "8px" }, { "type": "image", "url": "https://i.ibb.co.com/C0yjDzt/ezgif-com-gif-maker-21.png", "size": "full", "aspectMode": "cover", "aspectRatio": "2:1", "animated": True, "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(quality), "size": "7px", "color": "#00ffff", "align": "center" } ], "position": "absolute", "width": "94px", "height": "11px", "offsetTop": "13px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(durasi), "size": "7px", "color": "#00ffff", "align": "center" } ], "position": "absolute", "width": "94px", "height": "11px", "offsetTop": "26.5px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(title), "size": "7px", "color": "#00ffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "131.5px", "height": "11px", "offsetBottom": "15.5px", "offsetEnd": "13.5px" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=ua6105e31b80ad992f5dcc02003a9ecd6" } } }
                           sendTemaplate(to, KONTOL)         
                           cl.sendMessage(to, "{}".format(data["result"]["videoUrl"]))
                           
                        elif cmd.startswith('ytmp4 '):
                          #if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api  = imjustgood(wait["apikey"])
                           data = api.youtube(userId)
                           tz = pytz.timezone("Asia/Jakarta")
                           timeNow = datetime.now(tz=tz)
                           autor = "{}".format(data["result"]["author"])
                           audio = "{}".format(data["result"]["audioUrl"])
                           durasi = "Durasi : {}".format(data["result"]["duration"])
                           img = "{}".format(data["result"]["thumbnail"])
                           title = "{}".format(data["result"]["title"])
                           wath = "{}".format(data["result"]["watched"])
                           KONTOL = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/pJvKcvX/ezgif-com-gif-maker-19.png", "size": "full", "aspectMode": "cover", "aspectRatio": "2:1", "animated": True }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(img), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "40px", "height": "40px", "offsetTop": "12px", "offsetEnd": "13.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/GdyLZ5d/ezgif-com-gif-maker-69.png", "size": "100px", "aspectRatio": "2:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "100px", "height": "40px", "offsetStart": "8px" }, { "type": "image", "url": "https://i.ibb.co/C0yjDzt/ezgif-com-gif-maker-21.png", "size": "full", "aspectMode": "cover", "aspectRatio": "2:1", "animated": True, "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(autor), "size": "7px", "color": "#00ffff", "align": "center" } ], "position": "absolute", "width": "94px", "height": "11px", "offsetTop": "13px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(durasi), "size": "7px", "color": "#00ffff", "align": "center" } ], "position": "absolute", "width": "94px", "height": "11px", "offsetTop": "26.5px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(title), "size": "7px", "color": "#00ffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "131.5px", "height": "11px", "offsetBottom": "15.5px", "offsetEnd": "13.5px" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u914dd921845a59e01005b674177a1552" } } }
                           sendTemaplate(to, KONTOL)         
                           cl.sendMessage(to, "{}".format(data["result"]["videoUrl"]))

                        elif cmd.startswith('cuaca '):
                          #if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.cuaca(userId)
                           tz = pytz.timezone("Asia/Jakarta")
                           timeNow = datetime.now(tz=tz)
                           kontol = "╭───「 INFO CUACA 」───"
                           kontol += "\n├⌬ Jam : "+datetime.strftime(timeNow,'%H:%M:%S')
                           kontol += "\n├⌬ Tanggal : "+datetime.strftime(timeNow,'%d-%m-%Y')
                           kontol += "\n├⌬ Lokasi : {}".format(data["result"]["location"])
                           kontol += "\n├⌬ Cuaca : {}".format(data["result"]["description"])
                           kontol += "\n├⌬ Suhu : {}".format(data["result"]["humidity"])
                           kontol += "\n├⌬ Tempratur : {}".format(data["result"]["temperature"])
                           kontol += "\n├⌬ Angin : {}".format(data["result"]["wind"])
                           kontol += "\n╰───────────────"         
                           cl.sendMessage(to, str(kontol))

                        elif cmd.startswith('sholat '):
                          #if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.adzan(userId)
                           kontol = "╭───「 INFO SHOLAT 」───"
                           kontol += "\n├⌬ Date : {}".format(data["result"]["tanggal"])
                           kontol += "\n├⌬ Wilayah : {}".format(data["result"]["wilayah"])
                           kontol += "\n├⌬ Ashar : {}".format(data["result"]["adzan"]["ashar"])
                           kontol += "\n├⌬ Duha : {}".format(data["result"]["adzan"]["dhuha"])
                           kontol += "\n├⌬ Dzuhur : {}".format(data["result"]["adzan"]["dzuhur"])
                           kontol += "\n├⌬ Imsyak : {}".format(data["result"]["adzan"]["imsyak"])
                           kontol += "\n├⌬ Isya : {}".format(data["result"]["adzan"]["isya"])
                           kontol += "\n├⌬ Mag'rib : {}".format(data["result"]["adzan"]["maghrib"])
                           kontol += "\n├⌬ Subuh : {}".format(data["result"]["adzan"]["subuh"])
                           kontol += "\n├⌬ Fajar : {}".format(data["result"]["adzan"]["terbit"])
                           kontol += "\n╰────────────────"         
                           cl.sendMessage(to, str(kontol))       

                        elif cmd == "corona":
                          #if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data = api.corona()
                           tz = pytz.timezone("Asia/Jakarta")
                           timeNow = datetime.now(tz=tz)
                           kontol = "╭──「 CORONA VIRUS 」──"
                           kontol += "\n├⌬ TIME : "+datetime.strftime(timeNow,'%H:%M:%S')
                           kontol += "\n├⌬ DATE : {}".format(data["result"]["date"])
                           kontol += "\n├⌬─────────────⌬"
                           kontol += "\n├⌬ INDONESIA"
                           kontol += "\n├⌬ TERJANGKIT : {}".format(data["result"]["indonesia"]["case"])
                           kontol += "\n├⌬ SEMBUH : {}".format(data["result"]["indonesia"]["fit"])
                           kontol += "\n├⌬ MENINGGAL : {}".format(data["result"]["indonesia"]["rip"])
                           kontol += "\n├⌬─────────────⌬"
                           kontol += "\n├⌬ SELURUH DUNIA"
                           kontol += "\n├⌬ TERJANGKIT : {}".format(data["result"]["world"]["case"])
                           kontol += "\n├⌬ SEMBUH : {}".format(data["result"]["world"]["fit"])
                           kontol += "\n├⌬ MENINGGAL : {}".format(data["result"]["world"]["rip"])
                           kontol += "\n╰────────────────"         
                           cl.sendMessage(to, str(kontol))        

                        elif cmd == "surahlist":
                          #if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data = api.alquran()
                           vian  = "LIST SURAH AL-QUR'AN"
                           for qs in data:
                               vian += "\n{}".format(qs)
                           cl.sendMessage(to, str(vian))

                        elif cmd.startswith('surah '):
                          #if msg._from in admin:
                              try:
                                  args = text.split(" ")
                                  userId = text.replace(args[0] + " ","")
                                  api = imjustgood(wait["apikey"])
                                  data = api.alquranQS(userId) 
                                  audioUrl = data["result"]["audio"]
                                  vian = "Di Turunkan Di :{}\n".format(data["result"]["place"])
                                  vian += "{}".format(data["result"]["desc"])
                                  cl.sendReplyMessage(msg.id,to, (vian))
                                  cl.sendMessageAudio(to, str(audioUrl))
                              except Exception as error:
                                  cl.sendReplyMessage(msg.id,to, "ERROR!\nText Terlalu Panjang!!")         

                        elif cmd == "info bmkg":
                          #if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data = api.bmkg()
                           kontol = "╭──「 INFO BMKG 」──"
                           kontol += "\n├⌬ Time : {}".format(data["result"]["pukul"])
                           kontol += "\n├⌬ Date : {}".format(data["result"]["tanggal"])
                           kontol += "\n├⌬ Wilayah : {}".format(data["result"]["wilayah"])
                           kontol += "\n├⌬ Kekuatan : {}".format(data["result"]["kekuatan"])
                           kontol += "\n├⌬ Kedalaman : {}".format(data["result"]["kedalaman"])
                           kontol += "\n├⌬ Kordinat : {}".format(data["result"]["kordinat"])
                           kontol += "\n├⌬ Lokasi : {}".format(data["result"]["lokasi"])
                           kontol += "\n├⌬ Arhan : {}".format(data["result"]["arahan"])
                           kontol += "\n├⌬ Saran : {}".format(data["result"]["saran"])
                           kontol += "\n╰─────────────"         
                           cl.sendMessage(to, str(kontol))        

                        elif cmd.startswith('fancytext '):
                          #if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.fancy(userId) 
                           vian = "FANCY RESULT :\n"
                           for s in data["result"]:
                               vian += "\n{}\n".format(s)
                           cl.sendReplyMessage(msg.id,to, str(vian))         

                        elif cmd.startswith('acaratv '):
                          #if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.acaratv_channel(userId) 
                           vian = "Jadwal Acara TV"
                           for a in data["result"]:
                               vian += "\n{}".format(a)
                           cl.sendMessage(to, str(vian))    

                        elif cmd == "acara tv":
                          #if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data   = api.acaratv()
                           result = "ACARA TV"
                           for a in data["result"]:
                               for b in a:
                                   result += "\n\nChannel : {}".format(b)
                                   for c in a[b]:
                                       result += "\n{}".format(c)
                           cl.sendMessage(to, str(result))      

                        elif cmd == "info loker":
                          #if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data   = api.karir()
                           number = 0
                           apkbot = "INFO LOWONGAN KERJA"
                           for a in data["result"]:
                               number += 1
                               apkbot += "\n\n{}. {}".format(number,a["perusahaan"])
                               apkbot += "\nLokasi : {}".format(a["lokasi"])
                               apkbot += "\nProfesi : {}".format(a["profesi"])
                               apkbot += "\nBagian : {}".format(a["bagian"])
                               apkbot += "\nJabatan : {}".format(a["jabatan"])
                               apkbot += "\nGaji : {}".format(a["gaji"])
                               apkbot += "\nPendidikan : {}".format(a["pendidikan"])
                               apkbot += "\nPengalaman : {}".format(a["pengalaman"])
                               apkbot += "\nSyarat : {}".format(a["syarat"])
                               apkbot += "\nDeskirpsi : {}".format(a["deskripsi"])
                               apkbot += "\nSumber : {}".format(a["sumber"])
                           cl.sendReplyMessage(msg.id,to, str(apkbot))     

                        elif cmd.startswith("zodiak"):
                            #if msg._from in admin:
                                set = text.split(" ")
                                search = text.replace(set[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                data = api.zodiac(search)
                                vian = "╭─── • ZODIAK • ──"
                                vian += "\n├≽ Sign : {}".format(data["result"]["zodiac"])
                                vian += "\n├≽ Couple : {}".format(data["result"]["couple"])
                                vian += "\n├≽ Date Range : {}".format(data["result"]["date"])
                                vian += "\n├≽ Lucky Color : {}".format(data["result"]["color"])
                                vian += "\n├≽ Lucky Time : {}".format(data["result"]["time"])
                                vian += "\n├≽ Lucky Number : {}".format(data["result"]["number"])
                                vian += "\n├≽ Public : {}".format(data["result"]["public"])
                                vian += "\n├≽ Money : {}".format(data["result"]["money"])
                                vian += "\n├≽ Love Couple : {}".format(data["result"]["love"]["couple"])
                                vian += "\n├≽ Love Single : {}".format(data["result"]["love"]["single"])
                                vian += "\n╰── • Zul_Bost • ──"
                                cl.sendReplyMessage(msg.id,to, str(vian)) 

                        elif cmd.startswith('instagram '):
                          #if msg._from in admin:
                              try:
                                  args = text.split(" ")
                                  userId = text.replace(args[0] + " ","")
                                  api = imjustgood(wait["apikey"])
                                  data = api.instagram(userId) 
                                  user = "{}".format(data["result"]["username"])
                                  folwer = "{}".format(data["result"]["follower"])
                                  folwing = "{}".format(data["result"]["following"])
                                  post = "{}".format(data["result"]["post"])
                                  bio = "{}".format(data["result"]["biography"])
                                  pict = "{}".format(data["result"]["picture"])
                                  INSTA = {"type": "flex","altText": "TEAM TERMUX","contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co.com/vz3vV2G/ezgif-com-gif-maker-16.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:4", "animated": True }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(pict), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "102px", "height": "102px", "offsetTop": "20px", "offsetStart": "29px" }, { "type": "image", "url": "https://i.ibb.co.com/rfj2q51/ezgif-com-gif-maker-18.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:4", "animated": True, "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(user), "size": "7px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "113px", "height": "10px", "offsetTop": "7px", "offsetStart": "24px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(folwer), "size": "7px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "90px", "height": "10px", "offsetTop": "127px", "offsetStart": "35px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(folwing), "size": "7px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "90px", "height": "10px", "offsetTop": "142px", "offsetStart": "35px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(post), "size": "7px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "90px", "height": "10px", "offsetTop": "156px", "offsetStart": "35px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(bio), "size": "7px", "color": "#00ff00", "wrap": True, "align": "center" } ], "position": "absolute", "width": "130px", "height": "30px", "offsetBottom": "16px", "offsetStart": "15px" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1c5233bdc0da4800d07131656e106068" } } }
                                  sendTemplate(to, INSTA)           
                              except Exception as error:
                                  cl.sendReplyMessage(msg.id,to,str(error))

                        elif cmd.startswith('google '):
                          #if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.search(userId) 
                           pretyPrintJson(data)
                           number = 0
                           result = "GOOGLE SEARCH RESULT :"
                           for s in data["result"]:
                               number += 1
                               result += "\n{}. {}".format(number,s["title"])
                               result += "\n{}".format(s["snippet"])
                               result += "\n{}".format(s["url"])
                           cl.sendReplyMessage(msg.id,to, str(result))                  

                        elif cmd.startswith("ponsel"):
                            #if msg._from in admin:
                                set = text.split(" ")
                                search = text.replace(set[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                data = api.cellular(search)
                                pretyPrintJson(data)
                                number = 0
                                vian = "SPESIFIKASI PONSEL\n"
                                for a in data["result"]:
                                    number += 1
                                    vian += "\n• {}. {}\n".format(number,a["brands"])
                                    vian += "\n• Release : {}".format(a["release"])
                                    vian += "\n• Chipset : {}".format(a["chipset"])
                                    vian += "\n• Screen : {}".format(a["screen"])
                                    vian += "\n• Battery : {}".format(a["battery"])
                                    vian += "\n• Display : {}".format(a["display"])
                                    vian += "\n• Ram : {}".format(a["ram"])
                                    vian += "\n• Storage : {}\n".format(a["storage"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
 
                        elif cmd.startswith("resi-sicepat:"):
                          #if msg._from in admin:
                            try:
                                memek = text.split(" ")
                                ngewe = text.replace(memek[0] + " ","")
                                api = BEAPI(wait["apikey2"])
                                kontol = api.trackingResi(ngewe,"sicepat")
                                vian  = "{}\n".format(kontol["result"]["summary"]["courier_name"])
                                vian += "Resi : {}\n".format(kontol["result"]["summary"]["waybill_number"])
                                vian += "Tanggall : {}\n".format(kontol["result"]["delivery_status"]["pod_date"])
                                vian += "Jam : {}\n".format(kontol["result"]["delivery_status"]["pod_time"])
                                vian += "Penerima : {}\n".format(kontol["result"]["delivery_status"]["pod_receiver"])
                                vian += "Status : {}\n".format(kontol["result"]["delivery_status"]["status"])
                                for a in kontol["result"]["manifest"]:
                                    vian += "\n\n{}".format(a["manifest_description"])
                                    vian += "\nJam : {}".format(a["manifest_time"])
                                    vian += "\nTanggal :{}".format(a["manifest_date"])
                                    vian += "\nTanggal :{}".format(a["city_name"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))
 
                        elif cmd.startswith("resi-pos:"):
                          #if msg._from in admin:
                            try:
                                memek = text.split(" ")
                                ngewe = text.replace(memek[0] + " ","")
                                api = BEAPI(wait["apikey2"])
                                kontol = api.trackingResi(ngewe,"pos")
                                vian  = "{}\n".format(kontol["result"]["summary"]["courier_name"])
                                vian += "Resi : {}\n".format(kontol["result"]["summary"]["waybill_number"])
                                vian += "Tanggall : {}\n".format(kontol["result"]["delivery_status"]["pod_date"])
                                vian += "Jam : {}\n".format(kontol["result"]["delivery_status"]["pod_time"])
                                vian += "Penerima : {}\n".format(kontol["result"]["delivery_status"]["pod_receiver"])
                                vian += "Status : {}\n".format(kontol["result"]["delivery_status"]["status"])
                                for a in kontol["result"]["manifest"]:
                                    vian += "\n\n{}".format(a["manifest_description"])
                                    vian += "\nJam : {}".format(a["manifest_time"])
                                    vian += "\nTanggal :{}".format(a["manifest_date"])
                                    vian += "\nTanggal :{}".format(a["city_name"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith("resi-rex:"):
                          #if msg._from in admin:
                            try:
                                memek = text.split(" ")
                                ngewe = text.replace(memek[0] + " ","")
                                api = BEAPI(wait["apikey2"])
                                kontol = api.trackingResi(ngewe,"rex")
                                vian  = "{}\n".format(kontol["result"]["summary"]["courier_name"])
                                vian += "Resi : {}\n".format(kontol["result"]["summary"]["waybill_number"])
                                vian += "Tanggall : {}\n".format(kontol["result"]["delivery_status"]["pod_date"])
                                vian += "Jam : {}\n".format(kontol["result"]["delivery_status"]["pod_time"])
                                vian += "Penerima : {}\n".format(kontol["result"]["delivery_status"]["pod_receiver"])
                                vian += "Status : {}\n".format(kontol["result"]["delivery_status"]["status"])
                                for a in kontol["result"]["manifest"]:
                                    vian += "\n\n{}".format(a["manifest_description"])
                                    vian += "\nJam : {}".format(a["manifest_time"])
                                    vian += "\nTanggal :{}".format(a["manifest_date"])
                                    vian += "\nTanggal :{}".format(a["city_name"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith("resi-jnt:"):
                          #if msg._from in admin:
                            try:
                                memek = text.split(" ")
                                ngewe = text.replace(memek[0] + " ","")
                                api = BEAPI(wait["apikey2"])
                                kontol = api.trackingResi(ngewe,"jnt")
                                vian  = "{}\n".format(kontol["result"]["summary"]["courier_name"])
                                vian += "Resi : {}\n".format(kontol["result"]["summary"]["waybill_number"])
                                vian += "Tanggall : {}\n".format(kontol["result"]["delivery_status"]["pod_date"])
                                vian += "Jam : {}\n".format(kontol["result"]["delivery_status"]["pod_time"])
                                vian += "Penerima : {}\n".format(kontol["result"]["delivery_status"]["pod_receiver"])
                                vian += "Status : {}\n".format(kontol["result"]["delivery_status"]["status"])
                                for a in kontol["result"]["manifest"]:
                                    vian += "\n\n{}".format(a["manifest_description"])
                                    vian += "\nJam : {}".format(a["manifest_time"])
                                    vian += "\nTanggal :{}".format(a["manifest_date"])
                                    vian += "\nTanggal :{}".format(a["city_name"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith("resi-ninja:"):
                          #if msg._from in admin:
                            try:
                                memek = text.split(" ")
                                ngewe = text.replace(memek[0] + " ","")
                                api = BEAPI(wait["apikey2"])
                                kontol = api.trackingResi(ngewe,"ninja")
                                vian  = "{}\n".format(kontol["result"]["summary"]["courier_name"])
                                vian += "Resi : {}\n".format(kontol["result"]["summary"]["waybill_number"])
                                vian += "Tanggall : {}\n".format(kontol["result"]["delivery_status"]["pod_date"])
                                vian += "Jam : {}\n".format(kontol["result"]["delivery_status"]["pod_time"])
                                vian += "Penerima : {}\n".format(kontol["result"]["delivery_status"]["pod_receiver"])
                                vian += "Status : {}\n".format(kontol["result"]["delivery_status"]["status"])
                                for a in kontol["result"]["manifest"]:
                                    vian += "\n\n{}".format(a["manifest_description"])
                                    vian += "\nJam : {}".format(a["manifest_time"])
                                    vian += "\nTanggal :{}".format(a["manifest_date"])
                                    vian += "\nTanggal :{}".format(a["city_name"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))
                                                                                  
                        elif cmd.startswith("gnamegrup"):
                          #if msg._from in admin:
                            if msg.toType == 2:
                                X = cl.getChats(to)
                                #X.displayName = text.split(" ")
                                X.name = text.split(" ")
                                cl.updateGroup(X)

                        elif cmd.startswith("stag "):
                          #if msg._from in admin:
                            text_ = cmd.replace("stag ", "")
                            cond = text_.split(" ")
                            text = text_.replace(cond[0] + " ", "")
                            jml = int(cond[0])
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    text = text.replace("@{}".format(str(contact.displayName)),"")
                                if "|" in text:
                                    cond = text.split("|")
                                    fm = cond[0]
                                    lm = cond[1]
                                else:
                                    fm = ""
                                    lm = text
                                for ls in lists:
                                    for x in range(jml):
                                        sendMentionZul(to, ls, str(fm), str(lm))
                                cl.sendMessage(msg.to, "「 Succes tag {} user , with amount {} tags 」".format(str(len(lists)), str(jml)))
                                return
                            else:
                                cl.sendMessage(msg.to, "🛑Nothing user :v")
                                return

                        elif cmd.startswith("spamtag "):
                          #if msg._from in admin:
                            text_ = cmd.replace("spamtag ", "")
                            cond = text_.split(" ")
                            text = text_.replace(cond[0] + " ", "")
                            jml = int(cond[0])
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    text = text.replace("@{}".format(str(contact.displayName)),"")
                                if "|" in text:
                                    cond = text.split("|")
                                    fm = cond[0]
                                    lm = cond[1]
                                else:
                                    fm = ""
                                    lm = text
                                for ls in lists:
                                    for x in range(jml):
                                        sendMention(to, ls, str(fm), str(lm))
                                sendFoter(msg.to, "「 Succes tag {} user , with amount {} tags 」".format(str(len(lists)), str(jml)))
                                return
                            else:
                                cl.sendMessage(msg.to, "🛑Nothing user :v")
                                return

                        elif cmd.startswith("jumlah: "):
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                sendZulBots3(msg.to,"🛑ᴛᴏᴛᴀʟ sᴘᴀᴍᴄᴀʟʟ ᴅɪ ʀᴜʙᴀʜ ᴊᴀᴅɪ " +strnum)

                        elif cmd == "scall":
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                             if msg.toType == 2:
                                members = [mem for mem in cl.getChats([msg.to],True,True).chats[0].extra.groupExtra.memberMids]
                                jmlh = int(wait["limit"])
                                sendZulBots3(msg.to, "🛑Sukses Call {} 🛑Grup".format(str(wait["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        cl.acquireGroupCallRoute(to)
                                        cl.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        cl.sendText(to,str(e))
                                else:
                                    sendZulBots3(msg.to,"🛑Jumlah melebihi batas")

                        elif cmd.startswith("block "):
                          #if msg._from in admin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.blockContact(ls)
                                sendZulBots3(msg.to, "🛑Success add " + str(contact.displayName) + " to Blocklist")

                        elif cmd == "cvp":
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                settings["changevp"] = True
                                sendZulBots3(msg.to, "🛑Kirim Video ny")

                        elif cmd.startswith("cvp: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                sep = text.split(" ")
                                FckVeza = text.replace(sep[0] + " ","")
                                FckVezaGans = cl.getContact(sender)
                                flexvian(msg.to, "🛑Loading...")
                                pic = "http://dl.profile.line-cdn.net/{}".format(FckVezaGans.pictureStatus)
                                subprocess.getoutput('youtube-dl --format mp4 --output vp.mp4 {}'.format(FckVeza))
                                pict = cl.downloadFileURL(pic)
                                vids = "vp.mp4"
                                changeVideoAndPictureProfile(pict, vids)
                                sendZulBots3(msg.to, "🛑Dual Profile Video ♪")
                                os.remove("vp.mp4")

                        elif cmd == "cinema xx1":
                          #if msg._from in admin:
                            result = requests.get("http://jadwalnonton.com/")
                            data = BeautifulSoup(result.content, 'html5lib')
                            hasil = "[ Cinema XX1 ]\nType : Movie List Today\n"
                            no = 1
                            for dzin in data.findAll('div', attrs={'class':'col-xs-6 moside'}):
                                hasil += "\n\n{}. {}".format(str(no), str(dzin.find('h2').text))
                                hasil += "\n     Link : {}".format(str(dzin.find('a')['href']))
                                no = (no+1)
                            cl.sendReplyMessage(msg.id,to, str(hasil))
                                        
                        elif cmd.startswith("fs "):
                          #if msg._from in admin:
                            sep = text.split(" ")
                            txt = text.replace(sep[0] + " ","")
                            url = "https://rest.farzain.com/api/special/fansign/cosplay/cosplay.php?apikey=nda12345&text={}".format(txt)
                            cl.sendMessageImage(to, url)

                        elif cmd.startswith("anime: "):
                          #if msg._from in admin:
                            sep = msg.text.split(" ")
                            judul = msg.text.replace(sep[0] + " ","")
                            tahun = msg.text.replace(sep[1] + " ","")
                            r=requests.get('https://www.omdbapi.com/?t='+judul+'&y='+tahun+'&plot=full&apikey=4bdd1d70')
                            data=r.text
                            data=json.loads(data)
                            ret_ = "「 Anime Search 」"
                            ret_ += "\nTitle : " +str(data["Title"])  + " ("+str(data["Year"])+ ")"
                            ret_ += "\n\n " + str(data["Plot"])
                            ret_ += "\n\nSumber Info: https://myanimelist.net/anime"                       
                            img = data["Poster"]
                            cl.sendMessageImage(to,str(img))
                            cl.sendReplyMessage(msg.id,to, str(ret_))

                        elif cmd.startswith('pict '):
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                               res = '╭───「 Picture Status 」'
                               no = 0
                               if 'MENTION' in msg.contentMetadata.keys():
                                   mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                                   if len(mentions['MENTIONEES']) == 1:
                                       profile = cl.getContact(mentions['MENTIONEES'][0]['M'])
                                       if profile.pictureStatus:
                                           path = 'http://dl.profile.line-cdn.net/' + profile.pictureStatus
                                           cl.sendImageWithURL(to, path)
                                       else:
                                           cl.sendReplyMessage(msg.id,to, '🛑Failed steal picture status, user `%s` doesn\'t have a picture status' % profile.displayName)
                                
                        elif cmd.startswith('cover '):
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                               res = '╭───「 Picture Cover 」'
                               no = 0
                               if 'MENTION' in msg.contentMetadata.keys():
                                   mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                                   if len(mentions['MENTIONEES']) == 1:
                                       mid = mentions['MENTIONEES'][0]['M']
                                       cover = cl.getProfileCoverURL(mid)
                                       cl.sendImageWithURL(to, cover)
                                   else:
                                       cl.sendMessage(msg.to, '🛑Failed steal picture status, user `%s` doesn\'t have a picture status' % profile.displayName)
                                    
                        elif cmd.startswith("video "):
                          #if msg._from in admin:  
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    if contact.videoProfile == None:
                                    	continue
                                    path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus + "/vp"
                                    cl.sendVideoWithURL(to, str(path))
                                                                            
                        elif cmd.startswith("name "):
                          #if msg._from in admin:  
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.sendReplyMessage(msg.id,to, "[ Display Name ]\n{}".format(str(contact.displayName)))
                                    
                        elif cmd.startswith("bio "):
                          #if msg._from in admin:  
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.sendReplyMessage(msg.id,to, "[ Status Message ]\n{}".format(str(contact.statusMessage)))
                                
                        elif cmd.startswith("addfriend "):
                          #if msg._from in admin:  
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.findAndAddContactsByMid(ls)
                                sendZulBots3(msg.to, "🛑Success Add " + str(contact.displayName) + " to Friendlist")
                                
                        elif cmd.startswith("sepak "):
                          #if msg._from in admin:  
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        cl.deleteOtherFromChat(to, [ls])
                                        cl.inviteIntoChat(to, [ls])
                                        cl.cancelChatInvitation(to, [ls])
                                    except:
                                       sendZulBots3(msg.to, "🛑Limited !")
      
                        elif cmd.startswith("invite "):
                                if msg._from in creator or msg._from in owner or msg._from in admin:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    for target in targets:                                                                            
                                        try:      
                                            cl.findAndAddContactsByMid(target)
                                            cl.inviteIntoChat(to,[target])                                             
                                            sendZulBots3(mag.to, "User @!\n🛑Target sudah di invite..", [target])
                                        except:
                                            pass

                        elif msg.text.lower().startswith("up "):
                          #if msg._from in admin:
                           if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                               names = re.findall(r'@(\w+)', text)
                               mention = eval(msg.contentMetadata['MENTION'])
                               mentionees = mention['MENTIONEES']
                               lists = []
                               for mention in mentionees:
                                   if mention["M"] not in lists:
                                       lists.append(mention["M"])
                               for ls in lists:
                                   contact = cl.getContact(ls)                          
                                   jmlh = int(wait["limit"])
                                   sendTextTemplate200(msg.to, "🛑ᴍᴇᴍᴀɴɢɢɪʟ ᴋᴀᴍᴜ {} ᴋᴀʟɪ".format(str(wait["limit"])))
                                   if jmlh <= 1000:
                                     for x in range(jmlh):
                                         try:
                                             mids = [contact.mid]
                                             cl.acquireGroupCallRoute(to)
                                             cl.inviteIntoGroupCall(to,mids)
                                         except Exception as e:
                                             cl.sendMessage(to,str(e))
                                     else:
                                         sendZulBots3(to,"")

                        elif cmd.startswith("vcall "):
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                                if msg.toType == 2:
                                    strnum = removeCmd("vcall", text)
                                    num = int(strnum)                        
                                    for var in range(0,num):
                                        group = cl.getChats([to]).chats[0]
                                        cl.acquireGroupCallRoute(to)
                                        time.sleep(0.2)
                                        cl.inviteIntoGroupCall(to, contactIds=group.extra.groupExtra.memberMids)                                                                 
                                    sendZulBots3(msg.to, '「 Detect Spam 」\n › Type: Spamcall Group♪\n    • In Group: {}\n    • Amount: {}\n    • Status: Success'.format(group.chatName, strnum))  

                        elif 'Gift: ' in msg.text:
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              korban = msg.text.replace('Gift: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      cl.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)

                        elif 'Spam: ' in msg.text:
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              korban = msg.text.replace('Spam: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      cl.sendMessage(midd, str(Setmain["RAmessage1"]))

                        elif 'idline: ' in msg.text:
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              msgs = msg.text.replace('idline: ','')
                              conn = cl.findContactsByUserid(msgs)
                              if True:
                                  cl.sendReplyMessage(msg.id,to, "http://line.me/ti/p/~" + msgs)
                                  cl.sendMessage(to, None, contentMetadata={'mid': conn.mid}, contentType=13)

                        elif msg.text.lower() in tes["Message"]:
                            if wait["autotext"] == True:
                                sid = tes["Message"][msg.text.lower()]
                                cl.sendReplyMessage(msg.id, to, sid)     
                                    
                        elif msg.text.lower() in wait["stickers"]:
                           if wait["apkTikel"] == True:
                             if msg.text.lower() in wait["stickers"]:
                                 sid = wait["stickers"][msg.text.lower()]["STKID"]
                                 time.sleep(1)
                                 data = {
                                     "type": "template",
                                     "altText": "Sticker",
                                     "baseSize": { #
                                         "height": 1040, #
                                         "width": 1040 #
                                     }, #
                                     "template": {
                                         "type": "image_carousel",
                                         "columns": [{
                                             "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png".format(sid), 
                                             "action": {
                                                 "type": "uri",
                                                 "uri": "line://ti/p/~zul.1.02",
                                                 "area": {
                                                     "x": 520,
                                                     "y": 0,
                                                     "width": 520,
                                                     "height": 1040
                                                 }
                                             }
                                         }]
                                     }
                                 }
                                 sendTemplate(to, data)      
                                    
                        elif cmd.startswith("dellsticker: "):
                          #if msg._from in admin:
                                proses = text.split(" ")
                                nama = text.replace(proses[0] + " ","")
                                try:
                                    if nama not in wait["stickers"]:
                                        cl.sendMessage(msg.to,"🛑List Sticker Kosong.")
                                    else:
                                        del wait["stickers"][nama]
                                        f=codecs.open("sticker.json","w","utf-8")
                                        json.dump(wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                        sendZulBots3(msg.to,"🛑Hapus Sticker ✓")
                                except Exception as e:
                                    cl.sendMessage(to,"{}".format(str(e)))
                                    
                        elif cmd.startswith("stickerlist"):
                          #if msg._from in admin:
                                if wait["stickers"] == {}:
                                    cl.sendMessage(msg.to,"🛑Nothing sticker")
                                else:
                                    no = 0
                                    ret_ = "List\n"
                                    for a in wait["stickers"]:
                                        no += 1
                                        ret_ += "\n" +str(no)+". " +str(a)
                                    ret_ += "\n\nList %i Sticker" % len(wait["stickers"])
                                    cl.sendMessage(to, ret_)  
  
                        elif cmd.startswith("addsticker: "):
                          #if msg._from in admin:
                                proses = text.split(" ")
                                nama = text.replace(proses[0] + " ","")
                                try:
                                    if nama in wait["stickers"]:
                                        sendZulBots3(msg.to,"🛑Sudah ada dalam list")
                                    else:
                                        wait["stk"] = nama
                                        wait["sticker"] = True
                                        f=codecs.open("sticker.json","w","utf-8")
                                        json.dump(wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                        sendZulBots3(msg.to,"🛑Send a stickers ✓")
                                except Exception as e:
                                    cl.sendMessage(to,"{}".format(str(e)))
                   
#===========Protection============#
                        elif cmd.startswith("welcomemsg "):
                           #if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "Welcome Sudah Aktif ♪"
                                       cl.sendMessage(to, msgs)
                                  else:
                                       welcome.append(to)
                                       ginfo = cl.getChats([to], True , False).chats[0]
                                       msgs = "🛑Leave Msg diaktifkan\n🛑Di Group : " +str(ginfo.chatName)
                                       sendZulBots3(to, msgs)
                                  #cl.sendMessage(msg.to, "Welcome Enable ✓")
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(to)
                                         ginfo = cl.getChats([to], True , False).chats[0]
                                         msgs = "🛑Leave Msg dinonaktifkan\n🛑Di Group : " +str(ginfo.chatName)
                                         cl.sendMessage(to, msgs)
                                    else:
                                         msgs = "🛑Leave Msg sudah tidak aktif"
                                         sendZulBots3(to, msgs)
                                    #cl.sendMessage(msg.to, "Welcome Disable ✓")

                                
                        elif cmd.startswith("leavemsg "):
                           #if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in leave:
                                       msgs = "🛑Leave Msg sudah aktif"
                                  else:
                                       leave.append(to)
                                       ginfo = cl.getChats(to)
                                       msgs = "🛑Leave Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendZulBots3(msg.to, "🛑Leave Msg Enable ✓")
                              elif spl == 'off':
                                    if msg.to in leave:
                                         leave.remove(to)
                                         ginfo = cl.getChats(to)
                                         msgs = "🛑Leave Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "🛑Leave Msg sudah tidak aktif"
                                    sendZulBots3(msg.to, "🛑Leave Msg Disable ✓")

                        elif cmd.startswith("pqr "):
                           #if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "🛑Protect url sudah aktif"
                                  else:
                                       protectqr.append(to)
                                       ginfo = cl.getChats(to)
                                       msgs = "🛑Protect url diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendZulBots3(msg.to, "🛑Protect qr enable")
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(to)
                                         ginfo = cl.getChats(to)
                                         msgs = "🛑Protect url dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "🛑Protect url sudah tidak aktif"
                                    sendZulBots3(msg.to, "🛑Protect qr disable")

                        elif cmd.startswith("pkick "):
                           #if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "🛑Protect kick sudah aktif"
                                  else:
                                       protectkick.append(to)
                                       ginfo = cl.getChats(to)
                                       msgs = "🛑Protect kick diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendZulBots3(msg.to, "🛑Protect kick enable")
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(to)
                                         ginfo = cl.getChats(to)
                                         msgs = "🛑Protect kick dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "🛑Protect kick sudah tidak aktif"
                                    sendZulBots3(msg.to, "🛑Protect kick disable")

                        elif cmd.startswith("pjoin "):
                           #if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "🛑Protect join sudah aktif"
                                  else:
                                       protectjoin.append(to)
                                       ginfo = cl.getChats(to)
                                       msgs = "🛑Protect join diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendZulBots3(msg.to, "🛑Protect join enable")
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(to)
                                         ginfo = cl.getChats(to)
                                         msgs = "🛑Protect join dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "🛑Protect join sudah tidak aktif"
                                    sendZulBots3(msg.to, "🛑Protect join disble")

                        elif cmd.startswith("pcancell "):
                           #if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "🛑Protect cancel sudah aktif"
                                  else:
                                       protectcancel.append(to)
                                       ginfo = cl.getChats(to)
                                       msgs = "🛑Protect cancel diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendZulBots3(msg.to, "🛑Protect cancel enable")
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(to)
                                         ginfo = cl.getChats(to)
                                         msgs = "🛑Protect cancel dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "🛑Protect cancel sudah tidak aktif"
                                    sendZulBots3(msg.to, "🛑Protect cancel disable")
                        elif cmd == "quis on" or text.lower() == 'quis on':
                            #if msg._from in admin:
                                wait["quis"] = True                          
                                sendZulBots3(msg.to, "🛑QUIST AKTIF")
                        elif cmd == "quis off" or text.lower() == 'quis off':
                            #if msg._from in admin:
                                wait["quis"] = False                        
                                sendZulBots3(msg.to, "🛑QUIST MATI BOS")

                        elif text.lower() == "cekbot":
                            #if msg._from in admin:
                               try:cl.inviteIntoChat(to, ["ua6105e31b80ad992f5dcc02003a9ecd6"]);has = "OK"
                               except:has = "NOT"
                               try:cl.deleteOtherFromChat(to, ["ua6105e31b80ad992f5dcc02003a9ecd6"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "👉Normal 💯"
                               else:sil = "👉Cidera ❌"
                               if has1 == "OK":sil1 = "👉Normal 💯"
                               else:sil1 = "👉Cidera ❌"
                               cl.sendMessage(msg.to, "💥====[TEAM BOTS]===💥\n\n🔴Dupak: {} \n🔴Invite: {}".format(sil1,sil))

                        elif text.lower() == "cekbot2":
                            #if msg._from in admin:
                               try:cl.inviteIntoChat(to, ["ua6105e31b80ad992f5dcc02003a9ecd6"]);has = "OK"
                               except:has = "NOT"
                               try:cl.deleteOtherFromChat(to, ["ua6105e31b80ad992f5dcc02003a9ecd6"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "👉Normal 💯"
                               else:sil = "👉Cidera ❌"
                               if has1 == "OK":sil1 = "👉Normal 💯"
                               else:sil1 = "👉Cidera ❌"
                               sendZulBots1(msg.to, "💥====[TEAM BOTS]===💥\n\n🔴Dupak: {} \n🔴Invite: {}".format(sil1,sil))

                        elif cmd == "joinquis on":
                            #if msg._from in admin:
                                if wait["autoJoinquis"] == True:
                                    foro2(msg.to, "🛑join aktif")
                                else:
                                    wait["autoJoinquis"] = True
                                    sendZulBots3(msg.to, "🛑join Diaktifkan")

                        elif cmd == "joinquis off":
                            #if msg._from in admin:
                                if wait["autoJoinquis"] == False:
                                    foro(msg.to, "🛑Auto Tewas")
                                else:
                                    wait["autoJoin"] = False
                                    sendZulBots3(msg.to, "🛑Auto Tewas")

                        elif cmd.startswith("pinvite "):
                           #if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "🛑Protect invite sudah aktif"
                                  else:
                                       protectinvite.append(to)
                                       ginfo = cl.getChats(to)
                                       msgs = "🛑Protect in : " +str(ginfo.name)
                                  sendZulBots3(msg.to, "🛑Protect invite enable")
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(to)
                                         ginfo = cl.getChats(to)
                                         msgs = "🛑Protect invite dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "🛑Protect invite sudah tidak aktif"
                                    sendZulBots3(msg.to, "🛑Protect invite disable")
                        elif cmd.startswith('protect:off '):
                            #if msg._from in admin:
                               sep = text.split(" ")
                               num = text.replace(sep[0] + " ","")
                               groups = cl.getAllChatIds()
                               target = groups[int(num)-1]
                               try:
                                   protectqr.remove(target)
                                   protectkick.remove(target)
                                   protectjoin.remove(target)
                                   protectinvite.remove(target)
                                   protectcancel.remove(target)
                                   sendZulBots3(msg.to, "🛑Succes off Pro Group  {} ".format(cl.getChats(target).name))
                               except:pass
                        elif cmd.startswith('protect:on '):
                            #if msg._from in admin:
                               sep = text.split(" ")
                               num = text.replace(sep[0] + " ","")
                               groups = cl.getAllChatIds()
                               target = groups[int(num)-1]
                               try:
                                   protectqr.append(target)
                                   protectkick.append(target)
                                   protectjoin.append(target)
                                   protectinvite.append(target)
                                   protectcancel.append(target)
                                   sendZulBots3(msg.to, "🛑Succes on pro di Group  {} ".format(cl.getChats(target).name))
                               except:pass
                        elif cmd.startswith("protect "):
                           #if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(to)
                                  if msg.to in protectinvite:
                                      msgs = ""
                                  else:
                                      protectinvite.append(to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(to)
                                  if msg.to in protectjoin:
                                      msgs = ""
                                  else:
                                      protectjoin.append(to)
                                  if msg.to in protectcancel:
                                      ginfo = cl.getChats(to)
                                      msgs = "🛑Max protection enable "
                                  else:
                                      protectcancel.append(to)
                                      ginfo = cl.getChats(to)
                                      msgs = "🛑Max protection allready On"
                                  sendZulBots3(msg.to, "🛑All protection enable")
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectinvite:
                                         protectinvite.remove(to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectjoin:
                                         protectjoin.remove(to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(to)
                                         ginfo = cl.getChats(to)
                                         msgs = "🛑Max protection Disable"
                                    else:
                                         ginfo = cl.getChats(to)
                                         msgs = "🛑Max protection allready disble"
                                    sendZulBots3(msg.to, "🛑All protection disable")

#===========KICKOUT============#

                        elif cmd.startswith("xxxxxkick "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           sendZulBots3(msg.to, "@!\n🛑Minggt Kau fuck!!", [target])
                                           cl.deleteOtherFromChat(to, [target])
                                       except:
                                           pass

                        elif cmd.startswith(comd["kick"]):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                       	cl.deleteOtherFromChat(to,[target])
                                       except:
                                           sendZulBots3(msg.to,"🛑Mimit gaess..")
#===========ADMIN ADD============#
                        elif cmd.startswith("adminadd "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           sendZulBots3(msg.to,"🛑Add To Adminlist ✓")
                                       except:
                                           pass

                        elif cmd.startswith("staffadd "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           sendZulBots3(msg.to,"🛑Add To Stafflist ✓")
                                       except:
                                           pass

                        elif ("Botadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Bots.append(target)
                                           sendZulBots3(msg.to,"🛑Add To Lisbot ✓")
                                       except:
                                           pass

                        elif cmd.startswith("botadd "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Bots.append(target)
                                           sendZulBots3(msg.to,"🛑Add To Lisbot ✓")
                                       except:
                                           pass

                        elif cmd.startswith("admindell "):
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in SoakBots:
                                       try:
                                           admin.remove(target)
                                           sendZulBots3(msg.to,"🛑Delete Admin ✓")
                                       except:
                                           pass

                        elif cmd.startswith("staffdell "):
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in SoakBots:
                                       try:
                                           staff.remove(target)
                                           sendZulBots3(msg.to,"🛑Delete Staff ✓")
                                       except:
                                           pass

                        elif cmd.startswith("botdell "):
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in SoakBots:
                                       try:
                                           Bots.remove(target)
                                           sendZulBots3(msg.to,"🛑delete Botlist ✓")
                                       except:
                                           pass
                                           
                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            #if msg._from in admin:
                                wait["addadmin"] = True
                                sendZulBots3(msg.to,"🛑Send Contact ✓")

                        elif cmd == "admin:repeat" or text.lower() == 'admin:repeat':
                            #if msg._from in admin:
                                wait["delladmin"] = True
                                sendZulBots3(msg.to,"🛑Send Contact ✓")

                        elif cmd == "staff:on" or text.lower() == 'staff:on':
                            #if msg._from in admin:
                                wait["addstaff"] = True
                                sendZulBots3(msg.to,"🛑Send Contact ✓")

                        elif cmd == "staff:repeat" or text.lower() == 'staff:repeat':
                            #if msg._from in admin:
                                wait["dellstaff"] = True
                                sendZulBots3(msg.to,"🛑Send Contact ✓")

                        elif cmd == "bot:on" or text.lower() == 'bot:on':
                            #if msg._from in admin:
                                wait["addbots"] = True
                                sendZulBots3(msg.to,"🛑Send Contact ✓")

                        elif cmd == "bot:repeat" or text.lower() == 'bot:repeat':
                            #if msg._from in admin:
                                wait["dellbots"] = True
                                sendZulBots3(msg.to,"🛑Send Contact ✓")

                        elif cmd == "refresh" or text.lower() == 'abort':
                            #if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                sendZulBots3(msg.to,"🛑Bots Jandanya Jdi Fres")

                        elif cmd == "contact admin" or text.lower() == 'contact admin':
                            #if msg._from in admin:
                                ma = ""
                                for i in admin:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact staff" or text.lower() == 'contact staff':
                            #if msg._from in admin:
                                ma = ""
                                for i in staff:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact bot" or text.lower() == 'contact bot':
                            #if msg._from in admin:
                                ma = ""
                                for i in Bots:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#
                        elif "assalamualaikum" in msg.text.lower():
                             if wait["responsalam"] == True:  
                                cl.sendReplyMessage(msg.id,to, "ُوَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")
                        elif "asslamualaikum" in msg.text.lower():
                             if wait["responsalam"] == True:  
                                cl.sendReplyMessage(msg.id,to, "ُوَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")
                        elif "assalamualaikum wr wb" in msg.text.lower():
                             if wait["responsalam"] == True:  
                                cl.sendReplyMessage(msg.id,to, "ُوَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")
                        elif "asslamualaikum wr wb" in msg.text.lower():
                             if wait["responsalam"] == True:  
                                cl.sendReplyMessage(msg.id,to, "ُوَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")
                        elif "asalamualaikum" in msg.text.lower():
                             if wait["responsalam"] == True:  
                                cl.sendReplyMessage(msg.id,to, "ُوَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")
                        elif "asalamualaikum wr wb" in msg.text.lower():
                             if wait["responsalam"] == True:  
                                cl.sendReplyMessage(msg.id,to, "ُوَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")
                        elif "asalamualaikum wr wb" in msg.text.lower():
                             if wait["responsalam"] == True:  
                                cl.sendReplyMessage(msg.id,to, "ُوَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")
                        elif "asalamualaikum wr wb" in msg.text.lower():
                             if wait["responsalam"] == True:  
                                cl.sendReplyMessage(msg.id,to, "ُوَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ  ")


                        elif cmd == "notag on":
                            #if msg._from in admin:
                                wait["Mentionkick"] = True
                                ret = "🛑Notag Enable ✓"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "notag off":
                            #if msg._from in admin:
                                wait["Mentionkick"] = False
                                ret = "🛑Notag Disable ✓"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "respon1 on":
                            #if msg._from in admin:
                                wait["detectMention1"] = True
                                wait["respontag"] = False
                                ret = "🛑Auto Respon1 Enable ✓"
                                sendZulBots3(to, str(ret))
                           
                        elif cmd == "respon1 off":
                            #if msg._from in admin:
                                wait["detectMention1"] = False
                                ret = "🛑Auto Respon1 Disable ✓"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "respon on":
                            #if msg._from in admin:
                                wait["respontag"] = True
                                wait["detectMention1"] = False
                                ret = "🛑Auto Respon Enable ✓"
                                sendZulBots3(to, str(ret))
                           
                        elif cmd == "respon off":
                            #if msg._from in admin:
                                wait["respontag"] = False
                                ret = "🛑Auto Respon Disable ✓"
                                sendZulBots3(to, str(ret))
                           
                        elif cmd == "autoread on":
                            #if msg._from in admin:
                                Setmain["autoRead"] = True
                                ret = "🛑Auto Read Enable ✓"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "autoread off":
                            #if msg._from in admin:
                                Setmain["autoRead"] = False
                                ret = "🛑Auto Read Disable ✓"
                                sendZulBots3(to, str(ret))

                        elif cmd == "contact on":
                            #if msg._from in admin:
                                wait["contact"] = True
                                ret = "🛑Detail contact Enable ✓"
                                sendZulBots3(mlto, str(ret))
                            
                        elif cmd == "contact off":
                            #if msg._from in admin:
                                wait["contact"] = False
                                ret = "🛑Detail Contact Disable ✓"
                                sendZulBots3(to, str(ret))

                        elif cmd == "autotext on":
                            #if msg._from in admin:
                                wait["autotext"] = True
                                ret = "🛑Autotext Enable ✓"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "autotext off":
                            #if msg._from in admin:
                                wait["autotext"] = False
                                ret = "🛑Autotext Disable"
                                sendZulBots3(to, str(ret))

                        elif cmd == "autoblock on":
                            #if msg._from in admin:
                                wait["autoBlock"] = True
                                ret = "🛑Auto Block Enable"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "autoblock off":
                            #if msg._from in admin:
                                wait["autoBlock"] = False
                                ret = "🛑Auto Block Disable"
                                sendZulBots3(to, str(ret))

                        elif cmd == "unsend on":
                            #if msg._from in admin:
                                wait["unsend"] = True
                                ret = "🛑Unsend Chat Enable"
                                sendZulBots3(to, str(ret))
                        elif cmd == "liff gue":
                            #if msg._from in admin:
                                sendZulBots3(msg.to, "🛑Berikut Data Liffmu Majikanku\n\nLiff [ 01 ] https://liff.line.me/2000602682-YP5KArqL\n\nLiff [ 02 ] https://liff.line.me/2000602728-ZB8DrLMB\n\nLiff [ 03 ] https://liff.line.me/2000602744-qe53a4vv")
                        elif cmd == "cekliff" or cmd == "cek liff":
                          #if msg._from in admin:
                              a = wait['saat']
                              b = wait['liff']
                              sendZulBots3(to, "{}".format(str(a) + "      {}".format(str(b))))
                        elif cmd == "liff1" or cmd == "liff 1":
                          #if msg._from in admin:
                              h =  wait["liff1"]
                              y = wait["anu1"]
                              b = wait["saat1"]
                              spl = "{}".format(str(h))
                              wait["liff"] = spl
                              spk = "{}".format(str(y))
                              wait["anu"] = spk
                              spd = "{}".format(str(b))
                              wait["saat1"] = spd
                              time.sleep(1)
                              sendZulBots3(msg.to, "🛑Done Update Liff 01\n=====================")
                        elif cmd == "liff2" or cmd == "liff 2":
                          #if msg._from in admin:
                              h =  wait["liff2"]
                              y = wait["anu2"]
                              b = wait["saat2"]
                              spl = "{}".format(str(h))
                              wait["liff"] = spl
                              spk = "{}".format(str(y))
                              wait["anu"] = spk
                              spd = "{}".format(str(b))
                              wait["saat2"] = spd
                              time.sleep(1)
                              sendZulBots3(msg.to, "🛑Done Update Liff 02\n=====================")
                        elif cmd == "liff3" or cmd == "liff 3":
                          #if msg._from in admin:
                              h =  wait["liff3"]
                              y = wait["anu3"]
                              b = wait["saat3"]
                              spl = "{}".format(str(h))
                              wait["liff"] = spl
                              spk = "{}".format(str(y))
                              wait["anu"] = spk
                              spd = "{}".format(str(b))
                              wait["saat3"] = spd
                              time.sleep(1)
                              cl.sendMessage(msg.to, "🛑Done Update Liff 03\n=====================")

                        elif cmd == "unsend on":
                            #if msg._from in admin:
                                wait["unsend"] = True
                                ret = "🛑Unsend Chat Disable"
                                sendZulBots3(to, str(ret))

                        elif cmd == "unsend off":
                            #if msg._from in admin:
                                wait["unsend"] = False
                                ret = "🛑Unsend Chat Disable"
                                sendZulBots3(to, str(ret))

                        elif cmd == "timeline on":
                            #if msg._from in admin:
                                wait["Timeline"] = True
                                ret = "🛑Detail Post Enable"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "timeline off":
                            #if msg._from in admin:
                                wait["Timeline"] = False
                                ret = "🛑Detail Post Disable"
                                sendZulBots3(to, str(ret))

                        elif cmd == "autojoin on":
                            #if msg._from in admin:
                                wait["autoJoin"] = True
                                ret = "🛑Auto Join Enable."
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "autojoin off":
                            #if msg._from in admin:
                                wait["autoJoin"] = False
                                ret = "🛑Auto Join Disable"
                                sendZulBots3(to, str(ret))

                        elif cmd == "autoleave on":
                            #if msg._from in admin:
                                wait["autoLeave"] = True
                                ret = "🛑Auto Leave Enable"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "autoleave off":
                            #if msg._from in admin:
                                wait["autoLeave"] = False
                                ret = "🛑Auto Leave Disable"
                                sendZulBots3(to, str(ret))

                        elif cmd == "autoadd on":
                            #if msg._from in admin:
                                wait["autoAdd"] = True
                                ret = "🛑Auto Add Enable"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "autoadd off":
                            #if msg._from in admin:
                                wait["autoAdd"] = False
                                ret = "🛑Auto Add Disable"
                                sendZulBots3(to, str(ret))
                                
                        elif cmd == "tikelgede on":
                            #if msg._from in admin:
                                wait["apkTikel"] = True
                                ret = "🛑Sticker Temp On."
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "tikelgede off":
                            #if msg._from in admin:
                                wait["apkTikel"] = False
                                ret = "🛑Sticker Temp Off"
                                sendZulBots3(to, str(ret))

                        elif cmd == "sticker on":
                            #if msg._from in admin:
                                wait["sticker"] = True
                                ret = "🛑Detail Sticker On"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "sticker off":
                            #if msg._from in admin:
                                wait["sticker"] = False
                                ret = "🛑Detail sticker Off"
                                sendZulBots3(to, str(ret))
                                
                        elif cmd == "media on":
                            #if msg._from in admin:
                                wait["rsmule"] = True
                                wait["tiktok"] = True
                                wait["ytube"] = True
                                ret = "🛑Detect Media On"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "media off":
                            #if msg._from in admin:
                                wait["rsmule"] = False
                                wait["ytube"] = False
                                wait["tiktok"] = False
                                ret = "🛑Detect Media Off"
                                sendZulBots3(to, str(ret))
                                
                        elif cmd == "smule on":
                            #if msg._from in admin:
                                wait["rsmule"] = True
                                ret = "🛑Detect smule On"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "smule off":
                            #if msg._from in admin:
                                wait["rsmule"] = False
                                ret = "🛑Detect smule Off"
                                sendZulBots3(to, str(ret))

                        elif cmd == "tiktok on":
                            #if msg._from in admin:
                                wait["tiktok"] = True
                                ret = "🛑Tiktok url enable"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "tiktok off":
                            #if msg._from in admin:
                                wait["tiktok"] = False
                                ret = "🛑Tiktok url disable"
                                sendZulBots3(to, str(ret))

                        elif cmd == "youtube on":
                            #if msg._from in admin:
                                wait["ytube"] = True
                                ret = "🛑youtube url enable"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "youtube off":
                            #if msg._from in admin:
                                wait["ytube"] = False
                                ret = "🛑youtube url disable"
                                sendZulBots3(to, str(ret))

                        elif cmd == "jointicket on":
                            #if msg._from in admin:
                                wait["autoJoinTicket"] = True
                                ret = "🛑Join Ticket On."
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "jointicket off":
                            #if msg._from in admin:
                                wait["autoJoinTicket"] = False
                                ret = "🛑Join Ticket Off."
                                sendZulBots3(to, str(ret))
                                
                        elif cmd == "wc on":
                            #if msg._from in admin:
                                wait["welcomeOn"] = True
                                ret = "🛑Welcome Msg Enable."
                                sendZulBots3(to, str(ret))
                                
                        elif cmd == "autolike on":
                            #if msg._from in admin:
                                wait["likeOn"] = True
                                ret = "🛑Auto Like Enable."
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "wc off":
                            #if msg._from in admin:
                                wait["welcomeOn"] = False
                                ret = "🛑Welcome Msg Disable."
                                sendZulBots3(to, str(ret))                                
                                
                        elif cmd == "autolike off":
                            #if msg._from in admin:
                                wait["likeOn"] = False
                                ret = "🛑Auto like Disable."
                                sendZulBots3(to, str(ret))                                
        
                        elif cmd == "responsalam on":
                            #if msg._from in admin:
                                wait["responsalam"] = True
                                ret = "🛑Auto responsalam On."
                                sendZulBots3(to, str(ret))
                                
                        elif cmd == "responsalam off":
                            #if msg._from in admin:
                                wait["responsalam"] = False
                                ret = "🛑Auto responsalam Off."
                                sendZulBots3(to, str(ret))
  
                        elif cmd == "token on":
                            #if msg._from in admin:
                                wait["token"] = True
                                ret = "🛑Cek Token On."
                                sendZulBots3(to, str(ret))
                                
                        elif cmd == "token off":
                            #if msg._from in admin:
                                wait["token"] = False
                                ret = "🛑Cek Token Off."
                                sendZulBots3(to, str(ret))
                          
                        elif cmd == "autolike off":
                            #if msg._from in admin:
                                wait["likeOn"] = False
                                ret = "🛑Auto like Disable."
                                sendZulBots3(to, str(ret))                                

                        elif cmd == "sider1 on":
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendSiderZul0(to, "🛑sɪᴅᴇʀ ᴅɪʜɪᴅᴜᴘᴋᴀɴ")
                                  del cctv['point1'][msg.to]
                                  del cctv['sidermem1'][msg.to]
                                  del cctv['cyduk1'][msg.to]
                              except:
                                  pass
                              cctv['point1'][msg.to] = msg.id
                              cctv['sidermem1'][msg.to] = ""
                              cctv['cyduk'][msg.to]=False
                              cctv['cyduk1'][msg.to]=True
                              cctv['cyduk2'][msg.to]=False

                        elif cmd == "sider1 off":
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              if msg.to in cctv['point1']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk1'][msg.to]=False
                                  sendSiderZul0(msg.to, "🛑ᴄᴄᴛv ʏᴀɴɢ ᴛᴇʀᴛᴀɴɢᴋᴀᴘ:\n"+cctv['sidermem1'][msg.to])
                              else:
                                  sendSiderZul0(msg.to, "🛑sɪᴅᴇʀ ᴅɪᴍᴀᴛɪᴋᴀɴ")(msg.to, "🛑sɪᴅᴇʀ ᴅɪ ᴏғғ")                   
             
                        elif cmd == "sider2 on":
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendSiderZul2(msg.to, "🛑sɪᴅᴇʀ ᴅɪʜɪᴅᴜᴘᴋᴀɴ")
                                  del cctv['point2'][msg.to]
                                  del cctv['sidermem2'][msg.to]
                                  del cctv['cyduk2'][msg.to]
                              except:
                                  pass
                              cctv['point2'][msg.to] = msg.id
                              cctv['sidermem2'][msg.to] = ""
                              cctv['cyduk2'][msg.to]=True
                              cctv['cyduk'][msg.to]=False
                              cctv['cyduk1'][msg.to]=False

                        elif cmd == "sider2 off":
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              if msg.to in cctv['point2']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk2'][msg.to]=False
                                  sendSiderZul2(msg.to, "🛑sɪᴅᴇʀ ᴅɪᴍᴀᴛɪᴋᴀɴ")
                              else:
                                  sendSiderZul2(msg.to, "🛑sɪᴅᴇʀ ᴅɪᴍᴀᴛɪᴋᴀɴ")(msg.to, "🛑sɪᴅᴇʀ ᴅɪ ᴏғғ")                   
                                  
                        elif cmd == "sider on":
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendSiderZul3(msg.to, "🛑sɪᴅᴇʀ ᴅɪʜɪᴅᴜᴘᴋᴀɴ")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True
                              cctv['cyduk1'][msg.to]=False
                              cctv['cyduk2'][msg.to]=False

                        elif cmd == "sider off":
                          if wait["selfbot"] == True:
                           #if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  sendSiderZul3(msg.to, "🛑sɪᴅᴇʀ ᴅɪᴍᴀᴛɪᴋᴀɴ")
                              else:
                                  sendSiderZul3(msg.to, "🛑sɪᴅᴇʀ ᴅɪ ᴏғғ")

                        elif cmd == "respon2 on":
                            #if msg._from in admin:
                                wait["detectMention2"] = True
                                wait["detectMention1"] = False
                                wait["respontag"] = False
                                ret = "🛑Auto Respon1 Enable ✓"
                                sendZulBots3(to, str(ret))
                           
                        elif cmd == "respon2 off":
                            #if msg._from in admin:                                
                                wait["detectMention2"] = False
                                ret = "🛑Auto Respon1 Disable ✓"
                                sendZulBots3(to, str(ret))
                                
                        elif cmd == "respon1 on":
                            #if msg._from in admin:
                                wait["detectMention1"] = True
                                wait["detectMention2"] = False
                                wait["respontag"] = False
                                ret = "🛑Auto Respon1 Enable ✓"
                                sendZulBots3(to, str(ret))
                           
                        elif cmd == "respon1 off":
                            #if msg._from in admin:
                                wait["detectMention1"] = False                             
                                ret = "🛑Auto Respon1 Disable ✓"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "respon on":
                            #if msg._from in admin:
                                wait["respontag"] = True
                                wait["detectMention1"] = False
                                wait["detectMention2"] = False
                                ret = "🛑Auto Respon Enable ✓"
                                sendZulBots3(to, str(ret))
                           
                        elif cmd == "respon off":
                            #if msg._from in admin:
                                wait["respontag"] = False
                                ret = "🛑Auto Respon Disable ✓"
                                sendZulBots3(to, str(ret))
                        
                        elif cmd == "responcall on":
                            #if msg._from in admin:
                                wait["responGc"] = True
                                ret = "🛑Detect call enable"
                                sendZulBots3(to, str(ret))
                                                        
                        elif cmd == "responcall off":
                            #if msg._from in admin:
                                wait["responGc"] = False
                                ret = "🛑Detect call disable"
                                sendZulBots3(to, str(ret))
                                                                                      
                        elif cmd == "sticker sider":
                            #if msg._from in admin:
                                wait["AddstickerSider"]["status"] = True
                                ret = "🛑Send a stickers ♪"
                                sendZulBots3(to, str(ret))
                            
                        elif cmd == "sticker tag":
                            #if msg._from in admin:
                                wait["AddstickerTag"]["status"] = True
                                ret = "🛑Send a stickers ♪"
                                sendZulBots3(to, str(ret))

                        elif cmd == "sticker pesan":
                            #if msg._from in admin:
                                wait["AddstickerPesan"]["status"] = True
                                ret = "🛑Send a stickers ♪"
                                sendZulBots3(to, str(ret))

                        elif cmd == "sticker welcome":
                            #if msg._from in admin:
                                wait["AddstickerWelcome"]["status"] = True
                                ret = "🛑Send a stickers ♪"
                                sendZulBots3(to, str(ret))

                        elif cmd == "sticker leave":
                            #if msg._from in admin:
                                wait["AddstickerLeave"]["status"] = True
                                ret = "🛑Send a stickers ♪"
                                sendZulBots3(to, str(ret))
       
                        elif cmd == comd["cban"]:
                          if wait["selfbot"] == True:  
                            #if msg._from in admin:
                              if wait["blacklist"] == {}:
                                   ret = "🛑Blacklist Empty"
                                   sendZulBots3(to, str(ret))
                              else:
                                   ret = "🛑Cleared {} 🛑Blacklist".format(str(len(wait["blacklist"])))
                                   sendZulBots3(to, str(ret))
                                   wait["blacklist"] = {}
                    
#===========COMMAND BLACKLIST============#
                        elif cmd.startswith("talkban "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["Talkblacklist"][target] = True
                                           sendZulBots3(msg.to,"🛑Added Blacklist")
                                       except:
                                           pass

                        elif cmd.startswith("untalkban "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["Talkblacklist"][target]
                                           sendZulBots3(msg.to,"🛑Clear Blacklist")
                                       except:
                                           pass

                        elif cmd == "talkban:on" or text.lower() == 'talkban:on':
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                wait["Talkwblacklist"] = True
                                sendZulBots3(msg.to,"🛑Send Contact")

                        elif cmd == "untalkban:on" or text.lower() == 'untalkban:on':
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                wait["Talkdblacklist"] = True
                                sendZulBots3(msg.to,"🛑Send Contact")

                        elif cmd.startswith("ban "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           sendZulBots3(msg.to,"🛑Added To Blacklist")
                                       except:
                                           pass

                        elif cmd.startswith("unban "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           sendZulBots3(msg.to,"🛑Unbaned Blacklist")
                                       except:
                                           pass

                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                wait["wblacklist"] = True
                                sendZulBots3(msg.to,"🛑Send Contact")

                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                wait["dblacklist"] = True
                                sendZulBots3(msg.to,"🛑Send Contact")

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                              if wait["blacklist"] == {}:
                                sendZulBots3(msg.to,"🛑No Body Is Banned")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                sendZulBots3(msg.to,"🛑Blacklist User\n\n"+ma+"\n↘Total「%s」Blacklist User↘" %(str(len(wait["blacklist"]))))

                        elif cmd == "bl" or text.lower() == 'list bl':
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                              if wait["Talkblacklist"] == {}:
                                sendZulBots3(msg.to,"🛑No Body Is Banned")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                sendZulBots3(msg.to,"🛑Talkban User\n\n"+ma+"\n↘Total「%s」Talkban User↘" %(str(len(wait["Talkblacklist"]))))

                        elif cmd == "blc" or text.lower() == 'blc':
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    sendZulBots3(msg.to,"🛑No body is baned")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = cl.getContact(i)
                                        sendZulBots3(to, None, contentMetadata={'mid': i}, contentType=13)
#===========COMMAND SET============#wait["noTiFcall"],
                        elif cmd.startswith("setrespon1: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   wait["balasan"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))
                        elif cmd.startswith("setcall: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   wait["noTiFcall"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))
                        elif cmd.startswith("setcall1: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   wait["noTiFcall1"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))
                        elif cmd.startswith("setsider2: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   wait["siderMsg"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))
                        elif cmd.startswith("setpesan: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   wait["pesan"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setcomment: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   wait["comment"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setspeed: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   comd["speed"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))
                                  
                        elif cmd.startswith("setbye: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   comd["bye"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setkick: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   comd["kick"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))
                        elif cmd.startswith("setsider1on: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   comd["sider1On"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setsider1off: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   comd["sider1Off"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))
                        elif cmd.startswith("setsideron: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   comd["siderOn"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setsideroff: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   comd["siderOff"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))

                        elif cmd.startswith("Set tagall: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   comd["tagall"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))
                        elif 'Setjs: ' in msg.text:
                           #if msg._from in admin:
                              spl = msg.text.replace('Setjs: ','')
                              if spl in [""," ","\n",None]:
                                  sendZulBots3(msg.to, "🛑Gagal mengganti Pesan amda")
                              else:
                                  wait["amda"] = spl
                                  sendZulBots3(msg.to, "「amda」\n🛑amda diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Setbypass: ' in msg.text:
                           #if msg._from in admin:
                              spl = msg.text.replace('Setbypass: ','')
                              if spl in [""," ","\n",None]:
                                  sendZulBots3(msg.to, "🛑Gagal mengganti Pesan amdb")
                              else:
                                  wait["amdb"] = spl
                                  sendZulBots3(msg.to, "「amdb」\n🛑amdb diganti jadi :\n\n「{}」".format(str(spl)))
                        elif cmd.startswith("sethelp: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   comd["help"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setcban: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   comd["cban"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setrespon: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   wait["Tag"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setspam: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   Setmain["RAmessage1"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setunsend: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendZulBots3(msg.to, "🛑Failed..!!")
                               else:
                                   comd["unsend"] = str(key).lower()
                                   sendZulBots3(to, "{}".format(str(key).lower()))

                        elif cmd == "cekpesan":
                            #if msg._from in admin:
                               sendZulBots3(msg.to, "🛑\n"+ str(wait["pesan"]))
                               
                        elif cmd == "cekwelcome":
                            #if msg._from in admin:
                               sendZulBots3(msg.to, "🛑\n" + str(wait["welcome"]))
                               
                        elif cmd == "cekcomment":
                            #if msg._from in admin:
                               sendZulBots3(msg.to, "🛑\n" + str(wait["comment"]))                               

                        elif cmd == "cekrespon":
                            #if msg._from in admin:
                               sendZulBots3(msg.to, "🛑\n" + str(wait["Tag"]))

                        elif cmd == "cekspam":
                            #if msg._from in admin:
                               sendZulBots3(msg.to, "🛑\n" + str(Setmain["RAmessage1"]))

                        elif cmd == "ceksider":
                            #if msg._from in admin:
                               sendZulBots3(msg.to, "🛑\n" + str(wait["mention"]))

                        elif cmd == "ceksider1":
                            #if msg._from in admin:
                               sendZulBots3(msg.to, "🛑\n" + str(wait["mention1"]))
                               
                        elif cmd == "cekcomment":
                            #if msg._from in admin:
                               sendZulBots3(msg.to, "🛑\n" + str(wait["comment"]))

                        elif cmd == "cekleave":
                            #if msg._from in admin:
                               sendZulBots3(msg.to, "🛑\n" + str(wait["leave"]))

                        elif cmd.startswith("lefft: "):
                            #if msg._from in admin:
                                proses = text.split(" ")
                                ng = text.replace(proses[0] + " ","")
                                gid = cl.getAllChatIds()
                                for i in gid:
                                    h = cl.getChats(i).name
                                    if h == ng:
                                        cl.sendMessage(i, "🛑waitting for notifed success")
                                        cl.deleteSelfFromChat(i)
                                        cl.sendMessage(msg.to,"🛑Leave all group " +h)

                        elif text.lower() == "?yowes.":
                          if wait["selfbot"] == True:
                           if msg._from in admin or msg._from in staff:
                             ktl = cl.getChats([to]).chats[0]
                             if ktl.extra.groupExtra.inviteeMids == None:pends = []
                             else:pends = ktl.extra.groupExtra.inviteeMids
                             pending = []
                             for x in pends:
                               if x not in staff:
                                 if x not in admin:
                                   if x not in owner:
                                     if x not in creator:
                                       pending.append(x)
                             member = []
                             for x in ktl.extra.groupExtra.memberMids:
                               if x not in staff:
                                 if x not in admin:
                                   if x not in owner:
                                     if x not in creator:
                                       member.append(x)
                             cm = 'Zul.js gid={} type=dual token={} {}'.format(to, cl.authToken, "DESKTOPWIN\t8.7.0.3000\t13.385179")
                             for x in pending:
                                 cm += ' uik={}'.format(x)                              
                             for x in member:
                                 cm += ' uid={}'.format(x)                            
                             success = execute_js(cm)
                             return success

                        elif text.lower() == "?tampol.":
                          if wait["selfbot"] == True:
                           if msg._from in admin or msg._from in staff:
                             ktl = cl.getChats([to]).chats[0]
                             if ktl.extra.groupExtra.inviteeMids == None:pends = []
                             else:pends = ktl.extra.groupExtra.inviteeMids
                             pending = []
                             for x in pends:
                               if x not in staff:
                                 if x not in admin:
                                   if x not in owner:
                                     if x not in creator:
                                       pending.append(x)
                             member = []
                             for x in ktl.extra.groupExtra.memberMids:
                               if x not in staff:
                                 if x not in admin:
                                   if x not in owner:
                                     if x not in creator:
                                       member.append(x)
                             cm = 'Zul.js gid={} type=dual token={} {}'.format(to, cl.authToken, "DESKTOPWIN\t8.7.0.3000\t13.385179")
                             for x in pending:
                                 cm += ' uik={}'.format(x)                              
                             for x in member:
                                 cm += ' uid={}'.format(x)                            
                             success = execute_js(cm)
                             return success

                        elif text.lower() == "?hajar.":
                          if wait["selfbot"] == True:
                           if msg._from in admin or msg._from in staff:
                             ktl = cl.getChats([to]).chats[0]
                             if ktl.extra.groupExtra.inviteeMids == None:pends = []
                             else:pends = ktl.extra.groupExtra.inviteeMids
                             pending = []
                             for x in pends:
                               if x not in staff:
                                 if x not in admin:
                                   if x not in owner:
                                     if x not in creator:
                                       pending.append(x)
                             member = []
                             for x in ktl.extra.groupExtra.memberMids:
                               if x not in staff:
                                 if x not in admin:
                                   if x not in owner:
                                     if x not in creator:
                                       member.append(x)
                             cm = 'Zul.js gid={} type=dual token={} {}'.format(to, cl.authToken, "DESKTOPWIN\t8.7.0.3000\t13.385179")
                             for x in pending:
                                 cm += ' uik={}'.format(x)                              
                             for x in member:
                                 cm += ' uid={}'.format(x)                            
                             success = execute_js(cm)
                             return success

                        elif cmd.startswith("sapu: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                separate = msg.text.split(":")
                                number = msg.text.replace(separate[0] + ":"," ")
                                groups = cl.getAllChatIds()
                                gid = groups[int(number)-1]                             
                                xyz = cl.getChats(gid)
                                if xyz.invitee == None:pends = []
                                else:pends = [c.mid for c in xyz.invitee]
                                targp = []
                                for x in pends:
                                  if x not in admin and x not in Bots and x not in cl.profile.mid:targp.append(x)
                                mems = [c.mid for c in xyz.members]
                                targk = []
                                for x in mems:
                                  if x not in admin and x not in Bots and x not in cl.profile.mid:targk.append(x)
                                lolz = 'dual.js gid={} token={}'.format(gid, cl.authToken, win)
                                for x in targk:lolz += ' uik={}'.format(x)
                                execute_js(lolz)
                        elif text.lower() == wait["amda"]:
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                xyz = cl.getChats(to)
                                if xyz.invitee == None:pends = []
                                else:pends = [c.mid for c in xyz.invitee]
                                targp = []
                                for x in pends:
                                  if x not in admin and x not in Bots and x not in cl.profile.mid:targp.append(x)
                                mems = [c.mid for c in xyz.members]
                                targk = []
                                for x in mems:
                                  if x not in admin and x not in Bots and x not in cl.profile.mid:targk.append(x)
                                lolz = 'dual.js gid={} token={}'.format(to, cl.authToken, win)
                                for x in targk:lolz += ' uik={}'.format(x)
                                execute_js(lolz)
                        elif cmd.startswith("bantai: "):
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                separate = msg.text.split(":")
                                number = msg.text.replace(separate[0] + ":"," ")
                                groups = cl.getAllChatIds()
                                gid = groups[int(number)-1]  
                                bypassJS(gid)

                        elif text.lower() == wait["amdb"]:
                          if wait["selfbot"] == True:
                            #if msg._from in admin:
                                bypassJS(to)
                                
                        elif cmd == "#cl" or text.lower() == "#cencel":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                                SoakBots = cl.getChats(to)
                                if SoakBots.invitee == None:pends = []
                                else:pends = [c.mid for c in SoakBots.invitee]
                                targp = []
                                for x in pends:
                                  if x not in admin and x not in Bots and x not in cl.profile.mid:targp.append(x)
                                pokeh = 'cancel.js gid={} token={}'.format(to, cl.authToken, win)
                                for x in targp:pokeh += ' uid={}'.format(x)
                                execute_js(pokeh)
                                
 #notifikasi                                                                          
            if msg.contentType == 6:
                  if wait["responGc"] == True:
                    if msg._from not in Bots:
                        try:
                            contact = cl.getContact(sender)
                            group = cl.getChats([msg.to],True,True).chats[0]                                
                            #cover = cl.getProfileCoverURL(sender)
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            if msg.toType == 2:                
                                b = msg.contentMetadata['GC_EVT_TYPE']
                                c = msg.contentMetadata["GC_MEDIA_TYPE"]
                                if c == "VIDEO" and b == "S":
                                    tz = pytz.timezone("Asia/Jakarta")
                                    timeNow = datetime.now(tz=tz)
                                    arg = "ɢʀᴏᴜᴘ {} call".format(c)
                                    a1 = "{}".format(str(contact.displayName))
                                    a2 = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                    a3 = "{}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    data = {     
                                            "type": "flex",
                                            "altText": "TEAM TERMUX",
                                            "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/r4NMzr2/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "3:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                    "size": "full",
                    "aspectRatio": "7:4",
                    "aspectMode": "cover",
                    "margin": "none",
                    "align": "center",
                    "gravity": "top"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "80px",
                "offsetTop": "5px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/MnLrchS/ezgif-com-gif-to-apng-4.png",
                    "size": "xxl",
                    "aspectRatio": "6:3",
                    "aspectMode": "cover",
                    "animated": True,
                    "margin": "none"
                  }
                ],
                "position": "absolute",
                "width": "156px",
                "height": "76px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "ᴅᴀ ʏᴀɴɢ ғᴄɢ ɴɪᴄʜ\"ɴᴀɪᴋ ʏᴜᴋ ʙɪᴀʀ ʀᴀᴍᴇ ɢᴀᴇs ",
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                  }
                ],
                "position": "absolute",
                "width": "34px",
                "height": "36px",
                "backgroundColor": "#000000",
                "offsetTop": "28px",
                "offsetEnd": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/DYT9yGS/ezgif-com-gif-to-apng-3.png",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                    "animated": True,
                    "size": "20px"
                  }
                ],
                "position": "absolute",
                "width": "200px",
                "height": "15px",
                "offsetTop": "68px",
                "offsetEnd": "60px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "👥:{}".format(cl.getContact(msg._from).displayName),
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "1px",
                    "offsetTop": "1px"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "8px",
                "backgroundColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "57px",
                "offsetStart": "22px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰"+ datetime.strftime(timeNow,'%H:%M'),
                    "size": "5px",
                    "color": "#fbfbf0",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "10px",
                "offsetTop": "6px",
                "offsetStart": "114px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "??"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "14px",
                "offsetStart": "115px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "NOTIF CALL",
                    "size": "4px",
                    "color": "#00ffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "0px",
                "offsetStart": "6px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "76px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          }
        ],
        "paddingAll": "0px",
        "height": "80px",
        "cornerRadius": "15px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02"
        }
      }
    }
  ]
}
}
                                    time.sleep(0.5)
                                    sendTemplate(to, data)                       
                                if c == 'AUDIO' and b == "S":
                                    contact = cl.getContact(sender)                            
                                    #cover = cl.getProfileCoverURL(sender)                         
                                    tz = pytz.timezone("Asia/Jakarta")
                                    timeNow = datetime.now(tz=tz)
                                    arg = "ɢʀᴏᴜᴘ {} call".format(c)
                                    satu = "{}".format(str(contact.displayName))
                                    dua = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                    tiga = "{}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    data = {     
                                            "type": "flex",
                                            "altText": "TEAM TERMUX",
                                            "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/r4NMzr2/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "3:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                    "size": "full",
                    "aspectRatio": "7:4",
                    "aspectMode": "cover",
                    "margin": "none",
                    "align": "center",
                    "gravity": "top"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "80px",
                "offsetTop": "5px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/MnLrchS/ezgif-com-gif-to-apng-4.png",
                    "size": "xxl",
                    "aspectRatio": "6:3",
                    "aspectMode": "cover",
                    "animated": True,
                    "margin": "none"
                  }
                ],
                "position": "absolute",
                "width": "156px",
                "height": "76px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "ᴅᴀ ʏᴀɴɢ ғᴄɢ ɴɪᴄʜ\"ɴᴀɪᴋ ʏᴜᴋ ʙɪᴀʀ ʀᴀᴍᴇ ɢᴀᴇs ",
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                  }
                ],
                "position": "absolute",
                "width": "34px",
                "height": "36px",
                "backgroundColor": "#000000",
                "offsetTop": "28px",
                "offsetEnd": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/DYT9yGS/ezgif-com-gif-to-apng-3.png",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                    "animated": True,
                    "size": "20px"
                  }
                ],
                "position": "absolute",
                "width": "200px",
                "height": "15px",
                "offsetTop": "68px",
                "offsetEnd": "60px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "👥:{}".format(cl.getContact(msg._from).displayName),
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "1px",
                    "offsetTop": "1px"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "8px",
                "backgroundColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "57px",
                "offsetStart": "22px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰"+ datetime.strftime(timeNow,'%H:%M'),
                    "size": "5px",
                    "color": "#fbfbf0",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "10px",
                "offsetTop": "6px",
                "offsetStart": "114px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "📅"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "14px",
                "offsetStart": "115px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "NOTIF CALL",
                    "size": "4px",
                    "color": "#00ffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "0px",
                "offsetStart": "6px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "76px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          }
        ],
        "paddingAll": "0px",
        "height": "80px",
        "cornerRadius": "15px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02"
        }
      }
    }
  ]
}
}
                                    time.sleep(0.5)
                                    sendTemplate(to, data)                       
                                if c == 'LIVE' and b == 'S':
                                    contact = cl.getContact(sender)                            
                                    #cover = cl.getProfileCoverURL(sender)                         
                                    tz = pytz.timezone("Asia/Jakarta")
                                    timeNow = datetime.now(tz=tz)
                                    arg = "ɢʀᴏᴜᴘ {} call".format(c)
                                    c1 = "{}".format(str(contact.displayName))
                                    c2 = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                    c3 = "{}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    data = {     
                                            "type": "flex",
                                            "altText": "TEAM TERMUX",
                                            "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/r4NMzr2/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "3:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                    "size": "full",
                    "aspectRatio": "7:4",
                    "aspectMode": "cover",
                    "margin": "none",
                    "align": "center",
                    "gravity": "top"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "80px",
                "offsetTop": "5px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/MnLrchS/ezgif-com-gif-to-apng-4.png",
                    "size": "xxl",
                    "aspectRatio": "6:3",
                    "aspectMode": "cover",
                    "animated": True,
                    "margin": "none"
                  }
                ],
                "position": "absolute",
                "width": "156px",
                "height": "76px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "ᴅᴀ ʏᴀɴɢ ғᴄɢ ɴɪᴄʜ\"ɴᴀɪᴋ ʏᴜᴋ ʙɪᴀʀ ʀᴀᴍᴇ ɢᴀᴇs ",
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                  }
                ],
                "position": "absolute",
                "width": "34px",
                "height": "36px",
                "backgroundColor": "#000000",
                "offsetTop": "28px",
                "offsetEnd": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/DYT9yGS/ezgif-com-gif-to-apng-3.png",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                    "animated": True,
                    "size": "20px"
                  }
                ],
                "position": "absolute",
                "width": "200px",
                "height": "15px",
                "offsetTop": "68px",
                "offsetEnd": "60px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "👥:{}".format(cl.getContact(msg._from).displayName),
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "1px",
                    "offsetTop": "1px"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "8px",
                "backgroundColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "57px",
                "offsetStart": "22px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰"+ datetime.strftime(timeNow,'%H:%M'),
                    "size": "5px",
                    "color": "#fbfbf0",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "10px",
                "offsetTop": "6px",
                "offsetStart": "114px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "📅"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "14px",
                "offsetStart": "115px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "NOTIF CALL",
                    "size": "4px",
                    "color": "#00ffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "0px",
                "offsetStart": "6px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "76px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          }
        ],
        "paddingAll": "0px",
        "height": "80px",
        "cornerRadius": "15px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02"
        }
      }
    }
  ]
}
}
                                    time.sleep(0.5)
                                    sendTemplate(to, data)                       
                                else:
                                    mills = int(msg.contentMetadata["DURATION"])
                                    seconds = (mills/1000)%60
                                    if c == "VIDEO" and b == "E":
                                        contact = cl.getContact(sender)                            
                                        #cover = cl.getProfileCoverURL(sender)                         
                                        tz = pytz.timezone("Asia/Jakarta")
                                        timeNow = datetime.now(tz=tz)
                                        arg ="ɢʀᴏᴜᴘ {} call".format(c)
                                        b1 = "{}".format(str(contact.displayName))
                                        b2 = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                        b3 = "{}".format(seconds)
                                        data = {     
                                            "type": "flex",
                                            "altText": "TEAM TERMUX",
                                            "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/r4NMzr2/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "3:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                    "size": "full",
                    "aspectRatio": "7:4",
                    "aspectMode": "cover",
                    "margin": "none",
                    "align": "center",
                    "gravity": "top"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "80px",
                "offsetTop": "5px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/MnLrchS/ezgif-com-gif-to-apng-4.png",
                    "size": "xxl",
                    "aspectRatio": "6:3",
                    "aspectMode": "cover",
                    "animated": True,
                    "margin": "none"
                  }
                ],
                "position": "absolute",
                "width": "156px",
                "height": "76px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "ʏᴀ ʙᴀʀᴜ ᴍᴀᴜ\"ɴᴀɪᴋ ʟɢɪ ʏᴜᴋ..?",
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                  }
                ],
                "position": "absolute",
                "width": "34px",
                "height": "36px",
                "backgroundColor": "#000000",
                "offsetTop": "28px",
                "offsetEnd": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/DYT9yGS/ezgif-com-gif-to-apng-3.png",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                    "animated": True,
                    "size": "20px"
                  }
                ],
                "position": "absolute",
                "width": "200px",
                "height": "15px",
                "offsetTop": "68px",
                "offsetEnd": "60px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "👥:{}".format(cl.getContact(msg._from).displayName),
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "1px",
                    "offsetTop": "1px"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "8px",
                "backgroundColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "57px",
                "offsetStart": "22px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰"+ datetime.strftime(timeNow,'%H:%M'),
                    "size": "5px",
                    "color": "#fbfbf0",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "10px",
                "offsetTop": "6px",
                "offsetStart": "114px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "📅"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "14px",
                "offsetStart": "115px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "NOTIF CALL",
                    "size": "4px",
                    "color": "#00ffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "0px",
                "offsetStart": "6px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "76px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          }
        ],
        "paddingAll": "0px",
        "height": "80px",
        "cornerRadius": "15px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02"
        }
      }
    }
  ]
}
}
                                        time.sleep(0.5)
                                        sendTemplate(to, data)
                                    if c == "AUDIO" and b == "E":
                                        contact = cl.getContact(sender)                            
                                        #cover = cl.getProfileCoverURL(sender)                         
                                        tz = pytz.timezone("Asia/Jakarta")
                                        timeNow = datetime.now(tz=tz)
                                        arg ="ɢʀᴏᴜᴘ {} call".format(c)
                                        empat = "{}".format(str(contact.displayName))
                                        lima = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                        data = {     
                                            "type": "flex",
                                            "altText": "TEAM TERMUX",
                                            "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/r4NMzr2/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "3:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                    "size": "full",
                    "aspectRatio": "7:4",
                    "aspectMode": "cover",
                    "margin": "none",
                    "align": "center",
                    "gravity": "top"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "80px",
                "offsetTop": "5px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/MnLrchS/ezgif-com-gif-to-apng-4.png",
                    "size": "xxl",
                    "aspectRatio": "6:3",
                    "aspectMode": "cover",
                    "animated": True,
                    "margin": "none"
                  }
                ],
                "position": "absolute",
                "width": "156px",
                "height": "76px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "ʏᴀ ʙᴀʀᴜ ᴍᴀᴜ\"ɴᴀɪᴋ ʟɢɪ ʏᴜᴋ..?",
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                  }
                ],
                "position": "absolute",
                "width": "34px",
                "height": "36px",
                "backgroundColor": "#000000",
                "offsetTop": "28px",
                "offsetEnd": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/DYT9yGS/ezgif-com-gif-to-apng-3.png",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                    "animated": True,
                    "size": "20px"
                  }
                ],
                "position": "absolute",
                "width": "200px",
                "height": "15px",
                "offsetTop": "68px",
                "offsetEnd": "60px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "👥:{}".format(cl.getContact(msg._from).displayName),
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "1px",
                    "offsetTop": "1px"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "8px",
                "backgroundColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "57px",
                "offsetStart": "22px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰"+ datetime.strftime(timeNow,'%H:%M'),
                    "size": "5px",
                    "color": "#fbfbf0",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "10px",
                "offsetTop": "6px",
                "offsetStart": "114px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "📅"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "14px",
                "offsetStart": "115px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "NOTIF CALL",
                    "size": "4px",
                    "color": "#00ffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "0px",
                "offsetStart": "6px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "76px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          }
        ],
        "paddingAll": "0px",
        "height": "80px",
        "cornerRadius": "15px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02"
        }
      }
    }
  ]
}
}
                                        time.sleep(0.5)
                                        sendTemplate(to, data)
                                    if c == "LIVE" and b == "E":
                                        contact = cl.getContact(sender)                            
                                        #cover = cl.getProfileCoverURL(sender)                         
                                        tz = pytz.timezone("Asia/Jakarta")
                                        timeNow = datetime.now(tz=tz)
                                        arg ="ɢʀᴏᴜᴘ {} call".format(c)
                                        d1 = "{}".format(str(contact.displayName))
                                        d2 = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                        d3 = "{}".format(seconds)
                                        data = {     
                                            "type": "flex",
                                            "altText": "TEAM TERMUX",
                                            "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co.com/r4NMzr2/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "3:2",
            "gravity": "top",
            "animated": True,
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                    "size": "full",
                    "aspectRatio": "7:4",
                    "aspectMode": "cover",
                    "margin": "none",
                    "align": "center",
                    "gravity": "top"
                  }
                ],
                "position": "absolute",
                "width": "110px",
                "height": "80px",
                "offsetTop": "5px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/MnLrchS/ezgif-com-gif-to-apng-4.png",
                    "size": "xxl",
                    "aspectRatio": "6:3",
                    "aspectMode": "cover",
                    "animated": True,
                    "margin": "none"
                  }
                ],
                "position": "absolute",
                "width": "156px",
                "height": "76px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "ʏᴀ ʙᴀʀᴜ ᴍᴀᴜ\"ɴᴀɪᴋ ʟɢɪ ʏᴜᴋ..?",
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                  }
                ],
                "position": "absolute",
                "width": "34px",
                "height": "36px",
                "backgroundColor": "#000000",
                "offsetTop": "28px",
                "offsetEnd": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co.com/DYT9yGS/ezgif-com-gif-to-apng-3.png",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                    "animated": True,
                    "size": "20px"
                  }
                ],
                "position": "absolute",
                "width": "200px",
                "height": "15px",
                "offsetTop": "68px",
                "offsetEnd": "60px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "👥:{}".format(cl.getContact(msg._from).displayName),
                    "size": "4px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "1px",
                    "offsetTop": "1px"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "8px",
                "backgroundColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "57px",
                "offsetStart": "22px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰"+ datetime.strftime(timeNow,'%H:%M'),
                    "size": "5px",
                    "color": "#fbfbf0",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "10px",
                "offsetTop": "6px",
                "offsetStart": "114px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "📅"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "5px",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "14px",
                "offsetStart": "115px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "NOTIF CALL",
                    "size": "4px",
                    "color": "#00ffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "10px",
                "offsetTop": "0px",
                "offsetStart": "6px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "76px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          }
        ],
        "paddingAll": "0px",
        "height": "80px",
        "cornerRadius": "15px",
        "action": {
          "type": "uri",
          "label": "action",
          "uri": "http://line.me/ti/p/~zul.1.02"
        }
      }
    }
  ]
}
}
                                        time.sleep(0.5)
                                        sendTemplate(to, data)
                        except Exception as error:
                            print (error)                
                    
#========================{{Batas Notif}}===========                           
        if op.type in [26, 25]:
            if op.type == 26: print ("[26] RECEIVE MESSAGE")
            else: print ("[25] SEND MESSAGE")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = receiver
            try:
                if msg.contentType == 0:
                    if msg.toType == 2:
                        if wait["quis"] == True:
                            contactlist = cl.getAllContactIds()
                            kontak = [cont.mid for cont in cl.getContacts(contactlist)]
                            for i in range(len(quisdata[to]['asw'])):
                                if text.lower() == quisdata[to]['asw'][i].lower() and sender and clMID and quisdata[to]['saklar'] == True:
                                    if sender:
                                        wnr = cl.getContact(sender).displayName
                                        wna = cl.getContact(sender)
                                        if wnr in quisdata[to]['point']:
                                            quisdata[to]['point'][wnr] += 1
                                        else:
                                            quisdata[to]['point'][wnr] = 1
                                        if i != len(quisdata[to]['asw']):
                                            quisdata[to]['tmp'][i] = str(i+1)+'. '+quisdata[to]['asw'][i]+' (1)'+' ['+wnr+']'
                                            quisdata[to]['asw'][i] = quisdata[to]['asw'][i]+' (*)'
                                        else:
                                            quisdata[to]['tmp'].remove(str(quisdata[to]['tmp'][i]))
                                            quisdata[to]['tmp'].append(str(i+1)+'. '+quisdata[to]['asw'][i]+' (1)'+' ['+wnr+']')
                                            quisdata[to]['asw'].remove(str(quisdata[to]['asw'][i]))
                                            quisdata[to]['tmp'].append(quisdata[to]['asw'][i]+' (*)')
                                        rsl,rnk = '',''
                                        for j in quisdata[to]['tmp']:
                                            rsl += j+'\n'
                                        for k in quisdata[to]['point']:
                                            rnk += 'zulkifli QUIS '+k+' : '+str(quisdata[to]['point'][k])+'\n'
                                        if '_________' in str(quisdata[to]['tmp']):
                                            isi = str(quisdata[to]['quest'])+'\n'+rsl
                                            sendTextTemplateB(to, isi)
                                        else:
                                            quisdata[to]['saklar'] = False
                                            isi = str(quisdata[to]['quest'])+'\n'+rsl
                                            sendTextTemplateB(to, isi)
                                            sendTextTemplateB(to, 'Papan Poin :\n'+rnk)
                                            sendTextTemplateB(to, 'Ketik /mulai untuk Pertanyaan Lainnya.')
                                    else:
                                        sendMention(to, sender, '', 'Anda belum menambahkan TEAM TERMUX Kuis sebagai teman, Untuk ikut bermain silahkan tambahkan TEAM TERMUX Kuis sebagai teman.')
            except Exception as e:
                cl.log("[RECEIVE_MESSAGE] ERROR : " + str(e))
                traceback.print_tb(e.__traceback__)
            if msg.toType == 0 and sender:
                to = sender
            else:
            	to = receiver
            if receiver in temp_flood:
                if temp_flood[receiver]["expire"] == True:
                    if temp_flood[receiver]["expire"] >= 20:
                        temp_flood[receiver]["expire"] = False
                        temp_flood[receiver]["time"] = time.time()
                        #cl.sendMessage(msg.to, "🛑kembali aktif.")
                    return
                elif time.time() - temp_flood[receiver]["time"] <= 5:
                    temp_flood[receiver]["flood"] += 1
                    if temp_flood[receiver]["flood"] >= 20:
                        temp_flood[receiver]["flood"] = 0
                        temp_flood[receiver]["expire"] = True
                        #ret_ = "Spam terdeteksi, BSCC akan silent selama 30 detik pada ruangan ini atau ketik Open untuk mengaktifkan kembali."
                        cl.sendMessage(to, str(ret_))
                else:
                     temp_flood[receiver]["flood"] = 0
                     temp_flood[receiver]["time"] = time.time()
            else:
                temp_flood[receiver] = {
    	            "time": time.time(),
    	            "flood": 0,
    	            "expire": False
                }
            if text is None: return
            if text.lower() == "mulai" and sender:
                if wait["quis"] == True:
                    if quisdata[to]['saklar'] == False:
                        quisdata[to]['saklar'] = True
                        getQuest(to)
                        aa = ''
                        for aswr in quisdata[to]['tmp']:
                            aa += aswr+'\n'
                            q = quisdata[to]['quest']+'\n'+aa
                        cl.sendMessage(to, q)
                    else:
                        aa = '' 
                        for aswr in quisdata[to]['tmp']:
                            aa += aswr+'\n'
                        q = quisdata[to]['quest']+'\n'+aa
                        cl.sendMessage(to, q)
                        cl.sendMessage(msg.to, '🛑Ketik /nyerah untuk mengakhiri pertanyaan ini.')
            elif text.lower() == 'nyerah' and sender:
                if wait["quis"] == True:
                    if quisdata[to]['saklar'] == True:
                        rnk,asd = '',''
                        quisdata[to]['saklar'] = False
                        for j in range(len(quisdata[to]['tmp'])):
                            if '_________' in quisdata[to]['tmp'][j]:
                                if j != len(quisdata[to]['tmp']):
                                    quisdata[to]['tmp'][j] = str(j+1)+'. '+quisdata[to]['asw'][j]+' (*system)'
                                else:
                                    quisdata[to]['tmp'][j].remove(str(quisdata[to]['tmp'][j]))
                                    quisdata[to]['tmp'][j].append(str(j+1)+'. '+quisdata[to]['asw'][j]+' (*system)')
                        for m in quisdata[to]['tmp']:
                            asd += m+'\n'
                        for k in quisdata[to]['point']:
                            rnk += ' '+k+' : '+str(quisdata[to]['point'][k])+'\n'
                        cl.sendMessage(to, str(quisdata[to]['quest'])+'\n'+asd)
                        cl.sendMessage(msg.to, '🛑Papan Poin :\n'+rnk)
                        cl.sendMessage(msg.to, '🛑Ketik /mulai untuk Pertanyaan Lainnya')
                    else:
                        cl.sendMessage(msg.to, '🛑Game belum di mulai.')
                        cl.sendMessage(msg.to, '🛑Ketik /mulai untuk memulai permainan.')
            elif text.lower() == "next" and sender:
                if wait["quis"] == True:
                    if quisdata[to]['saklar'] == True:
                        getQuest(to)
                        aa = ''
                        for aswr in quisdata[to]['tmp']:
                            aa += aswr+'\n'
                            q = quisdata[to]['quest']+'\n'+aa
                        cl.sendMessage(to, q)
                    else:
                        cl.sendMessage(msg.to, '🛑game belom mulai bro.')
            elif text.lower() == 'reset' and sender:
                if wait["quis"] == True:
                    quisdata[to]['point'] = {}
                    quisdata[to]['saklar'] = False
                    cl.sendMessage(msg.to, '🛑Permainan telah di reset.')
                    cl.sendMessage(msg.to, '🛑Ketik /mulai untuk memulai permainan.')

            elif "u" in msg.text.lower():
              if wait["nganu"] == True:
                if msg._from in sender:
                    mid = re.compile(r'u\w{32}')
                    mymid = mid.findall(text)
                    n_links = []
                    for l in mymid:
                        if l not in n_links:
                            n_links.append(l)
                    if n_links == []:
                        pass
                    else:
                        for midd in n_links:
                            time.sleep(0.2)
                            cl.sendContact(to, midd)
                        #cl.removeAllMessages(to)

            elif text.lower() == 'helpquis' and sender:
                if wait["quis"] == True:
                    helpMessagequis = helpquis()
                    cl.sendMessage(to, str(helpMessagequis))

    except Exception as error:
        print (error)

while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                oepoll.setRevision(op.revision)
                bot(op)
                recordOp(op)
                
    except Exception as e:
        pass